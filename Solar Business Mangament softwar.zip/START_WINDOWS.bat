@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 24.8 or newer is required. Install Node.js first.
  pause
  exit /b 1
)
echo CONFIX Solar Solution offline office
 echo Open http://127.0.0.1:4173 in your browser.
echo Leave this window open. Press Ctrl+C to stop.
node server.mjs
pause
