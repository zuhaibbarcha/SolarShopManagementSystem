# Manual item data flow

`public/app.js` makes saved selection and manual description mutually exclusive.
`server.mjs` validates the same rule independently; a changed description may
not retain a saved item ID. Historical quotations with mismatched saved-item
names need review before conversion, so the server cannot deduct the wrong
item's stock.

At invoice issuance, `catalogueManualInvoiceLines()` creates one catalog row
per manual line in the same SQLite transaction as the invoice. It stores the
invoice's agreed sale price as a *pending catalog price*, leaves stock at zero,
and stores `null` as the unresolved line cost. `reviewStatus` and
`originInvoiceId` are metadata columns added to the `items` table by migration.
Pending items are hidden from employee item selection and blocked from manual
stock adjustment, edit and archive until review.

`resolveInvoicePricing()` is admin-only. It takes the actual unit cost,
confirmed catalog sale price and category, then changes the invoice cost
snapshot, relevant return cost snapshots and catalog review status atomically.
It will not run twice for the same line. An explicit checkbox confirms a
legitimate zero cost; a later-discovered sale below cost also requires
explicit confirmation. A later catalog price edit cannot rewrite invoice totals
or historical unit prices.

A manual physical product sold at stock zero has no issue movement. A physical
return adds a positive inventory movement. Voiding an invoice with an
unresolved manual item archives its unused catalog row without inventing
stock. Linked returns and payments still block unsafe voiding. Services never
change stock even if a return is recorded.

`profitSummary()` flags any valid invoice line with `null`/missing cost or no
catalog link as incomplete. Its saved-cost formula includes product and service
costs. It restores cost only for physical goods actually received back. Recorded
expenses change Net profit, not Sales profit. A positive quantity returned
while cost is pending also makes Inventory value incomplete.

The migration does not delete old data. Existing manual invoice lines with no
catalog link enter the review queue. Review links them to a new item and, when
appropriate, reconciles an earlier physical return. This backfill has an audit
entry; the invoice and credit-note amounts remain unchanged.
