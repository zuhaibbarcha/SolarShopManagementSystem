# Protecting the offline installation

The application has a **super admin** and a **sales employee**. Only the admin
can change inventory, record expenses, see reports and dashboard financials,
record payments/returns, void documents, manage the employee login and download
a backup. API routes enforce these restrictions independently of the menus.

The database is a normal, unencrypted SQLite file at `data/confix.sqlite`.
Anyone who can read that file can copy the business records without signing in
through the app. Anyone with write access to the folder can change or replace
it. Source code can also be copied or edited by someone who has file access.
No local app password can stop a Windows administrator or a person with physical
access to an unlocked computer from taking control of the files.

For a single office PC, use these Windows protections:

1. Keep the project in a dedicated local NTFS folder, not a shared folder or
   cloud-synced desktop. Create one Windows account for the owner and separate
   **standard** (non-admin) Windows accounts for staff.
2. Allow only the owner account and Windows SYSTEM to access the project folder
   and external backup folder. The optional `PROTECT_WINDOWS_FOLDER.ps1` can
   restrict this project copy after you make a backup and stop the server.
   Run it first without `-Apply` to see the command. It changes NTFS permissions
   recursively and has not been exercised on your specific Windows computer.
   You can instead use **Properties → Security → Advanced** and verify access
   before removing broad inherited permissions. Protect external backups
   separately; this script only covers the project folder.
3. Enable full-disk encryption supported by the Windows edition/device and
   keep the recovery key somewhere safe. Lock the Windows session when away.
4. Use different, strong app passwords for admin and employee. Give employees
   only the employee account. Never share the admin password or backup files.
5. Save a consistent backup from the app to a separate protected drive, then
   test restore in a separate test folder. Keep at least one offline backup.

These steps restrict ordinary local users but cannot guarantee that a Windows
administrator, the owner of a copy, or someone with the source code cannot
modify or reuse it. Preventing commercial reuse of copied source code is not a
technical feature of an offline application. The included ownership notice
states the intended restrictions; access controls protect only copies and
computers that you manage.


## Invoice full access for the sales employee

The sales employee can create invoices, record partial/final payments, create partial/full sales returns, mark stock as physically received during initial return entry, and view payment/return history. Cost prices remain hidden. Below-cost overrides, pricing resolution, late return-restock correction, voiding protected documents, inventory administration, expenses, backups, and user/security administration remain Super Admin only.
