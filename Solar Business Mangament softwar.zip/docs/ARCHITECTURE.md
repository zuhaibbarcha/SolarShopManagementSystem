# Developer guide — CONFIX Solar Solution offline

## File map

| File | Purpose |
| --- | --- |
| `server.mjs` | Local HTTP API, validation, roles, SQLite transactions, backup/restore. |
| `schema.sql` | SQLite tables and indexes. Existing tables are preserved. |
| `public/index.html` | Startup screen and entry point. |
| `public/app.js` | Browser forms, dashboard calculations, documents and navigation. |
| `public/local.css` | Core, branded, responsive and print styling. |
| `public/confix-logo.jpg` | Logo used on screen and documents. |
| `public/payment-qr.jpg` | Original supplied invoice payment QR; the print CSS displays the complete code. |
| `tests/` | Temporary-database integration and calculation tests. |
| `data/` | Live SQLite database and server lock; excluded from the package. |

The browser requests `/api/session`, then `/api/state`. `server.mjs` binds only
`127.0.0.1:4173`. Browser controls reflect the role, while the API separately
checks the role and CSRF token. Do not remove the API checks when changing menus.

## Data and units

Money is stored as **integer paisa**. PKR 1,000.00 is `100000` in the API and
database. Product `price` is the catalog sale price; `purchasePrice` is unit cost.
`trackStock=false` is appropriate for services, but a service may have a cost.
Document `lines` are JSON snapshots containing description, quantity, final unit
price, catalog list price, saved cost and stock-tracking flag. That snapshot
protects historical amounts when a product is edited later.

A document's `kind` is `quotation`, `invoice` or `return`. `sourceId` links an
invoice to its quotation or a return to its invoice. `convertedInvoiceId` links
back from a quotation. `payments`, `movements`, `expenses` and `audit` have their
own rows. A voided document remains in `documents` with status `void`.

`schema.sql` is applied with `CREATE TABLE IF NOT EXISTS` at startup. The
existing `users.role` migration remains in `server.mjs`. For future schema
changes, add an explicit migration; editing an existing CREATE TABLE statement
alone will not change a user's existing database.

## Business workflow

1. Admin creates products and sets opening stock through stock movements.
2. Customer and quotation are saved; quotations do not touch stock.
3. Invoice issuance snapshots cost and deducts physical item quantities in one
   transaction. Service lines never change stock.
4. Payments are separate installment rows; the invoice stores their net sum.
5. A return references the invoice and its original prices. Physical stock
   returns only when `receivedBack` is set. Refunds use separate payment rows.
6. The dashboard calculates Sales profit from invoice amounts after discounts,
   less returns and saved product/service costs, plus physical restock costs.
   Net profit (recorded) subtracts recorded expenses. Earlier invoice lines
   without a saved cost make profit display `Incomplete`.
7. Linked financial documents are controlled by void rules; history is retained.

For linked operations, use the `tx()` wrapper in `server.mjs`. A failed stock
check, payment limit or document validation must roll back the whole action.
The browser's `profitSummary()` is a display calculation, not a permission or
transaction boundary.

## API map

- `GET /api/session`, `POST /api/setup`, `POST /api/login`, `POST /api/logout`
- `GET /api/state` — role-filtered state
- `POST /api/items`, `PATCH /api/items/:id`, `POST /api/items/:id/stock`,
  `POST /api/items/:id/archive` — admin
- `POST /api/customers`, `PATCH /api/customers/:id`
- `POST /api/documents` — quotation, invoice or return (return: admin)
- `PATCH /api/quotations/:id` — status or draft content
- `POST /api/invoices/:id/payments` — payment or refund (admin)
- `POST /api/documents/:id/void`, `POST /api/expenses`,
  `POST /api/users/employee`, `GET /api/backup` — admin

All mutation calls require `x-csrf-token` from the current session. The cookie
is HttpOnly and SameSite=Strict. Sign-in is local to this one installation.

## Safe customization

- Business identity: `public/app.js` (`render`, `auth`, `documentView`),
  `public/index.html`, `public/confix-logo.jpg` and `README.md`.
- Colors, fonts, card sizes and print rules: `public/local.css`.
- Categories and required item fields: `itemData()` in `server.mjs` and the
  item form in `public/app.js`; update both together.
- Invoice amount, stock and return behavior: `createDocument()`, `payment()`,
  `voidDocument()` in `server.mjs`, with matching tests.
- Dashboard numbers: `profitSummary()`, `overview()` and `reports()` in
  `public/app.js`. Be careful that return cost is restored only for physical
  items actually restocked.
- New database fields: add a migration as well as updating `schema.sql`, state
  serialization and tests. Back up a live database before testing migrations.

Do not edit issued invoice amounts directly in SQLite. Use the application
workflow or a separately designed correction/credit-note workflow.

## Development checks

Node.js 24.8+ is required. The app itself needs no npm dependencies.
Run `npm test` after changes. Tests start isolated servers with temporary data
folders, so they do not touch `data/confix.sqlite`. Run `node --check server.mjs`
and `node --check public/app.js` for syntax. Start locally with `npm start` and
check inventory → quotation → invoice → payment → return → dashboard → backup.
The CSS and JS have been formatted with an 88-column target; a few HTML/SVG
fragments and long attribute expressions remain longer because splitting their
literal strings could alter content. Keep future code similarly indented.
