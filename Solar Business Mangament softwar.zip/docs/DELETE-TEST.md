# Removal and reversal test — offline CONFIX

Run in the project folder:

```bat
node --test tests/delete-effects.test.mjs
```

The test starts a real localhost server with a temporary SQLite database. It
uses HTTP requests like the browser, removes its temporary data afterward,
and does not touch the office `data/confix.sqlite`.

| Action | Expected result | Verified |
| --- | --- | --- |
| Archive item with stock > 0 | Rejected; item and stock remain active | Pass |
| Move stock to zero, then archive | Item stays in database as inactive; movement and audit history remain | Pass |
| Archive same item twice | Second request rejected; one archive audit event | Pass |
| Void draft quotation | Status `void`, audit kept, stock and sales unchanged | Pass |
| Convert a void quotation | Rejected | Pass |
| Void quotation with active linked invoice | Rejected until invoice is voided | Pass |
| Void unpaid invoice | Stock restored, invoice excluded from valid sales/receivables, source quotation reopened | Pass |
| Void after sold-out item was archived | Item reactivated, stock restored, reversal and reactivation audited | Pass |
| Physical return after sold-out item was archived | Item reactivated, returned quantity in stock, credit linked | Pass |
| Void credit note or invoice with return | Rejected; financial history remains | Pass |
| Void invoice with partial payment | Rejected; payment, stock and balance unchanged | Pass |
| Expense recorded before invoice void | Expense stays recorded; invoice void only changes valid sales and receivables | Pass |

The app does **not** provide permanent delete for inventory, quotation or
invoice records. It archives inventory and voids eligible documents to keep an
audit trail. There is currently no delete/void action for customers, payment
receipts, refunds, credit notes, expenses, users or audit events. The test does
not claim those unsupported actions work.

A physical return or invoice void may bring stock back after an item was
archived at zero stock. The server now reactivates that item and records
`Item reactivated for stock reversal` in the audit log. It would be unsafe to
leave the returned quantity hidden in an inactive item. Manual stock-in and
new invoicing of an archived item remain blocked until it is active.

This is an automated localhost API test. It does not test clicks or Windows
folder permissions. Run a normal browser check after installing a patch.
