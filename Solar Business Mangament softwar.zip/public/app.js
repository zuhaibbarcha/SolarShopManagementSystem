// The html tag preserves normal template-literal output while allowing the formatter
// to indent HTML fragments inside JavaScript. Dynamic values are still escaped by esc().
function html(strings, ...values) {
  return strings.reduce(
    (result, segment, index) =>
      result + segment + (index < values.length ? String(values[index]) : ""),
    "",
  );
}

// Browser client: rendering, forms and the local API. Money is integer paisa.
const developerCredit =
  '<footer class="developerCredit"><span>Powered by <strong>Barcha Technologies</strong></span><a href="mailto:zuhaibnasirbarcha@gmail.com">zuhaibnasirbarcha@gmail.com</a><a href="tel:03555555174">03555-555174</a></footer>';
const standardNotes = {
  quotation: "Prices are valid for 15 days, subject to stock availability.",
  invoice: "Please quote the invoice number when paying. Thank you for your business.",
};
const $ = (s) => document.querySelector(s),
  app = $("#app"),
  esc = (v) =>
    String(v ?? "").replace(
      /[&<>"']/g,
      (c) =>
        ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c],
    ),
  money = (n) =>
    "PKR " +
    (Number(n || 0) / 100).toLocaleString("en-PK", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }),
  rupees = (n) => Number(n || 0) / 100,
  minor = (v) => Math.round(Number(v || 0) * 100),
  today = () => new Date().toISOString().slice(0, 10);
let csrf = "",
  state = {
    items: [],
    customers: [],
    documents: [],
    payments: [],
    movements: [],
    audit: [],
    expenses: [],
    users: [],
  },
  role = "admin",
  recoveryConfigured = false,
  tab = "Overview",
  modal = "",
  filter = "",
  needle = "",
  busy = false;
async function api(path, method = "GET", data) {
  const res = await fetch("/api/" + path, {
    method,
    credentials: "same-origin",
    headers: {
      ...(data ? { "Content-Type": "application/json" } : {}),
      ...(method !== "GET" ? { "x-csrf-token": csrf } : {}),
    },
    body: data ? JSON.stringify(data) : undefined,
  });
  const body = await res.json();
  if (!res.ok) throw Error(body.error || "Request failed");
  return body;
}
function notice(msg, error = false) {
  document.querySelector(".notice")?.remove();
  const el = document.createElement("div");
  el.className = "notice" + (error ? " error" : "");
  el.textContent = msg;
  document.body.append(el);
  setTimeout(() => el.remove(), 4500);
}
async function action(fn) {
  if (busy) return;
  busy = true;
  document.querySelectorAll("button[type=submit]").forEach((x) => (x.disabled = true));
  try {
    await fn();
    await refresh();
    modal = "";
    render();
    notice("Saved successfully.");
  } catch (e) {
    notice(e.message, true);
  } finally {
    busy = false;
    document
      .querySelectorAll("button[type=submit]")
      .forEach((x) => (x.disabled = false));
  }
}
// The server remains authoritative for records and permissions.
async function refresh() {
  state = await api("state");
  role = state.role || "admin";
  if (role !== "admin" && filter === "Needs pricing") filter = "";
  if (role !== "admin" && !["Customers", "Quotations", "Invoices", "Returns"].includes(tab))
    tab = "Quotations";
}
function showRecoveryKey(key) {
  app.innerHTML = html`<div class="auth"><div class="auth-card">
    <img src="/confix-logo.jpg" alt="CONFIX logo" />
    <h2>Save administrator recovery key</h2>
    <p>This key is shown only now. Print or write it down and keep it somewhere secure. It can reset the Super Admin password if it is forgotten.</p>
    <p class="recovery-key"><b>${esc(key)}</b></p>
    <button id="recovery-continue">I have saved the recovery key</button>
    <p class="login-credit">Powered by <strong>Barcha Technologies</strong></p>
  </div></div>`;
  $("#recovery-continue").onclick = async () => { await refresh(); render(); };
}
function recoverAdmin() {
  app.innerHTML = html`<div class="auth"><form id="recover-form">
    <img src="/confix-logo.jpg" alt="CONFIX logo" />
    <h2>Recover Super Admin</h2>
    <p>Use the recovery key saved when the administrator account was created.</p>
    <input name="username" required minlength="3" placeholder="Super Admin username" autocomplete="username" />
    <input name="recoveryKey" required placeholder="Recovery key" autocomplete="off" />
    <input name="password" required minlength="10" type="password" placeholder="New password (10+ characters)" autocomplete="new-password" />
    <button type="submit">Reset Super Admin password</button>
    <button type="button" class="secondary" id="back-login">Back to sign in</button>
    <p class="login-credit">Powered by <strong>Barcha Technologies</strong></p>
  </form></div>`;
  $("#back-login").onclick = () => auth(false, true);
  $("#recover-form").onsubmit = async (e) => {
    e.preventDefault();
    try {
      const result = await api("recover-admin", "POST", Object.fromEntries(new FormData(e.target)));
      showRecoveryKey(result.recoveryKey);
    } catch (err) { notice(err.message, true); }
  };
}
function forcePasswordChange() {
  app.innerHTML = html`<div class="auth"><form id="change-password-form">
    <img src="/confix-logo.jpg" alt="CONFIX logo" />
    <h2>Change temporary password</h2>
    <p>Your password was reset by the administrator. Create your own password before continuing.</p>
    <input name="password" required minlength="10" type="password" placeholder="New password (10+ characters)" autocomplete="new-password" />
    <button type="submit">Change password</button>
    <button type="button" class="secondary" id="change-password-signout">Sign out</button>
  </form></div>`;
  $("#change-password-signout").onclick = signOut;
  $("#change-password-form").onsubmit = async (e) => {
    e.preventDefault();
    try {
      await api("users/change-password", "POST", Object.fromEntries(new FormData(e.target)));
      await refresh(); render(); notice("Password changed successfully.");
    } catch (err) { notice(err.message, true); }
  };
}
async function signOut() {
  try {
    await api("logout", "POST");
    csrf = "";
    state = null;
    modal = "";
    const s = await api("session");
    recoveryConfigured = !!s.recoveryConfigured;
    auth(!!s.setupNeeded, recoveryConfigured);
  } catch (e) {
    notice(e.message, true);
  }
}
function auth(needed, canRecover = recoveryConfigured) {
  app.innerHTML = html`<div class="auth">
    <form id="auth-form">
      <img src="/confix-logo.jpg" alt="CONFIX logo" />
      <h2>CONFIX SOLAR SOLUTION</h2>
      <p>${needed ? "Create administrator account" : "Sign in"}</p>
      <input
        name="username"
        required
        minlength="3"
        placeholder="Username"
        autocomplete="username"
      /><input
        name="password"
        required
        minlength="${needed ? 10 : 1}"
        type="password"
        placeholder="Password"
        autocomplete="${needed ? "new-password" : "current-password"}"
      /><button type="submit">${needed ? "Create account" : "Sign in"}</button>
      ${!needed && canRecover ? '<button type="button" class="secondary" id="forgot-password">Forgot Super Admin password?</button>' : ""}
      <p class="login-credit">Powered by <strong>Barcha Technologies</strong></p>
    </form>
  </div>`;
  if (!needed && canRecover) $("#forgot-password").onclick = recoverAdmin;
  $("#auth-form").onsubmit = async (e) => {
    e.preventDefault();
    const b = Object.fromEntries(new FormData(e.target));
    try {
      const result = await api(needed ? "setup" : "login", "POST", b);
      csrf = result.csrf;
      role = result.role || "admin";
      if (result.recoveryKey) return showRecoveryKey(result.recoveryKey);
      if (result.mustChangePassword) return forcePasswordChange();
      await refresh();
      render();
    } catch (err) {
      notice(err.message, true);
    }
  };
}
async function boot() {
  try {
    const s = await api("session");
    csrf = s.csrf || "";
    role = s.role || "admin";
    recoveryConfigured = !!s.recoveryConfigured;
    if (!s.user) return auth(s.setupNeeded, recoveryConfigured);
    if (s.mustChangePassword) return forcePasswordChange();
    await refresh();
    render();
  } catch (e) {
    app.innerHTML =
      '<div class="boot"><h2>Cannot connect to local server</h2><p>Start the application and reload this page.</p></div>';
  }
}
const docs = (k) => state.documents.filter((d) => d.kind === k && d.status !== "void"),
  find = (id) => state.documents.find((d) => d.id === id),
  item = (id) => state.items.find((x) => x.id === id),
  balance = (d) => Math.max(0, d.total - d.creditTotal - d.paidTotal),
  payStatus = (d) =>
    d.status === "void"
      ? "Void"
      : balance(d) === 0
        ? "Paid"
        : d.dueDate && d.dueDate < today()
          ? "Overdue"
          : d.paidTotal > 0
            ? "Partially paid"
            : "Unpaid";
function navIcon(name) {
  const shapes = {
    Overview:
      '<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/>',
    Inventory: '<path d="M3 7 12 3l9 4-9 4-9-4Zm0 0v10l9 4 9-4V7M12 11v10"/>',
    Customers:
      '<circle cx="9" cy="8" r="3"/><path d="M3 20v-2a6 6 0 0 1 12 0v2M17 6a3 3 0 0 1 0 6m1 3a5 5 0 0 1 3 5"/>',
    Quotations:
      '<path d="M6 2h8l5 5v15H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2Zm8 0v5h5M8 12h8M8 16h8"/>',
    Invoices: '<path d="M5 2h14v20l-3-2-4 2-4-2-3 2V2Zm3 6h8M8 12h8M8 16h5"/>',
    Returns: '<path d="M3 7v5h5M4 12a8 8 0 1 1 2 6M3 12l5-5"/>',
    Reports: '<path d="M4 20V11h4v9m4 0V5h4v15m4 0v-7h4v7M2 20h20"/>',
    Expenses:
      '<rect x="3" y="6" width="18" height="14" rx="2"/><path d="M3 10h18M7 6V4h12M16 15h2"/>',
    LogOut: '<path d="M10 17l5-5-5-5m5 5H3m8-9h8a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-8"/>',
    Users:
      '<path d="M12 2 20 5v6c0 5-3 8-8 11-5-3-8-6-8-11V5l8-3Z"/><circle cx="12" cy="10" r="2"/><path d="M8 17c.5-2 2-3 4-3s3.5 1 4 3"/>',
  };
  return html`<svg
    class="nav-icon"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    stroke-width="1.7"
    stroke-linecap="round"
    stroke-linejoin="round"
    aria-hidden="true"
  >
    ${shapes[name] || shapes.Overview}
  </svg>`;
}
function headingMeta(name) {
  return (
    {
      Overview: ["THE BUSINESS AT A GLANCE", "Your solar business, clearly in view."],
      Inventory: ["PRODUCTS & STOCK", "Every product accounted for."],
      Customers: ["PEOPLE & PARTNERS", "Relationships behind every project."],
      Quotations: ["PROPOSALS & TENDERS", "From first estimate to accepted offer."],
      Invoices: ["BILLING & RECEIVABLES", "A clear record of every sale."],
      Returns: ["CREDITS & ADJUSTMENTS", "Every return connected to its sale."],
      Reports: ["INSIGHTS & PERFORMANCE", "The numbers behind better decisions."],
      Expenses: ["COSTS & OPERATIONS", "Know where the business spends."],
      Users: ["TEAM & ACCESS", "The right access for every role."],
    }[name] || ["CONFIX SOLAR SOLUTION", ""]
  );
}
// Rebuild the active page after state changes; bind() attaches its controls.
function render() {
  const pendingPricing =
    role === "admin"
      ? state.documents
          .filter((d) => d.kind === "invoice" && d.status !== "void")
          .flatMap((d) => d.lines)
          .filter((l) => !l.itemId || l.costPrice === null || l.costPrice === undefined)
          .length
      : 0;
  const names =
    role === "admin"
      ? [
          "Overview",
          "Inventory",
          "Customers",
          "Quotations",
          "Invoices",
          "Returns",
          "Reports",
          "Expenses",
          "Users",
        ]
      : ["Customers", "Quotations", "Invoices", "Returns"];
  app.innerHTML = html`<div class="layout">
      <nav class="side">
        <div class="brand"><img src="/confix-logo.jpg" alt="CONFIX logo" /></div>
        <div class="side-links">
          ${names.map((n) => html`<button data-tab="${n}" class="${tab === n ? "on" : ""}">${navIcon(n)}<span>${n}</span></button>`).join("")}
        </div>
        <div class="side-bottom">
          <button id="logout">${navIcon("LogOut")}<span>Sign out</span></button
          >${developerCredit}
        </div>
      </nav>
      <main class="main">
        <header class="company-header">
          <img src="/confix-logo.jpg" alt="CONFIX Solar Solution logo" />
          <div class="company-identity">
            <strong class="company-wordmark">CONFIX <em>SOLAR SOLUTION</em></strong
            ><span>OFFICE NO. 5, 6 ALI MARKET, NEAR PSO PUMP, YADGAR CHOWK, GILGIT</span
            ><span>+92 345 2670067 · CONFIXPRIVATELIMITED@GMAIL.COM</span>
          </div>
          <div class="header-credit">
            POWERED BY <strong>Barcha Technologies</strong>
          </div>
        </header>
        ${pendingPricing ? html`<button class="pricing-alert no-print" data-goto="Invoices" data-filter="Needs pricing">${pendingPricing} invoice line${pendingPricing === 1 ? "" : "s"} need cost and sale price review. Open review →</button>` : ""}
        <div class="pagebar">
          <div class="page-heading">
            <span class="eyebrow">${headingMeta(tab)[0]}</span>
            <div class="page-title-row">
              <span class="page-title-icon">${navIcon(tab)}</span>
              <h1>${esc(tab)}</h1>
            </div>
            <p>${headingMeta(tab)[1]}</p>
          </div>
          <div class="actions no-print">
            <span class="pill"
              >${role === "admin" ? "Super admin" : "Sales employee"}</span
            >${role === "admin" ? '<button class="secondary" id="backup">Download backup</button>' : ""}${tab === "Inventory" ? '<button data-open="item">+ Add item</button>' : tab === "Customers" ? '<button data-open="customer">+ Add customer</button>' : tab === "Quotations" ? '<button data-open="quotation">+ Quotation</button>' : tab === "Expenses" ? '<button data-open="expense">+ Expense</button>' : tab === "Users" ? '<button data-open="employee">Set employee login</button>' : ""}
          </div>
        </div>
        <section id="content">${content()}</section>
      </main>
    </div>
    ${
      modal
        ? html`<div class="dialog">
            <div class="box">
              <div class="head">
                <h2>${modalTitle()}</h2>
                <button class="secondary no-print" id="close">✕</button>
              </div>
              <div id="modal-body">${modalContent()}</div>
            </div>
          </div>`
        : ""
    }`;
  bind();
}
function content() {
  if (role !== "admin" && !["Customers", "Quotations", "Invoices", "Returns"].includes(tab))
    return "<p>Access restricted.</p>";
  if (tab === "Overview") return overview();
  if (tab === "Inventory") return inventory();
  if (tab === "Customers") return customers();
  if (tab === "Reports") return reports();
  if (tab === "Expenses") return expenses();
  if (tab === "Users") return users();
  return listing();
}
// Saved cost snapshots avoid changing profit when an item price is edited later.
// Only physical items actually received back restore their cost on a return.
function profitSummary() {
  const invoices = docs("invoice"),
    returns = docs("return"),
    sales = invoices.reduce((a, d) => a + d.total, 0),
    credit = returns.reduce((a, d) => a + d.total, 0),
    cost = invoices.reduce(
      (a, d) => a + d.lines.reduce((v, l) => v + (l.costPrice || 0) * l.quantity, 0),
      0,
    ),
    restockedCost = returns
      .filter((d) => d.receivedBack)
      .reduce(
        (a, d) =>
          a +
          d.lines.reduce(
            (v, l) =>
              v +
              (l.tracked || (l.manualOrigin && l.manualKind !== "Service")
                ? l.costPrice || 0
                : 0) *
                l.quantity,
            0,
          ),
        0,
      ),
    expenses = state.expenses.reduce((a, e) => a + e.amount, 0),
    incomplete = invoices.some((d) =>
      d.lines.some(
        (l) => !l.itemId || l.costPrice === null || l.costPrice === undefined,
      ),
    );
  return {
    sales,
    credit,
    cost,
    restockedCost,
    expenses,
    salesProfit: sales - credit - cost + restockedCost,
    netProfit: sales - credit - cost + restockedCost - expenses,
    incomplete,
  };
}
function overview() {
  const p = profitSummary(),
    invoices = docs("invoice"),
    out = invoices.reduce((a, d) => a + balance(d), 0),
    inventoryCostIncomplete = state.items.some(
      (i) => i.active && i.trackStock && i.reviewStatus === "pending" && i.stock > 0,
    );
  const metrics = [
    ["Total sales", p.sales, "Invoices"],
    ["Sales returns", p.credit, "Returns"],
    ["Accounts receivable", out, "Invoices", "Outstanding"],
    ["Sales profit", p.salesProfit, "Reports"],
    ["Net profit (recorded)", p.netProfit, "Reports"],
    [
      "Payments received",
      state.payments.reduce(
        (a, x) => a + (x.type === "refund" ? -x.amount : x.amount),
        0,
      ),
      "Invoices",
    ],
    [
      "Inventory value",
      state.items
        .filter((i) => i.active && i.trackStock && i.reviewStatus !== "pending")
        .reduce((a, i) => a + i.stock * i.purchasePrice, 0),
      "Inventory",
    ],
    [
      "Low stock items",
      state.items.filter(
        (i) =>
          i.active &&
          i.trackStock &&
          i.reviewStatus !== "pending" &&
          i.stock <= i.lowStock,
      ).length,
      "Inventory",
    ],
  ];
  const cards = (entries, start) =>
    entries
      .map(([name, value, target, query], index) => {
        const ix = start + index;
        return html`<button
          type="button"
          class="stat stat-${ix + 1}"
          data-goto="${target}"
          data-filter="${query || ""}"
        >
          <span class="stat-label">${esc(name)}</span
          ><strong
            >${ix === 7 ? value : ((ix === 3 || ix === 4) && p.incomplete) || (ix === 6 && inventoryCostIncomplete) ? "Incomplete" : money(value)}</strong
          ><span class="stat-link">View details →</span>
        </button>`;
      })
      .join("");
  return html`<section class="metric-section">
      <h2>Financial performance</h2>
      <div class="stats financial-stats">${cards(metrics.slice(0, 6), 0)}</div>
    </section>
    <section class="metric-section">
      <h2>Inventory health</h2>
      <div class="stats inventory-stats">${cards(metrics.slice(6), 6)}</div>
    </section>
    <p class="muted">
      Sales profit = invoice sales − sales returns − saved product and service costs +
      cost of physical items restocked. Net profit (recorded) = sales profit − recorded
      expenses.
      ${p.incomplete ? "Invoice lines awaiting administrator pricing review make profit incomplete." : ""}
      Unrecorded overhead is excluded.
    </p>
    <div class="panel">
      <h2>Activity</h2>
      ${
        state.audit
          .slice(0, 12)
          .map(
            (a) =>
              html`<p>
                <span class="muted"
                  >${esc(a.createdAt.slice(0, 16).replace("T", " "))}</span
                >
                · ${esc(a.action)} · ${esc(a.actor)}
              </p>`,
          )
          .join("") || "No activity yet."
      }
    </div>`;
}

function inventory() {
  const arr = state.items.filter(
    (i) =>
      (!filter ||
        (filter === "Needs pricing"
          ? i.reviewStatus === "pending"
          : filter === "Low stock"
            ? i.reviewStatus !== "pending" && i.trackStock && i.stock <= i.lowStock
            : i.category === filter)) &&
      (!needle ||
        (i.name + " " + i.sku + " " + i.category)
          .toLowerCase()
          .includes(needle.toLowerCase())),
  );
  return html`<div class="toolbar">
      <input
        id="search"
        placeholder="Search name, SKU, category"
        value="${esc(needle)}"
      /><select id="filter">
        <option value="">All categories</option>
        <option ${filter === "Low stock" ? "selected" : ""}>Low stock</option>
        <option ${filter === "Needs pricing" ? "selected" : ""}>Needs pricing</option>
        ${["Solar panel", "Inverter", "Battery", "Service", "Other"].map((x) => html`<option ${filter === x ? "selected" : ""}>${x}</option>`).join("")}
      </select>
    </div>
    <div class="panel scroll">
      <table>
        <thead>
          <tr>
            <th>SKU</th>
            <th>Product / service</th>
            <th>Category</th>
            <th>Sale price</th>
            <th>Stock</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          ${arr
            .map(
              (i) =>
                html`<tr>
                  <td>${esc(i.sku)}</td>
                  <td>${esc(i.name)}</td>
                  <td>${esc(i.category)}</td>
                  <td>${money(i.price)}</td>
                  <td>${i.trackStock ? i.stock : "Service"}</td>
                  <td>
                    ${i.reviewStatus === "pending" ? "Pricing review required" : i.active ? (i.trackStock && i.stock <= i.lowStock ? "Low stock" : "Active") : "Archived"}
                  </td>
                  <td class="actions-cell">
                    ${i.reviewStatus === "pending" ? html`<button class="secondary" data-open="pricing:${i.originInvoiceId}:${state.documents.find((d) => d.id === i.originInvoiceId)?.lines.findIndex((l) => l.itemId === i.id) ?? 0}">Review pricing</button>` : html`<button class="secondary" data-open="item:${i.id}">Edit</button><button class="secondary" data-open="stock:${i.id}">Stock / history</button>`}
                    ${i.active && i.reviewStatus !== "pending" ? html`<button class="danger" data-archive="${i.id}">Archive</button>` : ""}
                  </td>
                </tr>`,
            )
            .join("")}
        </tbody>
      </table>
    </div>`;
}
function customers() {
  const arr = state.customers.filter((c) =>
    (c.name + " " + c.phone + " " + c.email)
      .toLowerCase()
      .includes(needle.toLowerCase()),
  );
  return html`<div class="toolbar">
      <input id="search" placeholder="Search customers" value="${esc(needle)}" />
    </div>
    <div class="panel scroll">
      <table>
        <thead>
          <tr>
            <th>Name / organization</th>
            <th>Phone</th>
            <th>Email</th>
            <th>Address</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          ${arr
            .map(
              (c) =>
                html`<tr>
                  <td>${esc(c.name)}</td>
                  <td>${esc(c.phone)}</td>
                  <td>${esc(c.email)}</td>
                  <td>${esc(c.address)}</td>
                  <td>
                    <button class="secondary" data-open="customer:${c.id}">Edit</button>
                  </td>
                </tr>`,
            )
            .join("")}
        </tbody>
      </table>
    </div>`;
}
function listing() {
  const kind = { Quotations: "quotation", Invoices: "invoice", Returns: "return" }[tab],
    arr = state.documents.filter(
      (d) =>
        d.kind === kind &&
        (!filter ||
          (filter === "Outstanding" && kind === "invoice" && balance(d) > 0) ||
          (filter === "Needs pricing" &&
            kind === "invoice" &&
            d.status !== "void" &&
            d.lines.some(
              (l) => !l.itemId || l.costPrice === null || l.costPrice === undefined,
            )) ||
          filter === d.status ||
          filter === payStatus(d)) &&
        (!needle ||
          (
            d.number +
            " " +
            d.customer +
            " " +
            d.phone +
            " " +
            d.email +
            " " +
            d.title +
            " " +
            d.tenderRef +
            " " +
            d.customerRef +
            " " +
            (d.sourceId ? find(d.sourceId)?.number : "")
          )
            .toLowerCase()
            .includes(needle.toLowerCase())),
    );
  return html`<div class="toolbar">
      <input
        id="search"
        placeholder="Search number, customer, project, reference"
        value="${esc(needle)}"
      /><select id="filter">
        <option value="">All statuses</option>
        ${(kind === "quotation" ? ["Draft", "Submitted", "Approved", "Rejected", "Expired", "Converted to invoice", "void"] : kind === "invoice" ? [...(role === "admin" ? ["Needs pricing"] : []), "Outstanding", "Unpaid", "Partially paid", "Paid", "Overdue", "void"] : ["Issued"]).map((x) => html`<option ${filter === x ? "selected" : ""}>${x}</option>`).join("")}
      </select>
    </div>
    <div class="panel scroll">
      <table>
        <thead>
          <tr>
            <th>Number</th>
            <th>Customer</th>
            <th>Date</th>
            <th>Project / reference</th>
            <th>Total</th>
            <th>Balance</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          ${arr
            .map(
              (d) =>
                html`<tr>
                  <td>${esc(d.number)}</td>
                  <td>${esc(d.customer)}</td>
                  <td>${esc(d.date)}</td>
                  <td>${esc(d.title || d.tenderRef)}</td>
                  <td>${money(d.total)}</td>
                  <td>${kind === "invoice" ? money(balance(d)) : "—"}</td>
                  <td>
                    <span class="pill"
                      >${esc(kind === "invoice" ? payStatus(d) : kind === "return" ? (d.receivedBack ? "Received & restocked" : "Credit issued / stock pending") : d.status)}</span
                    >
                  </td>
                  <td>
                    <button class="secondary" data-open="view:${d.id}">
                      View / print</button
                    >${role === "admin" && kind === "invoice" && d.status !== "void" && d.lines.some((l) => !l.itemId || l.costPrice === null || l.costPrice === undefined) ? html`<button data-open="pricing:${d.id}:${d.lines.findIndex((l) => !l.itemId || l.costPrice === null || l.costPrice === undefined)}">Review pricing</button>` : ""}${d.status !== "void" && kind === "quotation" ? html`<button class="secondary" data-open="quotation:${d.id}">Reuse / edit</button>` : ""}
                  </td>
                </tr>`,
            )
            .join("")}
        </tbody>
      </table>
    </div>`;
}
function reports() {
  const p = profitSummary();
  return html`<div class="panel">
      <h2 class="section-title">Sales and margin</h2>
      <p>Total sales: ${money(p.sales)}</p>
      <p>Sales returns: ${money(p.credit)}</p>
      <p>Receivable: ${money(docs("invoice").reduce((a, d) => a + balance(d), 0))}</p>
      <p>
        Sales profit:
        ${p.incomplete ? "Incomplete — review invoice costs" : money(p.salesProfit)}
      </p>
      ${(() => {
        const pending = docs("return").filter(
          (d) =>
            !d.receivedBack &&
            d.lines.some((l) =>
              l.itemId &&
              (l.tracked || (l.manualOrigin && l.manualKind !== "Service")),
            ),
        );
        return pending.length
          ? html`<p><b>Pending returned stock:</b> ${pending.length} credit note${pending.length === 1 ? "" : "s"}. Profit remains lower until the physical goods are received and restocked.</p>`
          : "";
      })()}
      <p>Recorded expenses: ${money(p.expenses)}</p>
      <p>
        Net profit (recorded):
        ${p.incomplete ? "Incomplete — older invoices have no saved costs" : money(p.netProfit)}
      </p>
      <p>
        Payments: ${state.payments.length} · Inventory movements:
        ${state.movements.length} · Audit events: ${state.audit.length}
      </p>
    </div>
    <div class="panel scroll">
      <h2>Recent stock movements</h2>
      <table>
        <tr>
          <th>Date</th>
          <th>Item</th>
          <th>Quantity</th>
          <th>Reason</th>
          <th>Reference</th>
        </tr>
        ${state.movements
          .slice(0, 50)
          .map(
            (m) =>
              html`<tr>
                <td>${esc(m.createdAt.slice(0, 16))}</td>
                <td>${esc(item(m.itemId)?.name)}</td>
                <td>${m.delta}</td>
                <td>${esc(m.reason)}</td>
                <td>${esc(m.reference)}</td>
              </tr>`,
          )
          .join("")}
      </table>
    </div>`;
}

function expenses() {
  return html`<div class="panel scroll">
    <h2 class="section-title">Recorded business expenses</h2>
    <table>
      <thead>
        <tr>
          <th>Date</th>
          <th>Category</th>
          <th>Amount</th>
          <th>Notes</th>
          <th>Recorded by</th>
        </tr>
      </thead>
      <tbody>
        ${state.expenses
          .map(
            (e) =>
              html`<tr>
                <td>${esc(e.date)}</td>
                <td>${esc(e.category)}</td>
                <td>${money(e.amount)}</td>
                <td>${esc(e.notes)}</td>
                <td>${esc(e.actor)}</td>
              </tr>`,
          )
          .join("")}
      </tbody>
    </table>
  </div>`;
}
function users() {
  return html`<div class="panel">
    <h2>Office accounts</h2>
    <p>Manage the sales employee account here. Resetting the password signs out that employee and requires a new personal password at next sign-in.</p>
    ${state.users.map((u) => html`<p><b>${esc(u.username)}</b> · ${u.role === "admin" ? "Super admin" : "Sales employee"}</p>`).join("")}
    <p><button class="secondary" data-open="recoverykey">Generate / replace Super Admin recovery key</button></p>
    <p class="muted">Use this once after upgrading an existing installation. Generating a new key invalidates the previous recovery key.</p>
  </div>`;
}
function modalTitle() {
  const [kind, id] = modal.split(":");
  return {
    item: id ? "Edit inventory item" : "Add inventory item",
    customer: id ? "Edit customer" : "Add customer",
    stock: "Stock movement and history",
    quotation: id ? "Quotation" : "New quotation",
    invoice: "New invoice",
    return: "Sales return",
    payment: "Record payment / refund",
    pricing: "Resolve invoice item pricing",
    view: "Document",
    expense: "Record expense",
    employee: "Sales employee account",
    recoverykey: "Super Admin recovery key",
  }[kind];
}
function field(name, label, value = "", type = "text", extra = "") {
  return html`<div>
    <label>${label}</label
    ><input name="${name}" type="${type}" value="${esc(value)}" ${extra} />
  </div>`;
}
function modalContent() {
  const [kind, id, mode] = modal.split(":");
  if (kind === "pricing") {
    const invoice = find(id),
      line = invoice?.lines[Number(mode)];
    if (role !== "admin" || !line || invoice.status === "void")
      return "<p>Pricing review unavailable.</p>";
    const linked = item(line.itemId);
    return html`<form id="form" class="form-grid">
      <p class="wide">
        <b>${esc(invoice.number)}</b> · ${esc(line.description)} · quantity
        ${line.quantity}<br />
        Invoice unit price: ${money(line.price)}. This agreed invoice price will remain
        unchanged.
      </p>
      <div>
        <label>Category</label
        ><select name="category">
          ${["Solar panel", "Inverter", "Battery", "Service", "Other"].map((x) => html`<option ${x === (linked?.category || (line.manualKind === "Service" ? "Service" : "Other")) ? "selected" : ""}>${x}</option>`).join("")}
        </select>
      </div>
      ${field("purchasePrice", "Actual unit cost (PKR)", "", "number", 'required min="0" step="0.01"')}
      ${field("salePrice", "Catalog sale price (PKR)", rupees(linked?.price ?? line.price), "number", 'required min="0" step="0.01"')}
      <label class="wide"
        ><input type="checkbox" name="confirmZeroCost" style="width:auto" /> Confirm if
        actual cost is zero</label
      >
      <label class="wide"
        ><input type="checkbox" name="confirmBelowCost" style="width:auto" /> Confirm if
        this invoice was sold below actual cost</label
      >
      <p class="wide muted">
        Saving fills the invoice cost snapshot and linked returns. It is recorded in the
        audit log. Catalog sale price affects future sales only.
      </p>
      <button type="submit" class="wide">Confirm prices and resolve</button>
    </form>`;
  }
  if (kind === "recoverykey")
    return html`<form id="form" class="form-grid"><p class="wide">Generate a new Super Admin recovery key. The previous recovery key will stop working. Save the new key securely when it is displayed.</p><button type="submit" class="wide">Generate new recovery key</button></form>`;
  if (kind === "employee")
    return html`<form id="form" class="form-grid">
      ${field("username", "Employee username", state.users.find((u) => u.role === "employee")?.username, "text", 'required minlength="3"')}${field("password", "New password (10+ characters)", "", "password", 'required minlength="10"')}<button
        type="submit"
        class="wide"
      >
        Save / reset employee login
      </button>
    </form>`;
  if (kind === "expense")
    return html`<form id="form" class="form-grid">
      ${field("date", "Date", today(), "date", "required")}${field("category", "Category", "", "text", "required")}${field("amount", "Amount (PKR)", "", "number", 'required min="0.01" step="0.01"')}${field("notes", "Notes")}<button
        type="submit"
        class="wide"
      >
        Record expense
      </button>
    </form>`;
  if (kind === "item") {
    const i = state.items.find((x) => x.id === id) || {};
    return html`<form id="form" class="form-grid">
      ${field("name", "Product / service name", i.name, "text", "required")}${field("sku", "SKU / code", i.sku)}
      <div>
        <label>Category</label
        ><select name="category">
          ${["Solar panel", "Inverter", "Battery", "Service", "Other"].map((x) => html`<option ${i.category === x ? "selected" : ""}>${x}</option>`).join("")}
        </select>
      </div>
      ${field("unit", "Unit", i.unit || "piece", "text", "required")}${field("brand", "Brand", i.brand)}${field("purchasePrice", "Purchase price (PKR)", rupees(i.purchasePrice), "number", 'min="0" step="0.01"')}${field("price", "Sale price (PKR)", rupees(i.price), "number", 'min="0" step="0.01" required')}${field("lowStock", "Low stock threshold", i.lowStock || 0, "number", 'min="0" step="1"')}
      <div>
        <label>Track physical stock</label
        ><select name="trackStock">
          <option value="1" ${i.trackStock ? "selected" : ""}>Yes</option>
          <option
            value="0"
            ${i.trackStock === false || (!i.id && i.category === "Service") ? "selected" : ""}
          >
            No · service
          </option>
        </select>
      </div>
      ${field("description", "Description", i.description)}<button
        type="submit"
        class="wide"
      >
        Save item
      </button>
    </form>`;
  }
  if (kind === "customer") {
    const c = state.customers.find((x) => x.id === id) || {};
    return html`<form id="form" class="form-grid">
      ${field("name", "Customer / organization", c.name, "text", "required")}${field("phone", "Phone", c.phone)}${field("email", "Email", c.email, "email")}${field("address", "Address", c.address)}<button
        type="submit"
        class="wide"
      >
        Save customer
      </button>
    </form>`;
  }
  if (kind === "stock") {
    const i = item(id);
    return html`<p><b>${esc(i.name)}</b> · Current stock: ${i.stock}</p>
      <form id="form" class="form-grid">
        <div>
          <label>Movement</label
          ><select name="movement">
            <option value="in">Stock in</option>
            <option value="out">Stock out</option>
            <option value="adjust">Set stock to exact quantity</option>
          </select>
        </div>
        ${field("quantity", "Quantity", 1, "number", 'required min="0" step="1"')}${field("reason", "Reason", "Manual adjustment")}${field("reference", "Reference")}<button
          type="submit"
          class="wide"
        >
          Record movement
        </button>
      </form>
      <h3>History</h3>
      ${
        state.movements
          .filter((m) => m.itemId === id)
          .map(
            (m) =>
              html`<p>
                ${esc(m.createdAt.slice(0, 16))} · ${m.delta > 0 ? "+" : ""}${m.delta} ·
                ${esc(m.reason)} · ${esc(m.reference)}
              </p>`,
          )
          .join("") || "<p>No movements.</p>"
      }`;
  }
  if (["quotation", "invoice", "return"].includes(kind))
    return documentForm(kind, id, mode);
  if (kind === "payment") {
    const d = find(id),
      outstanding = balance(d),
      refundable = Math.max(0, d.paidTotal - (d.total - d.creditTotal)),
      refundFirst = !outstanding && refundable > 0;
    return html`<p>
        ${esc(d.number)} · Remaining ${money(outstanding)} · Refund needed
        ${money(refundable)}
      </p>
      <form id="form" class="form-grid">
        <div>
          <label>Entry type</label
          ><select name="type" id="payment-type">
            <option value="payment" ${refundFirst ? "" : "selected"} ${outstanding ? "" : "disabled"}>Payment</option>
            <option value="refund" ${refundFirst ? "selected" : ""} ${refundable ? "" : "disabled"}>Refund after credit note</option>
          </select>
        </div>
        ${field("amount", "Amount (PKR)", rupees(refundFirst ? refundable : outstanding), "number", `required min="0.01" max="${rupees(refundFirst ? refundable : outstanding)}" step="0.01"`)}${field("date", "Date", today(), "date", "required")}
        <p class="wide muted">The full remaining amount is filled in. Enter a smaller amount for a partial payment.</p>
        <div>
          <label>Method</label
          ><select name="method">
            ${["Cash", "Bank", "Online", "Cheque"].map((x) => html`<option>${x}</option>`).join("")}
          </select>
        </div>
        ${field("reference", "Transaction / cheque reference")}${field("notes", "Notes")}<button
          type="submit"
          class="wide"
        >
          Record entry
        </button>
      </form>`;
  }
  if (kind === "view") return documentView(find(id));
  return "";
}
function documentForm(kind, id, mode) {
  const original = find(id),
    source = kind === "invoice" ? original : kind === "return" ? original : null,
    reuse = kind === "quotation" && mode === "reuse",
    edit = kind === "quotation" && mode === "edit",
    d =
      reuse || edit || source
        ? original
        : { lines: [{ itemId: "", description: "", quantity: 1, price: 0 }] },
    lines = d.lines || [],
    savedNotes = state.documents
      .filter((x) =>
        ["quotation", "invoice"].includes(x.kind) &&
        x.status !== "void" &&
        x.notes?.trim() &&
        !Object.values(standardNotes).includes(x.notes.trim()),
      )
      .filter((x, index, all) =>
        all.findIndex((other) => other.notes.trim() === x.notes.trim()) === index,
      )
      .slice(0, 15),
    originalNote = String(d.notes || "").trim(),
    noteValue = kind === "invoice" && source && originalNote === standardNotes.quotation
      ? standardNotes.invoice
      : originalNote || standardNotes[kind] || "";
  return html`<form
    id="form"
    class="form-grid"
    data-doc-kind="${kind}"
    data-source="${source?.id || ""}"
    data-edit="${edit ? original.id : ""}"
  >
    <div class="wide">
      <label>Saved customer</label
      ><select id="customer-select">
        <option value="">Enter manually</option>
        ${state.customers.map((c) => html`<option value="${c.id}" ${c.id === d.customerId ? "selected" : ""}>${esc(c.name)}</option>`).join("")}
      </select>
    </div>
    ${field("customer", "Customer / organization", d.customer, "text", "required")}${field("phone", "Phone", d.phone)}${field("email", "Email", d.email, "email")}${field("title", "Project name", d.title)}${field("tenderRef", "Tender / reference", d.tenderRef)}${field("customerRef", "Customer reference", d.customerRef)}${field("dueDate", "Due date (invoice)", d.dueDate, "date")}
    <div class="wide">
      <h3>
        ${kind === "return" ? "Items to return (quantities must not exceed invoice)" : "Items and services"}
      </h3>
      <div id="lines">${lines.map(lineHTML).join("")}</div>
      <button class="secondary no-print" type="button" id="add-line">+ Add line</button>
      <p id="running-total"></p>
      <p class="muted">
        To grant a discount, enter a unit price below the saved sale price. The
        reduction will appear on the quotation or invoice. A sale below purchase cost
        requires confirmation before issue.
      </p>
    </div>
    <div class="wide">
      <label>Notes / terms</label
      ><textarea name="notes" rows="3">${esc(noteValue)}</textarea>
      ${kind !== "return" && savedNotes.length
        ? html`<label for="saved-note">Reuse a note from a previous document</label>
            <select id="saved-note"><option value="">Keep current note</option>
              ${savedNotes.map((x) => html`<option value="${x.id}">${esc(x.number)} · ${esc(x.notes.trim().slice(0, 65))}</option>`).join("")}
            </select>`
        : ""}
      ${kind !== "return" ? html`<p class="muted">Edit this note for this document. Notes you save can be reused on a later quotation or invoice.</p>` : ""}
    </div>
    ${
      kind === "return"
        ? html`<div class="wide">
            <label
              ><input type="checkbox" name="receivedBack" style="width:auto" /> Physical
              stock received back</label
            >
          </div>`
        : ""
    }<button type="submit" class="wide">
      ${edit ? "Save quotation" : kind === "invoice" ? "Issue invoice" : kind === "return" ? "Record credit note" : "Save quotation"}
    </button>
  </form>`;
}
function lineHTML(l = {}) {
  const saved = item(l.itemId),
    list = l.listPrice ?? saved?.price ?? l.price ?? 0,
    discount = list > 0 ? Math.max(0, (1 - (l.price ?? list) / list) * 100) : 0;
  return html`<div class="line">
    <div>
      <label>Saved item / description</label
      ><select class="line-item">
        <option value="">Manual entry</option>
        ${state.items
          .filter(
            (i) => (i.active && i.reviewStatus !== "pending") || i.id === l.itemId,
          )
          .map(
            (i) =>
              html`<option value="${i.id}" ${i.id === l.itemId ? "selected" : ""}>
                ${esc(i.name)} · ${esc(i.sku)}
              </option>`,
          )
          .join("")}</select
      ><input
        class="line-desc"
        value="${esc(l.description)}"
        required
        placeholder="Description"
        ${l.itemId ? "readonly" : ""}
      />
    </div>
    <div class="manual-kind" ${l.itemId ? "hidden" : ""}>
      <label>Manual entry type</label
      ><select class="line-kind">
        <option value="Product" ${l.manualKind !== "Service" ? "selected" : ""}>
          Physical product
        </option>
        <option value="Service" ${l.manualKind === "Service" ? "selected" : ""}>
          Service / labour
        </option>
      </select>
    </div>
    <div>
      <label>Quantity</label
      ><input
        class="line-qty"
        type="number"
        min="1"
        step="1"
        required
        value="${l.quantity || 1}"
      />
    </div>
    <div>
      <label>Discount %</label
      ><input
        class="line-discount"
        type="number"
        min="0"
        max="100"
        step="0.01"
        value="${discount.toFixed(2)}"
      />
    </div>
    <div>
      <label>Unit price PKR</label
      ><input
        class="line-price"
        type="number"
        min="0"
        step="0.01"
        required
        value="${rupees(l.price)}"
      />
    </div>
    <button class="secondary remove-line" type="button">×</button>
  </div>`;
}
// Printable document and action bar share the same record. The bar is hidden in print.
function documentView(d) {
  if (!d) return "<p>Document unavailable.</p>";
  const invoice = d.kind === "invoice",
    payments = state.payments.filter((p) => p.invoiceId === d.id),
    source = d.sourceId ? find(d.sourceId) : null,
    discount = d.lines.reduce(
      (a, l) => a + Math.max(0, (l.listPrice ?? l.price) - l.price) * l.quantity,
      0,
    ),
    catalogSubtotal = d.lines.reduce(
      (a, l) => a + (l.listPrice ?? l.price) * l.quantity,
      0,
    );
  return html`<div class="doc" id="print-doc">
      <header class="doc-head">
        <img src="/confix-logo.jpg" alt="CONFIX logo" />
        <div>
          <h2>CONFIX Solar Solution</h2>
          <div>Office No. 5, 6 Ali Market, Near PSO Pump, Yadgar Chowk, Gilgit</div>
          <div>+92 345 2670067 · confixprivatelimited@gmail.com</div>
        </div>
      </header>
      <div class="doc-meta">
        <div>
          <strong>${esc(d.kind.toUpperCase())} · ${esc(d.status)}</strong>
          <p>
            Customer: ${esc(d.customer)}
            ${d.phone ? html`<br />Phone: ${esc(d.phone)}` : ""}
            ${d.email ? html`<br />Email: ${esc(d.email)}` : ""}
          </p>
          ${d.title || d.tenderRef || d.customerRef
            ? html`<p>
                ${d.title ? html`Project: ${esc(d.title)}` : ""}
                ${d.tenderRef ? html`${d.title ? "<br />" : ""}Tender / reference: ${esc(d.tenderRef)}` : ""}
                ${d.customerRef ? html`${d.title || d.tenderRef ? "<br />" : ""}Customer reference: ${esc(d.customerRef)}` : ""}
              </p>`
            : ""}
        </div>
        <div>
          <strong>${esc(d.number)}</strong>
          <p>Date: ${esc(d.date)}${invoice && d.dueDate ? html`<br />Due: ${esc(d.dueDate)}` : ""}</p>
          ${source ? html`<p>Source: ${esc(source.number)}</p>` : ""}${d.convertedInvoiceId ? html`<p>Converted invoice: ${esc(find(d.convertedInvoiceId)?.number)}</p>` : ""}
        </div>
      </div>
      <table>
        <thead>
          <tr>
            <th>Description</th>
            <th>Quantity</th>
            <th>Unit price</th>
            <th>Amount</th>
          </tr>
        </thead>
        <tbody>
          ${d.lines
            .map(
              (l) =>
                html`<tr>
                  <td>${esc(l.description)}</td>
                  <td>${l.quantity}</td>
                  <td>${money(l.price)}</td>
                  <td>${money(l.quantity * l.price)}</td>
                </tr>`,
            )
            .join("")}
          <tr class="total">
            <td colspan="3">TOTAL</td>
            <td>${money(d.total)}</td>
          </tr>
        </tbody>
      </table>
      ${
        invoice
          ? html`<div class="invoice-lower">
                <section class="bank-details">
                  <div class="bank-copy">
                    <h3>Payment / Bank Details</h3>
                    <p>
                      <b>CONFIX PRIVATE LIMITED</b><br />
                      <span>Bank: Soneri Bank</span><br />
                      <span>Account: 046720016378535</span><br />
                      <span>IBAN: PK27SONE0046720016378535</span>
                    </p>
                    <small>Please quote invoice ${esc(d.number)} when making payment.</small>
                  </div>
                  <div>
                    <div class="payment-qr">
                      <img src="/payment-qr.jpg" alt="CONFIX payment QR code" />
                    </div>
                    <small class="qr-label">Scan to pay</small>
                  </div>
                </section>
                <section class="invoice-summary">
                  <h3>Invoice Summary</h3>
                  ${discount > 0 && d.lines.every((l) => l.price <= (l.listPrice ?? l.price))
                    ? html`<p>Catalog price subtotal <b>${money(catalogSubtotal)}</b></p>
                        <p>Discount on item prices <b>− ${money(discount)}</b></p>`
                    : ""}
                  <p class="summary-strong">Amount due <b>${money(d.total)}</b></p>
                  <p>Total invoice amount <b>${money(d.total)}</b></p>
                  ${d.creditTotal ? html`<p>Credit notes <b>${money(d.creditTotal)}</b></p>` : ""}
                  <p>Amount paid (net) <b>${money(d.paidTotal)}</b></p>
                  <p class="summary-balance">Balance receivable <b>${money(balance(d))}</b></p>
                </section>
              </div>
              ${
                payments.length
                  ? html`<section class="payment-history">
                      <h3>Payment History</h3>
                      <table>
                        <thead><tr><th>Date</th><th>Receipt No.</th><th>Method</th><th>Status</th><th>Amount</th></tr></thead>
                        <tbody>${payments.map((p) => html`<tr><td>${esc(p.date)}</td><td>${esc(p.number)}</td><td>${esc(p.method)}</td><td>${p.type === "refund" ? "Refund" : "Received"}</td><td>${money(p.amount)}</td></tr>`).join("")}</tbody>
                      </table>
                    </section>`
                  : ""
              }
              ${(() => {
                const credits = state.documents.filter((r) => r.kind === "return" && r.sourceId === d.id && r.status !== "void");
                return credits.length
                  ? html`<section class="payment-history return-history">
                      <h3>Sales Return History</h3>
                      <table>
                        <thead><tr><th>Date</th><th>Credit Note</th><th>Stock status</th><th>Amount</th></tr></thead>
                        <tbody>${credits.map((r) => html`<tr><td>${esc(r.date)}</td><td>${esc(r.number)}</td><td>${r.receivedBack ? "Received & restocked" : "Stock pending"}</td><td>${money(r.total)}</td></tr>`).join("")}</tbody>
                      </table>
                    </section>`
                  : "";
              })()}`
          : ""
      }
      ${d.kind === "return"
        ? html`<p class="return-stock-status"><b>Physical stock:</b> ${d.receivedBack ? "Received & restocked" : "Pending receipt — credit note recorded, inventory not yet increased"}</p>`
        : ""}
      ${d.notes ? html`<p>Notes / terms: ${esc(d.notes)}</p>` : ""}
      <p class="doc-credit">
        Developed and designed by Barcha Technologies · 03555-555174 ·
        zuhaibnasirbarcha@gmail.com
      </p>
    </div>
    <div class="actions no-print" style="padding:16px 0">
      <button id="print">Print / Save PDF</button
      ><button class="secondary" id="email">Email</button
      ><button class="secondary" id="whatsapp">WhatsApp</button
      >${documentActions(d, invoice)}
    </div>`;
}
// Keep record actions outside the printable document template. CSS hides this bar in print.
function documentActions(d, invoice) {
  const actions = [];
  if (d.kind === "quotation" && d.status !== "void") {
    actions.push(
      html`<button class="secondary" data-open="quotation:${d.id}:reuse">
        Reuse
      </button>`,
    );
    if (!d.convertedInvoiceId) {
      actions.push(
        html`<button class="secondary" data-open="quotation:${d.id}:edit">
          Edit
        </button>`,
      );
      for (const status of ["Draft", "Submitted", "Approved", "Rejected", "Expired"]) {
        actions.push(
          html`<button class="secondary" data-status="${d.id}:${status}">
            ${status}
          </button>`,
        );
      }
      actions.push(
        html`<button data-open="invoice:${d.id}">Convert to invoice</button>`,
      );
    }
  }
  if (invoice && d.status !== "void") {
    if (balance(d) > 0 || d.paidTotal > d.total - d.creditTotal)
      actions.push(html`<button data-open="payment:${d.id}">Record payment / refund</button>`);
    actions.push(html`<button data-open="return:${d.id}">Sales return</button>`);
  }
  if (
    role === "admin" &&
    d.kind === "return" &&
    d.status !== "void" &&
    !d.receivedBack &&
    d.lines.some((l) =>
      l.itemId && (l.tracked || (l.manualOrigin && l.manualKind !== "Service")),
    )
  ) {
    actions.push(
      html`<button data-receive-return="${d.id}">Mark goods received & restock</button>`,
    );
  }
  if (role === "admin" && d.status !== "void" && d.kind !== "return") {
    actions.push(html`<button class="danger" data-void="${d.id}">Void</button>`);
  }
  return actions.join("");
}

function bind() {
  document.querySelectorAll("[data-tab]").forEach(
    (b) =>
      (b.onclick = () => {
        tab = b.dataset.tab;
        needle = "";
        filter = "";
        render();
      }),
  );
  document.querySelectorAll("[data-goto]").forEach(
    (b) =>
      (b.onclick = () => {
        tab = b.dataset.goto;
        filter = b.dataset.filter;
        needle = "";
        render();
      }),
  );
  document.querySelectorAll("[data-open]").forEach(
    (b) =>
      (b.onclick = () => {
        modal = b.dataset.open;
        render();
      }),
  );
  $("#close")?.addEventListener("click", () => {
    modal = "";
    render();
  });
  $("#search")?.addEventListener("input", (e) => {
    needle = e.target.value;
    const start = e.target.selectionStart;
    $("#content").innerHTML = content();
    bind();
    $("#search")?.focus();
    $("#search")?.setSelectionRange(start, start);
  });
  $("#filter")?.addEventListener("change", (e) => {
    filter = e.target.value;
    $("#content").innerHTML = content();
    bind();
  });
  $("#logout").onclick = signOut;
  $("#backup")?.addEventListener("click", () => {
    location.href = "/api/backup";
  });
  document.querySelectorAll("[data-archive]").forEach(
    (b) =>
      (b.onclick = () => {
        if (confirm("Archive this item? It remains in history."))
          action(() => api("items/" + b.dataset.archive + "/archive", "POST", {}));
      }),
  );
  document.querySelectorAll("[data-void]").forEach(
    (b) =>
      (b.onclick = () => {
        if (
          confirm(
            "Void this document? Linked payments and returns must be resolved first.",
          )
        )
          action(() => api("documents/" + b.dataset.void + "/void", "POST", {}));
      }),
  );
  document.querySelectorAll("[data-receive-return]").forEach(
    (b) =>
      (b.onclick = () => {
        if (
          confirm(
            "Confirm that the physical returned goods have actually been received? Stock will be increased once and this action is audit logged.",
          )
        )
          action(() => api("returns/" + b.dataset.receiveReturn + "/receive-stock", "POST", {}));
      }),
  );
  document.querySelectorAll("[data-status]").forEach(
    (b) =>
      (b.onclick = () => {
        const [id, status] = b.dataset.status.split(":");
        action(() => api("quotations/" + id, "PATCH", { status }));
      }),
  );
  $("#print")?.addEventListener("click", () => window.print());
  const view = modal?.startsWith("view:") ? find(modal.split(":")[1]) : null;
  $("#email")?.addEventListener("click", () => {
    const subject = `${view.kind === "invoice" ? "Invoice" : "Quotation"} from CONFIX Solar Solution – ${view.number}`,
      message = `Dear ${view.customer},\n\nPlease find ${view.number} from CONFIX Solar Solution. Kindly attach the PDF saved using Print / Save PDF before sending.\n\nRegards,\nCONFIX Solar Solution`;
    location.href = `mailto:${encodeURIComponent(view.email || "")}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(message)}`;
  });
  $("#whatsapp")?.addEventListener("click", () => {
    const msg = `Dear ${view.customer}, please find ${view.kind} ${view.number} from CONFIX Solar Solution. Please attach the PDF saved using Print / Save PDF.`;
    window.open("https://wa.me/?text=" + encodeURIComponent(msg), "_blank", "noopener");
  });
  const f = $("#form");
  if (f) {
    f.onsubmit = (e) => {
      e.preventDefault();
      submitForm(f);
    };
    $("#add-line")?.addEventListener("click", () => {
      $("#lines").insertAdjacentHTML("beforeend", lineHTML());
      bindLines();
    });
    $("#customer-select")?.addEventListener("change", (e) => {
      const c = state.customers.find((c) => c.id === e.target.value);
      if (c)
        for (const key of ["name", "phone", "email"])
          f.elements[key === "name" ? "customer" : key].value = c[key] || "";
    });
    $("#saved-note")?.addEventListener("change", (e) => {
      const selected = find(e.target.value);
      if (selected) f.elements.notes.value = selected.notes || "";
    });
    $("#payment-type")?.addEventListener("change", (e) => {
      const invoice = find(modal.split(":")[1]);
      const refundable = Math.max(0, invoice.paidTotal - (invoice.total - invoice.creditTotal));
      const amount = rupees(e.target.value === "refund" ? refundable : balance(invoice));
      f.elements.amount.value = amount;
      f.elements.amount.max = amount;
    });
    bindLines();
  }
}
function bindLines() {
  document.querySelectorAll(".line-item").forEach(
    (el) =>
      (el.onchange = () => {
        const i = item(el.value),
          row = el.closest(".line"),
          desc = row.querySelector(".line-desc"),
          kind = row.querySelector(".manual-kind"),
          discount = row.querySelector(".line-discount");
        if (i) {
          desc.value = i.name;
          desc.readOnly = true;
          kind.hidden = true;
          discount.disabled = false;
          row.querySelector(".line-price").value = rupees(i.price);
          discount.value = "0.00";
        } else {
          desc.value = "";
          desc.readOnly = false;
          kind.hidden = false;
          discount.value = "0.00";
          discount.disabled = true;
        }
        calc();
      }),
  );
  document.querySelectorAll(".line-desc").forEach(
    (el) =>
      (el.oninput = () => {
        const row = el.closest(".line"),
          selection = row.querySelector(".line-item");
        if (selection.value) {
          selection.value = "";
          row.querySelector(".manual-kind").hidden = false;
          row.querySelector(".line-discount").value = "0.00";
          row.querySelector(".line-discount").disabled = true;
        }
      }),
  );
  document.querySelectorAll(".remove-line").forEach(
    (el) =>
      (el.onclick = () => {
        if (document.querySelectorAll(".line").length > 1) {
          el.closest(".line").remove();
          calc();
        }
      }),
  );
  document.querySelectorAll(".line-discount").forEach(
    (el) =>
      (el.oninput = () => {
        const row = el.closest(".line"),
          saved = item(row.querySelector(".line-item").value);
        if (saved) {
          const pct = Number(el.value);
          if (pct >= 0 && pct <= 100)
            row.querySelector(".line-price").value = (
              rupees(saved.price) *
              (1 - pct / 100)
            ).toFixed(2);
        }
        calc();
      }),
  );
  document.querySelectorAll(".line-price").forEach(
    (el) =>
      (el.oninput = () => {
        const row = el.closest(".line"),
          saved = item(row.querySelector(".line-item").value);
        if (saved && saved.price > 0)
          row.querySelector(".line-discount").value = Math.max(
            0,
            (1 - minor(el.value) / saved.price) * 100,
          ).toFixed(2);
        calc();
      }),
  );
  document.querySelectorAll(".line-qty").forEach((el) => (el.oninput = calc));
  document.querySelectorAll(".line").forEach((row) => {
    row.querySelector(".line-discount").disabled =
      !row.querySelector(".line-item").value;
  });
  calc();
}
function calc() {
  const total = [...document.querySelectorAll(".line")].reduce(
    (a, r) =>
      a +
      Number(r.querySelector(".line-qty").value || 0) *
        Number(r.querySelector(".line-price").value || 0),
    0,
  );
  if ($("#running-total"))
    $("#running-total").textContent =
      "Total: PKR " + total.toLocaleString("en-PK", { minimumFractionDigits: 2 });
}
// Convert form money from PKR to integer paisa before sending to the server.
async function submitForm(f) {
  const [kind, id, lineIndex] = modal.split(":"),
    data = Object.fromEntries(new FormData(f));
  if (kind === "pricing")
    return action(() =>
      api(`invoices/${id}/lines/${lineIndex}/resolve-pricing`, "POST", {
        category: data.category,
        purchasePrice: minor(data.purchasePrice),
        salePrice: minor(data.salePrice),
        confirmZeroCost: data.confirmZeroCost === "on",
        confirmBelowCost: data.confirmBelowCost === "on",
      }),
    );
  if (kind === "recoverykey") {
    try { const result = await api("users/recovery-key", "POST", {}); modal = ""; showRecoveryKey(result.recoveryKey); }
    catch (e) { notice(e.message, true); }
    return;
  }
  if (kind === "employee") return action(() => api("users/employee", "POST", data));
  if (kind === "expense")
    return action(() =>
      api("expenses", "POST", { ...data, amount: minor(data.amount) }),
    );
  if (kind === "item")
    return action(() =>
      api("items" + (id ? "/" + id : ""), id ? "PATCH" : "POST", {
        ...data,
        trackStock: data.trackStock === "1",
        price: minor(data.price),
        purchasePrice: minor(data.purchasePrice),
        lowStock: Number(data.lowStock),
      }),
    );
  if (kind === "customer")
    return action(() =>
      api("customers" + (id ? "/" + id : ""), id ? "PATCH" : "POST", data),
    );
  if (kind === "stock") {
    const current = item(id),
      n = Number(data.quantity),
      quantity =
        data.movement === "adjust"
          ? n - current.stock
          : data.movement === "out"
            ? -n
            : n;
    if (!quantity) return notice("Stock already equals this quantity.", true);
    return action(() =>
      api(`items/${id}/stock`, "POST", {
        quantity,
        reason: data.reason,
        reference: data.reference,
      }),
    );
  }
  if (kind === "payment")
    return action(() =>
      api(`invoices/${id}/payments`, "POST", { ...data, amount: minor(data.amount) }),
    );
  if (["quotation", "invoice", "return"].includes(kind)) {
    const lines = [...f.querySelectorAll(".line")].map((r) => ({
      itemId: r.querySelector(".line-item").value,
      description: r.querySelector(".line-desc").value,
      manualKind: r.querySelector(".line-kind").value,
      quantity: Number(r.querySelector(".line-qty").value),
      price: minor(r.querySelector(".line-price").value),
    }));
    const doc = {
      ...data,
      customerId: $("#customer-select")?.value || "",
      kind,
      sourceId: f.dataset.source || "",
      receivedBack: !!f.elements.receivedBack?.checked,
      lines,
    };
    delete doc.trackStock;
    return action(async () => {
      if (f.dataset.edit) await api("quotations/" + f.dataset.edit, "PATCH", doc);
      else if (kind === "invoice") {
        try {
          await api("documents", "POST", doc);
        } catch (err) {
          if (
            role === "admin" &&
            err.message.includes("priced below their purchase cost") &&
            confirm(err.message + "\n\nIssue this invoice anyway?")
          )
            await api("documents", "POST", { ...doc, confirmLowPrice: true });
          else throw err;
        }
      } else await api("documents", "POST", doc);
    });
  }
}
boot();
