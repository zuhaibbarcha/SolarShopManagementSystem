import test from "node:test";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
const root = resolve(import.meta.dirname, ".."),
  seed = resolve(root, "sample-data/seed-demo.mjs");
test("demo SQL and five complete transaction flows", async () => {
  const dir = await mkdtemp(join(tmpdir(), "confix-demo-")),
    port = 45000 + Math.floor(Math.random() * 5000),
    base = `http://127.0.0.1:${port}`,
    env = { ...process.env, CONFIX_DATA_DIR: dir, PORT: String(port) };
  let server,
    csrf = "",
    cookie = "";
  const start = async () => {
      server = spawn(process.execPath, [join(root, "server.mjs")], { env });
      for (let i = 0; i < 100; i++) {
        try {
          if ((await fetch(base + "/api/session")).ok) return;
        } catch {}
        await new Promise((r) => setTimeout(r, 50));
      }
      throw Error("Server did not start");
    },
    stop = () =>
      new Promise((done) => {
        server.once("exit", done);
        server.kill("SIGTERM");
      });
  const call = async (path, method = "GET", body, expected = 200) => {
    const res = await fetch(base + "/api/" + path, {
        method,
        headers: {
          cookie,
          "x-csrf-token": csrf,
          ...(body ? { "content-type": "application/json" } : {}),
        },
        body: body ? JSON.stringify(body) : undefined,
      }),
      data = await res.json();
    assert.equal(res.status, expected, `${path}: ${JSON.stringify(data)}`);
    return data;
  };
  try {
    await start();
    const setup = await fetch(base + "/api/setup", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        username: "test-admin",
        password: "Strong demo password 1234",
      }),
    });
    assert.equal(setup.status, 200);
    cookie = setup.headers.get("set-cookie").split(";")[0];
    csrf = (await setup.json()).csrf;
    await stop();
    const seeded = spawn(process.execPath, [seed], { env });
    let stderr = "";
    seeded.stderr.on("data", (b) => (stderr += b));
    assert.equal(await new Promise((done) => seeded.once("exit", done)), 0, stderr);
    const again = spawn(process.execPath, [seed], { env });
    assert.notEqual(
      await new Promise((done) => again.once("exit", done)),
      0,
      "second seed must refuse duplicates",
    );
    await start();
    let state = await call("state");
    assert.equal(state.items.length, 25);
    assert.equal(state.customers.length, 5);
    assert.equal(state.movements.length, 20);
    assert.equal(state.audit.filter((a) => a.actor === "demo-seed").length, 30);
    for (const category of ["Solar panel", "Inverter", "Battery", "Service", "Other"])
      assert.equal(state.items.filter((i) => i.category === category).length, 5);
    const items = Object.fromEntries(state.items.map((i) => [i.sku, i]));
    const invoices = [];
    const expected = [271500, 336200, 383600, 413700, 504850];
    let returnTotal = 0;
    for (let i = 1; i <= 5; i++) {
      const sku = (n) => `DEMO-${n}-${String(i).padStart(2, "0")}`;
      const lines = [
        ["PNL", 2],
        ["INV", 1],
        ["BAT", 1],
        ["SRV", 1],
        ["OTH", 1],
      ].map(([prefix, quantity]) => {
        const x = items[sku(prefix)];
        return { itemId: x.id, description: x.name, quantity, price: x.price };
      });
      const c = state.customers.find(
        (c) => c.id === `demo-customer-${String(i).padStart(2, "0")}`,
      );
      const quote = await call(
        "documents",
        "POST",
        {
          kind: "quotation",
          customer: c.name,
          customerId: c.id,
          email: c.email,
          title: `TEST TENDER ${i}`,
          tenderRef: `DEMO-2026-${i}`,
          lines,
        },
        201,
      );
      assert.equal(quote.total, expected[i - 1] * 100);
      state = await call("state");
      assert.equal(
        state.items.find((x) => x.id === lines[0].itemId).stock,
        20,
        "quotation must not deduct stock",
      );
      await call(`quotations/${quote.id}`, "PATCH", { status: "Submitted" });
      await call(`quotations/${quote.id}`, "PATCH", { status: "Approved" });
      const invoice = await call(
        "documents",
        "POST",
        {
          kind: "invoice",
          sourceId: quote.id,
          customer: quote.customer,
          customerId: c.id,
          email: c.email,
          title: quote.title,
          tenderRef: quote.tenderRef,
          lines: quote.lines,
        },
        201,
      );
      invoices.push(invoice);
      state = await call("state");
      assert.equal(
        state.documents.find((x) => x.id === quote.id).convertedInvoiceId,
        invoice.id,
      );
      assert.equal(state.items.find((x) => x.id === lines[0].itemId).stock, 18);
      assert.equal(state.items.find((x) => x.id === lines[3].itemId).stock, 0);
      assert.equal(
        invoice.lines[3].costPrice,
        [250000, 700000, 900000, 250000, 400000][i - 1],
        "service cost must be saved on the invoice",
      );
      for (let j = 0; j < 4; j++)
        await call(
          `invoices/${invoice.id}/payments`,
          "POST",
          {
            amount: invoice.total / 4,
            method: "Bank",
            reference: `DEMO-PAY-${i}-${j + 1}`,
          },
          201,
        );
      state = await call("state");
      assert.equal(
        state.documents.find((x) => x.id === invoice.id).paidTotal,
        invoice.total,
      );
      const ret = await call(
        "documents",
        "POST",
        {
          kind: "return",
          sourceId: invoice.id,
          customer: invoice.customer,
          lines: [{ ...invoice.lines[0], quantity: 1 }],
          receivedBack: true,
        },
        201,
      );
      returnTotal += ret.total;
      await call(
        `invoices/${invoice.id}/payments`,
        "POST",
        {
          type: "refund",
          amount: ret.total,
          method: "Bank",
          reference: `DEMO-REFUND-${i}`,
        },
        201,
      );
      state = await call("state");
      const finalInvoice = state.documents.find((x) => x.id === invoice.id);
      assert.equal(
        finalInvoice.total - finalInvoice.creditTotal - finalInvoice.paidTotal,
        0,
      );
      assert.equal(state.items.find((x) => x.id === lines[0].itemId).stock, 19);
      console.log(
        `Case ${i}: invoice PKR ${invoice.total / 100}, ` +
          `return PKR ${ret.total / 100}, panel stock 19, ` +
          `four receipts, one refund, balance 0`,
      );
    }
    state = await call("state");
    assert.equal(state.documents.filter((d) => d.kind === "quotation").length, 5);
    assert.equal(state.documents.filter((d) => d.kind === "invoice").length, 5);
    assert.equal(state.documents.filter((d) => d.kind === "return").length, 5);
    assert.equal(state.payments.filter((p) => p.type === "payment").length, 20);
    assert.equal(state.payments.filter((p) => p.type === "refund").length, 5);
    assert.equal(
      invoices.reduce((n, d) => n + d.total, 0),
      190985000,
    );
    assert.equal(returnTotal, 24600000);
    const savedCosts = state.documents
      .filter((d) => d.kind === "invoice")
      .reduce(
        (sum, d) =>
          sum +
          d.lines.reduce(
            (lineSum, line) => lineSum + line.quantity * line.costPrice,
            0,
          ),
        0,
      );
    const restockedCosts = state.documents
      .filter((d) => d.kind === "return" && d.receivedBack)
      .reduce(
        (sum, d) =>
          sum +
          d.lines.reduce(
            (lineSum, line) =>
              lineSum + (line.tracked ? line.quantity * line.costPrice : 0),
            0,
          ),
        0,
      );
    assert.equal(savedCosts, 137830000);
    assert.equal(restockedCosts, 17600000);
    assert.equal(190985000 - returnTotal - savedCosts + restockedCosts, 46155000);
    assert.equal(
      state.documents
        .filter((d) => d.kind === "invoice")
        .reduce((n, d) => n + Math.max(0, d.total - d.creditTotal - d.paidTotal), 0),
      0,
    );
    await stop();
    const verifier = spawn(
      process.execPath,
      [resolve(root, "sample-data/verify-demo.mjs")],
      { env },
    );
    let report = "";
    verifier.stdout.on("data", (b) => (report += b));
    assert.equal(await new Promise((done) => verifier.once("exit", done)), 0);
    assert(report.includes("PKR 0.00"));
    assert(report.includes("Integrity: ok"));
    await start();
    assert.equal(
      (await call("state")).documents.filter((d) => d.kind === "return").length,
      5,
    );
    console.log(
      "Demo seed: 25 items, 5 customers, 5 quotations, 5 invoices, 20 installments, 5 returns/refunds verified after restart.",
    );
  } finally {
    if (server && server.exitCode === null) await stop().catch(() => {});
    await rm(dir, { recursive: true, force: true });
  }
});
