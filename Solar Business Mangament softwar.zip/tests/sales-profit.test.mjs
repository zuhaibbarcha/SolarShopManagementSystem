import test from "node:test";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { mkdtemp, rm, readFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import vm from "node:vm";

const root = resolve(import.meta.dirname, "..");
const source = await readFile(join(root, "public/app.js"), "utf8");
const functionText = source.slice(
  source.indexOf("function profitSummary()"),
  source.indexOf("\nfunction overview()"),
);
function calculate(documents, expenses = []) {
  const context = { state: { documents, expenses } };
  vm.runInNewContext(
    `const docs=k=>state.documents.filter(d=>d.kind===k&&d.status!=='void');${functionText};result=profitSummary()`,
    context,
  );
  return context.result;
}
const invoice = (lines, total) => ({ kind: "invoice", status: "Issued", lines, total });
const credit = (lines, total, receivedBack) => ({
  kind: "return",
  status: "Issued",
  lines,
  total,
  receivedBack,
});

test("white box: discounted product and service costs, expenses only affect net", () => {
  const d = [
    invoice(
      [
        { itemId: "panel", tracked: true, quantity: 2, costPrice: 1200000 },
        { itemId: "service", tracked: false, quantity: 1, costPrice: 200000 },
      ],
      4000000,
    ),
  ];
  const p = calculate(d, [{ amount: 150000 }]);
  assert.equal(p.salesProfit, 1400000);
  assert.equal(p.netProfit, 1250000);
  assert.equal(p.incomplete, false);
});
test("white box: only a physical restock restores its cost", () => {
  const lines = [
    { itemId: "panel", tracked: true, quantity: 1, costPrice: 600000 },
    { itemId: "visit", tracked: false, quantity: 1, costPrice: 100000 },
  ];
  const base = invoice(lines, 1000000),
    returns = [credit(lines, 800000, true)];
  const p = calculate([base, ...returns]);
  assert.equal(p.restockedCost, 600000);
  assert.equal(p.salesProfit, 100000);
  const noStock = calculate([base, credit(lines, 800000, false)]);
  assert.equal(noStock.salesProfit, -500000);
});
test("white box: legacy missing costs signal incomplete and voids are ignored", () => {
  const p = calculate([
    invoice([{ itemId: "old", quantity: 1 }], 500000),
    {
      ...invoice([{ itemId: "void", quantity: 1, costPrice: 100 }], 900000),
      status: "void",
    },
  ]);
  assert.equal(p.incomplete, true);
  assert.equal(p.sales, 500000);
});

test("manual stock return stays incomplete until its cost is confirmed", () => {
  const pending = [
    {
      kind: "invoice",
      status: "Issued",
      total: 4000000,
      lines: [
        {
          itemId: "manual-1",
          manualOrigin: true,
          manualKind: "Product",
          tracked: false,
          quantity: 2,
          costPrice: null,
        },
      ],
    },
    {
      kind: "return",
      status: "Issued",
      total: 2000000,
      receivedBack: true,
      lines: [
        {
          itemId: "manual-1",
          manualOrigin: true,
          manualKind: "Product",
          tracked: false,
          quantity: 1,
          costPrice: null,
        },
      ],
    },
  ];
  assert.equal(calculate(pending).incomplete, true);
  pending[0].lines[0].costPrice = 1200000;
  pending[1].lines[0].costPrice = 1200000;
  const reviewed = calculate(pending);
  assert.equal(reviewed.incomplete, false);
  assert.equal(reviewed.restockedCost, 1200000);
  assert.equal(reviewed.salesProfit, 800000);
});

test("black box: missed restock can be resolved once without recreating the credit note", async () => {
  const dir = await mkdtemp(join(tmpdir(), "confix-return-receipt-")),
    port = 56000 + Math.floor(Math.random() * 8000),
    base = `http://127.0.0.1:${port}`;
  const server = spawn(process.execPath, [join(root, "server.mjs")], {
    env: { ...process.env, PORT: String(port), CONFIX_DATA_DIR: dir },
  });
  let cookie = "", csrf = "";
  async function call(path, method = "GET", data, expected = 200) {
    const r = await fetch(base + "/api/" + path, {
      method,
      headers: { cookie, "x-csrf-token": csrf, "content-type": "application/json" },
      body: data ? JSON.stringify(data) : undefined,
    });
    const value = await r.json();
    assert.equal(r.status, expected, `${path}: ${JSON.stringify(value)}`);
    return { value, headers: r.headers };
  }
  try {
    for (let i = 0; i < 100; i++) {
      try { if ((await fetch(base + "/api/session")).ok) break; } catch {}
      await new Promise((r) => setTimeout(r, 50));
    }
    const setup = await call("setup", "POST", { username: "owner", password: "administrator123" });
    cookie = setup.headers.get("set-cookie").split(";")[0]; csrf = setup.value.csrf;
    const item = (await call("items", "POST", {
      name: "Return test panel", sku: "RET-1", category: "Solar panel", unit: "piece",
      purchasePrice: 600000, price: 800000, trackStock: true,
    }, 201)).value;
    await call(`items/${item.id}/stock`, "POST", { quantity: 2, reason: "Opening test stock" });
    const inv = (await call("documents", "POST", {
      kind: "invoice", customer: "Return Test", lines: [
        { itemId: item.id, description: item.name, quantity: 1, price: 800000 },
      ],
    }, 201)).value;
    const ret = (await call("documents", "POST", {
      kind: "return", sourceId: inv.id, customer: "Return Test", receivedBack: false,
      lines: [{ ...inv.lines[0], quantity: 1 }],
    }, 201)).value;
    let state = (await call("state")).value;
    assert.equal(state.items.find((i) => i.id === item.id).stock, 1, "credit alone does not restock");
    assert.equal(calculate(state.documents).salesProfit, -600000, "COGS stays charged until goods arrive");
    const received = (await call(`returns/${ret.id}/receive-stock`, "POST", {})).value;
    assert.equal(received.receivedBack, true);
    state = (await call("state")).value;
    assert.equal(state.items.find((i) => i.id === item.id).stock, 2, "later receipt restores stock once");
    assert.equal(calculate(state.documents).salesProfit, 0, "receiving returned goods restores their COGS");
    assert.ok(state.audit.some((a) => a.action === "Returned stock received after credit note"));
    assert.ok(state.movements.some((m) => m.documentId === ret.id && m.delta === 1));
    await call(`returns/${ret.id}/receive-stock`, "POST", {}, 409);
    state = (await call("state")).value;
    assert.equal(state.items.find((i) => i.id === item.id).stock, 2, "duplicate receipt cannot double-restock");
  } finally {
    server.kill("SIGTERM");
    await new Promise((done) => server.once("exit", done));
    await rm(dir, { recursive: true, force: true });
  }
});

test("black box: realistic stock, quotation, invoice, partial return, expense and audit", async () => {
  const dir = await mkdtemp(join(tmpdir(), "confix-profit-")),
    port = 46000 + Math.floor(Math.random() * 10000),
    base = `http://127.0.0.1:${port}`;
  const server = spawn(process.execPath, [join(root, "server.mjs")], {
    env: { ...process.env, PORT: String(port), CONFIX_DATA_DIR: dir },
  });
  let cookie = "",
    csrf = "";
  async function call(path, method = "GET", data, expected = 200) {
    const r = await fetch(base + "/api/" + path, {
      method,
      headers: { cookie, "x-csrf-token": csrf, "content-type": "application/json" },
      body: data ? JSON.stringify(data) : undefined,
    });
    const value = await r.json();
    assert.equal(r.status, expected, `${path}: ${JSON.stringify(value)}`);
    return { value, headers: r.headers };
  }
  try {
    for (let i = 0; i < 100; i++) {
      try {
        if ((await fetch(base + "/api/session")).ok) break;
      } catch {}
      await new Promise((r) => setTimeout(r, 50));
    }
    const setup = await call("setup", "POST", {
      username: "owner",
      password: "administrator123",
    });
    cookie = setup.headers.get("set-cookie").split(";")[0];
    csrf = setup.value.csrf;
    const panel = (
      await call(
        "items",
        "POST",
        {
          name: "550 W monocrystalline solar panel",
          sku: "CSS-PV-550",
          category: "Solar panel",
          unit: "piece",
          purchasePrice: 1200000,
          price: 2000000,
          trackStock: true,
        },
        201,
      )
    ).value;
    const service = (
      await call(
        "items",
        "POST",
        {
          name: "Inverter installation and commissioning",
          sku: "CSS-SVC-INV",
          category: "Service",
          unit: "job",
          purchasePrice: 200000,
          price: 500000,
          trackStock: false,
        },
        201,
      )
    ).value;
    assert.equal(
      (
        await call(`items/${panel.id}/stock`, "POST", {
          quantity: 5,
          reason: "Supplier delivery",
        })
      ).value.stock,
      5,
    );
    const customer = (
      await call("customers", "POST", {
        name: "Gilgit Model School",
        phone: "03555666444",
      })
    ).value;
    const lines = [
      { itemId: panel.id, description: panel.name, quantity: 2, price: 1800000 },
      { itemId: service.id, description: service.name, quantity: 1, price: 400000 },
    ];
    const quote = (
      await call(
        "documents",
        "POST",
        { kind: "quotation", customer: customer.name, customerId: customer.id, lines },
        201,
      )
    ).value;
    assert.equal(
      (await call("state")).value.items.find((i) => i.id === panel.id).stock,
      5,
      "quote leaves stock intact",
    );
    const inv = (
      await call(
        "documents",
        "POST",
        {
          kind: "invoice",
          sourceId: quote.id,
          customer: customer.name,
          customerId: customer.id,
          lines,
        },
        201,
      )
    ).value;
    let state = (await call("state")).value;
    assert.equal(state.items.find((i) => i.id === panel.id).stock, 3);
    assert.equal(state.items.find((i) => i.id === service.id).stock, 0);
    assert.equal(inv.lines[1].costPrice, 200000, "service cost snapshot");
    assert.equal(
      calculate(state.documents, state.expenses).salesProfit,
      1400000,
      "discount included in sale price",
    );
    await call(
      `invoices/${inv.id}/payments`,
      "POST",
      { amount: 1000000, method: "Bank" },
      201,
    );
    assert.equal(
      (await call("state")).value.documents.find((d) => d.id === inv.id).paidTotal,
      1000000,
    );
    const ret = (
      await call(
        "documents",
        "POST",
        {
          kind: "return",
          sourceId: inv.id,
          customer: customer.name,
          lines: [{ ...inv.lines[0], quantity: 1 }],
          receivedBack: true,
        },
        201,
      )
    ).value;
    state = (await call("state")).value;
    assert.equal(ret.total, 1800000);
    assert.equal(state.items.find((i) => i.id === panel.id).stock, 4);
    assert.equal(calculate(state.documents, state.expenses).salesProfit, 800000);
    await call(
      "expenses",
      "POST",
      { date: "2026-09-26", category: "Fuel for school visit", amount: 150000 },
      201,
    );
    state = (await call("state")).value;
    assert.equal(calculate(state.documents, state.expenses).salesProfit, 800000);
    assert.equal(calculate(state.documents, state.expenses).netProfit, 650000);
    assert.ok(state.audit.some((a) => a.action === "Sales return recorded"));
    assert.ok(state.movements.some((m) => m.delta === 1 && m.itemId === panel.id));
    assert.equal(
      (
        await call(`items/${panel.id}/stock`, "POST", {
          quantity: -1,
          reason: "Damaged during storage",
        })
      ).value.stock,
      3,
    );
    assert.equal(
      (
        await call(`items/${panel.id}/stock`, "POST", {
          quantity: 2,
          reason: "Supplier replacement",
        })
      ).value.stock,
      5,
    );
  } finally {
    server.kill("SIGTERM");
    await new Promise((done) => server.once("exit", done));
    await rm(dir, { recursive: true, force: true });
  }
});
