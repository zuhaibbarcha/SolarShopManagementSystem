import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import vm from "node:vm";

const source = readFileSync(new URL("../public/app.js", import.meta.url), "utf8");
const defaults = source.slice(
  source.indexOf("const standardNotes ="),
  source.indexOf("const $ ="),
);
const forms = source.slice(
  source.indexOf("function field("),
  source.indexOf("function lineHTML("),
);

function render(records, modal) {
  const state = { documents: records, customers: [], items: [] };
  const context = {
    state,
    modal,
    role: "admin",
    result: "",
    html: (strings, ...values) => strings.reduce(
      (out, part, i) => out + part + (i < values.length ? values[i] : ""),
      "",
    ),
    esc: (s) => String(s ?? "").replaceAll("&", "&amp;").replaceAll('"', "&quot;").replaceAll("<", "&lt;"),
    find: (id) => records.find((x) => x.id === id),
    item: () => null,
    lineHTML: () => "<div class=\"line\"></div>",
    balance: (d) => Math.max(0, d.total - d.creditTotal - d.paidTotal),
    rupees: (n) => Number(n || 0) / 100,
    money: (n) => `PKR ${(Number(n || 0) / 100).toFixed(2)}`,
    today: () => "2026-09-27",
  };
  vm.runInNewContext(`${defaults}\n${forms}\nresult=modalContent()`, context);
  return context.result;
}

test("short document notes persist as editable text and prior custom notes are reusable", () => {
  const fresh = render([], "quotation");
  assert.match(fresh, /Prices are valid for 15 days, subject to stock availability/);
  const quote = {
    id: "q1", kind: "quotation", number: "QTN-1", status: "Approved",
    notes: "Prices are valid for 15 days, subject to stock availability.",
    customer: "Example", lines: [],
  };
  assert.match(render([quote], "invoice:q1"), /Please quote the invoice number when paying/);
  const custom = { ...quote, id: "q2", number: "QTN-2", notes: "Site access by prior appointment." };
  const reused = render([custom], "quotation");
  assert.match(reused, /Reuse a note from a previous document/);
  assert.match(reused, /value="q2"/);
  assert.match(render([custom], "invoice:q2"), /Site access by prior appointment/);
});

test("payment amount starts at the remaining balance, or the refund after a credit", () => {
  const invoice = {
    id: "i1", number: "INV-1", kind: "invoice", status: "Issued",
    total: 27150000, paidTotal: 0, creditTotal: 0,
  };
  assert.match(render([invoice], "payment:i1"), /name="amount" type="number" value="271500"/);
  assert.match(render([{ ...invoice, paidTotal: 10000000 }], "payment:i1"), /name="amount" type="number" value="171500"/);
  const refunded = render([{ ...invoice, paidTotal: 27150000, creditTotal: 4200000 }], "payment:i1");
  assert.match(refunded, /value="refund" selected/);
  assert.match(refunded, /name="amount" type="number" value="42000"/);
});
