import test from "node:test";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { mkdtemp, readFile, writeFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { DatabaseSync } from "node:sqlite";
const root = resolve(import.meta.dirname, ".."),
  dir = await mkdtemp(join(tmpdir(), "confix-flow-")),
  port = 44000 + Math.floor(Math.random() * 10000),
  base = `http://127.0.0.1:${port}`,
  env = { ...process.env, PORT: String(port), CONFIX_DATA_DIR: dir };
let proc = spawn(process.execPath, [join(root, "server.mjs")], { env });
let cookie = "",
  csrf = "";
async function ready() {
  for (let i = 0; i < 100; i++) {
    try {
      const r = await fetch(base + "/api/session");
      if (r.ok) return;
    } catch {}
    await new Promise((r) => setTimeout(r, 50));
  }
  throw Error("Server did not start");
}
async function request(path, method = "GET", data, expected = 200) {
  const r = await fetch(base + "/api/" + path, {
    method,
    headers: {
      cookie,
      "x-csrf-token": csrf,
      ...(data ? { "content-type": "application/json" } : {}),
    },
    body: data ? JSON.stringify(data) : undefined,
  });
  const v = await r.json();
  assert.equal(r.status, expected, `${path}: ${JSON.stringify(v)}`);
  return v;
}
const get = () => request("state");
const stop = () =>
  new Promise((done) => {
    proc.once("exit", done);
    proc.kill("SIGTERM");
  });
test("all offline entries and persistence", async () => {
  try {
    await ready();
    let r = await fetch(base + "/api/setup", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        username: "office",
        password: "A strong local password 123!",
      }),
    });
    assert.equal(r.status, 200);
    cookie = r.headers.get("set-cookie").split(";")[0];
    csrf = (await r.json()).csrf;
    const items = [];
    for (const category of ["Solar panel", "Inverter", "Battery", "Service", "Other"])
      for (let i = 0; i < 5; i++) {
        const isService = category === "Service";
        const item = await request(
          "items",
          "POST",
          {
            name: `${category} ${i + 1}`,
            sku: `${category.slice(0, 2).toUpperCase()}-${i + 1}`,
            category,
            unit: isService ? "job" : "piece",
            price: 15000 + i * 100,
            purchasePrice: 10000,
            trackStock: !isService,
            lowStock: 3,
          },
          201,
        );
        items.push(item);
        if (!isService)
          await request(`items/${item.id}/stock`, "POST", {
            quantity: 20,
            reason: "Opening stock",
          });
      }
    assert.equal((await get()).items.length, 25);
    const customers = [];
    for (let i = 0; i < 5; i++)
      customers.push(
        await request("customers", "POST", {
          name: `Gilgit public department ${i + 1}`,
          phone: `0345267006${i}`,
          email: `department${i}@example.org`,
          address: "Gilgit",
        }),
      );
    const quotes = [];
    for (let i = 0; i < 5; i++) {
      const c = customers[i],
        lines = [items[0], items[5], items[10], items[15], items[20]].map((x) => ({
          itemId: x.id,
          description: x.name,
          quantity: 2,
          price: x.price,
        }));
      quotes.push(
        await request(
          "documents",
          "POST",
          {
            kind: "quotation",
            customer: c.name,
            customerId: c.id,
            phone: c.phone,
            email: c.email,
            title: `Solar installation ${i + 1}`,
            tenderRef: `TENDER-${i + 1}`,
            lines,
          },
          201,
        ),
      );
    }
    assert.equal(
      (await get()).documents.filter((d) => d.kind === "quotation").length,
      5,
    );
    assert.equal(
      (await get()).items.find((i) => i.id === items[0].id).stock,
      20,
      "quotation does not deduct stock",
    );
    await request(`quotations/${quotes[0].id}`, "PATCH", { status: "Submitted" });
    await request(`quotations/${quotes[0].id}`, "PATCH", { status: "Approved" });
    const reuse = await request(
      "documents",
      "POST",
      {
        kind: "quotation",
        customer: quotes[0].customer,
        lines: quotes[0].lines.map((l) => ({ ...l, quantity: 1 })),
      },
      201,
    );
    assert.notEqual(reuse.number, quotes[0].number);
    const invoice = await request(
      "documents",
      "POST",
      {
        kind: "invoice",
        sourceId: quotes[0].id,
        customer: quotes[0].customer,
        customerId: quotes[0].customerId,
        lines: quotes[0].lines,
      },
      201,
    );
    let s = await get();
    assert.equal(
      s.documents.find((d) => d.id === quotes[0].id).convertedInvoiceId,
      invoice.id,
    );
    assert.equal(s.items.find((i) => i.id === items[0].id).stock, 18);
    assert.equal(
      s.items.find((i) => i.id === items[15].id).stock,
      0,
      "service stock unchanged",
    );
    const amounts = [10000, 20000, 30000];
    for (const amount of amounts)
      await request(
        `invoices/${invoice.id}/payments`,
        "POST",
        { amount, method: "Bank" },
        201,
      );
    s = await get();
    assert.equal(s.documents.find((d) => d.id === invoice.id).paidTotal, 60000);
    assert.equal(s.payments.length, 3);
    await request(
      `invoices/${invoice.id}/payments`,
      "POST",
      { amount: invoice.total + 1, method: "Cash" },
      400,
    );
    const remaining = invoice.total - 60000;
    await request(
      `invoices/${invoice.id}/payments`,
      "POST",
      { amount: remaining, method: "Cash" },
      201,
    );
    s = await get();
    assert.equal(s.documents.find((d) => d.id === invoice.id).paidTotal, invoice.total);
    const ret = await request(
      "documents",
      "POST",
      {
        kind: "return",
        sourceId: invoice.id,
        customer: invoice.customer,
        lines: [{ ...invoice.lines[0], quantity: 1 }],
        receivedBack: true,
      },
      201,
    );
    s = await get();
    assert.equal(s.items.find((i) => i.id === items[0].id).stock, 19);
    assert.equal(s.documents.find((d) => d.id === invoice.id).creditTotal, ret.total);
    await request(
      "documents",
      "POST",
      {
        kind: "return",
        sourceId: invoice.id,
        customer: invoice.customer,
        lines: [{ ...invoice.lines[0], quantity: 2 }],
        receivedBack: true,
      },
      400,
    );
    await request(
      `invoices/${invoice.id}/payments`,
      "POST",
      { type: "refund", amount: ret.total, method: "Bank" },
      201,
    );
    await request(`documents/${invoice.id}/void`, "POST", {}, 400);
    const standalone = await request(
      "documents",
      "POST",
      {
        kind: "invoice",
        customer: customers[1].name,
        lines: [
          {
            itemId: items[1].id,
            description: items[1].name,
            price: items[1].price,
            quantity: 1,
          },
        ],
      },
      201,
    );
    await request(`documents/${standalone.id}/void`, "POST", {});
    s = await get();
    assert.equal(s.items.find((i) => i.id === items[1].id).stock, 20);
    const br = await fetch(base + "/api/backup", { headers: { cookie } });
    assert.equal(br.status, 200);
    const bytes = Buffer.from(await br.arrayBuffer()),
      backupFile = join(dir, "test-backup.sqlite");
    await writeFile(backupFile, bytes);
    const check = new DatabaseSync(backupFile, { readOnly: true });
    assert.equal(check.prepare("PRAGMA integrity_check").get().integrity_check, "ok");
    check.close();
    await stop();
    proc = spawn(process.execPath, [join(root, "server.mjs")], { env });
    await ready();
    s = await get();
    assert.equal(
      s.documents.find((d) => d.id === invoice.id).paidTotal,
      invoice.total - ret.total,
    );
    await stop();
    const restore = spawn(
      process.execPath,
      [join(root, "server.mjs"), "--restore", backupFile],
      { env },
    );
    assert.equal(await new Promise((done) => restore.once("exit", done)), 0);
    console.log(
      "Verified 25 items, five customers/quotes, reuse, stock, four payments, return/refund, void, backup, restart and restore.",
    );
  } finally {
    if (proc.exitCode === null) await stop().catch(() => {});
    await rm(dir, { recursive: true, force: true });
  }
});
