import test from "node:test";
import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { spawn } from "node:child_process";

test("password reset: employee temporary password and Super Admin recovery key", async () => {
  const dir = await mkdtemp(join(tmpdir(), "confix-password-"));
  const port = 4800 + Math.floor(Math.random() * 500);
  const base = `http://127.0.0.1:${port}`;
  const child = spawn(process.execPath, ["server.mjs"], { cwd: process.cwd(), env: {...process.env, CONFIX_DATA_DIR:dir, PORT:String(port)}, stdio:"ignore" });
  const auth = {cookie:"", csrf:""};
  const call = async (path, method="GET", body, a=auth) => {
    const r = await fetch(`${base}/api/${path}`, {method, headers:{...(body?{"content-type":"application/json"}:{}), ...(a.cookie?{cookie:a.cookie}:{}), ...(method!=="GET"&&a.csrf?{"x-csrf-token":a.csrf}:{})}, body:body?JSON.stringify(body):undefined});
    return {r, v:await r.json()};
  };
  try {
    for(let i=0;i<80;i++){try{if((await fetch(`${base}/api/session`)).ok)break;}catch{} await new Promise(r=>setTimeout(r,25));}
    let x=await call("session");
    assert.equal(x.v.setupNeeded,true); assert.equal(x.v.recoveryConfigured,false);
    x=await call("setup","POST",{username:"owner",password:"administrator123"});
    assert.equal(x.r.status,200); assert.ok(x.v.recoveryKey); const key=x.v.recoveryKey;
    auth.cookie=x.r.headers.get("set-cookie").split(";")[0]; auth.csrf=x.v.csrf;
    x=await call("session"); assert.equal(x.v.setupNeeded,false); assert.equal(x.v.recoveryConfigured,true);
    x=await call("users/employee","POST",{username:"sales",password:"temporary12345"}); assert.equal(x.r.status,200);
    const emp={cookie:"",csrf:""}; x=await call("login","POST",{username:"sales",password:"temporary12345"},emp); emp.cookie=x.r.headers.get("set-cookie").split(";")[0]; emp.csrf=x.v.csrf; assert.equal(x.v.mustChangePassword,true);
    assert.equal((await call("state","GET",undefined,emp)).r.status,403);
    // A temporary-password user can leave without being trapped on this page.
    x=await call("logout","POST",{},emp); assert.equal(x.r.status,200);
    assert.match(x.r.headers.get("set-cookie"),/Max-Age=0/);
    assert.equal((await call("session","GET",undefined,emp)).v.user,null);
    assert.equal((await call("session","GET",undefined,emp)).v.recoveryConfigured,true);
    x=await call("login","POST",{username:"sales",password:"temporary12345"},emp);
    emp.cookie=x.r.headers.get("set-cookie").split(";")[0]; emp.csrf=x.v.csrf;
    assert.equal((await call("users/change-password","POST",{password:"personal-password-987"},emp)).r.status,200);
    assert.equal((await call("state","GET",undefined,emp)).r.status,200);
    x=await call("logout","POST",{},emp); assert.equal(x.r.status,200);
    assert.equal((await call("session","GET",undefined,emp)).v.user,null);
    x=await call("recover-admin","POST",{username:"owner",recoveryKey:key,password:"new-administrator-456"},{cookie:"",csrf:""}); assert.equal(x.r.status,200); assert.ok(x.v.recoveryKey); assert.notEqual(x.v.recoveryKey,key);
    assert.equal((await call("login","POST",{username:"owner",password:"administrator123"},{cookie:"",csrf:""})).r.status,401);
    assert.equal((await call("recover-admin","POST",{username:"owner",recoveryKey:key,password:"another-password-456"},{cookie:"",csrf:""})).r.status,401);
    assert.equal((await call("login","POST",{username:"owner",password:"new-administrator-456"},{cookie:"",csrf:""})).r.status,200);
  } finally { child.kill("SIGTERM"); await new Promise(r=>setTimeout(r,50)); await rm(dir,{recursive:true,force:true}); }
});
