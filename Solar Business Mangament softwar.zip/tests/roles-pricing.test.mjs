import test from "node:test";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { DatabaseSync } from "node:sqlite";

test("employee permissions, price confirmation, expense and profit snapshots", async () => {
  const root = resolve(import.meta.dirname, ".."),
    dir = await mkdtemp(join(tmpdir(), "confix-roles-")),
    port = 47000 + Math.floor(Math.random() * 10000),
    base = `http://127.0.0.1:${port}`;
  const server = spawn(process.execPath, [join(root, "server.mjs")], {
    env: { ...process.env, PORT: String(port), CONFIX_DATA_DIR: dir },
  });
  const users = { admin: { cookie: "", csrf: "" }, employee: { cookie: "", csrf: "" } };
  async function call(as, path, method = "GET", data) {
    const u = users[as],
      res = await fetch(base + "/api/" + path, {
        method,
        headers: {
          cookie: u.cookie,
          "x-csrf-token": u.csrf,
          "content-type": "application/json",
        },
        body: data ? JSON.stringify(data) : undefined,
      });
    const value = await res.json();
    return { code: res.status, value, headers: res.headers };
  }
  try {
    for (let i = 0; i < 60; i++) {
      try {
        if ((await fetch(base + "/api/session")).ok) break;
      } catch {}
      await new Promise((r) => setTimeout(r, 50));
    }
    let r = await call("admin", "setup", "POST", {
      username: "owner",
      password: "administrator123",
    });
    assert.equal(r.code, 200);
    users.admin.cookie = r.headers.get("set-cookie").split(";")[0];
    users.admin.csrf = r.value.csrf;
    assert.equal(r.value.role, "admin");
    r = await call("admin", "users/employee", "POST", {
      username: "sales",
      password: "employee12345",
    });
    assert.equal(r.code, 200);
    r = await call("employee", "login", "POST", {
      username: "sales",
      password: "employee12345",
    });
    assert.equal(r.code, 200);
    users.employee.cookie = r.headers.get("set-cookie").split(";")[0];
    users.employee.csrf = r.value.csrf;
    assert.equal(r.value.role, "employee");
    assert.equal(r.value.mustChangePassword, true);
    assert.equal((await call("employee", "users/change-password", "POST", { password: "employee-personal-67890" })).code, 200);
    const product = (
      await call("admin", "items", "POST", {
        name: "Solar panel",
        category: "Solar panel",
        sku: "P-01",
        unit: "piece",
        purchasePrice: 12000,
        price: 20000,
        trackStock: true,
      })
    ).value;
    assert.equal(
      (await call("admin", `items/${product.id}/stock`, "POST", { quantity: 10 })).code,
      200,
    );
    const employeeState = (await call("employee", "state")).value;
    assert.equal(employeeState.items[0].purchasePrice, undefined);
    assert.deepEqual(employeeState.audit, []);
    assert.deepEqual(employeeState.payments, []);
    for (const [path, method, payload] of [
      ["items", "POST", {}],
      [`items/${product.id}/stock`, "POST", { quantity: -1 }],
      ["backup", "GET"],
      ["users/employee", "POST", {}],
      ["expenses", "POST", {}],
    ])
      assert.equal((await call("employee", path, method, payload)).code, 403, path);
    const belowCostLine = {
      itemId: product.id,
      description: "Solar panel",
      quantity: 2,
      price: 10000,
    };
    const quote = await call("employee", "documents", "POST", {
      kind: "quotation", customer: "Demo buyer", lines: [belowCostLine],
    });
    assert.equal(quote.code, 201);
    const belowCostRequest = {
      kind: "invoice", sourceId: quote.value.id, customer: "Demo buyer", lines: [belowCostLine],
    };
    assert.equal((await call("employee", "documents", "POST", belowCostRequest)).code, 409);
    assert.equal((await call("employee", "documents", "POST", { ...belowCostRequest, confirmLowPrice: true })).code, 403);

    const line = { itemId: product.id, description: "Solar panel", quantity: 4, price: 15000 };
    const created = await call("employee", "documents", "POST", {
      kind: "invoice", customer: "Invoice full-access buyer", lines: [line],
    });
    assert.equal(created.code, 201);
    const inv = created.value;
    assert.equal(inv.lines[0].costPrice, 12000);
    assert.equal(inv.total, 60000);
    assert.equal((await call("employee", `documents/${inv.id}/void`, "POST", {})).code, 403);

    assert.equal((await call("employee", `invoices/${inv.id}/payments`, "POST", { amount: 20000, method: "Cash" })).code, 201);
    assert.equal((await call("employee", `invoices/${inv.id}/payments`, "POST", { amount: 40000, method: "Bank" })).code, 201);

    const partialReturn = await call("employee", "documents", "POST", {
      kind: "return", sourceId: inv.id, customer: "Invoice full-access buyer",
      receivedBack: false, lines: [{ ...line, quantity: 1 }],
    });
    assert.equal(partialReturn.code, 201);
    assert.equal(partialReturn.value.receivedBack, false);
    assert.equal((await call("employee", `returns/${partialReturn.value.id}/receive-stock`, "POST", {})).code, 403);
    const remainingReturn = await call("employee", "documents", "POST", {
      kind: "return", sourceId: inv.id, customer: "Invoice full-access buyer",
      receivedBack: true, lines: [{ ...line, quantity: 3 }],
    });
    assert.equal(remainingReturn.code, 201);
    assert.equal(remainingReturn.value.receivedBack, true);

    const after = (await call("employee", "state")).value;
    assert.equal(after.payments.filter((p) => p.invoiceId === inv.id).length, 2);
    assert.equal(after.documents.filter((d) => d.kind === "return" && d.sourceId === inv.id).length, 2);
    const employeeInvoice = after.documents.find((d) => d.id === inv.id);
    assert.deepEqual(employeeInvoice.creditedLines, { "0": 4 });
    assert.equal(employeeInvoice.lines[0].costPrice, undefined);
    assert.equal(
      (
        await call("admin", "expenses", "POST", {
          date: "2026-09-26",
          category: "Fuel",
          amount: 1500,
        })
      ).code,
      201,
    );
    const db = new DatabaseSync(join(dir, "confix.sqlite"), { readOnly: true });
    assert.equal(db.prepare("SELECT amount FROM expenses").get().amount, 1500);
    assert.equal(
      db.prepare("SELECT role FROM users WHERE username=?").get("sales").role,
      "employee",
    );
    db.close();
  } finally {
    server.kill("SIGTERM");
    await new Promise((done) => server.once("exit", done));
    await rm(dir, { recursive: true, force: true });
  }
});
