import test from "node:test";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";

// Integration test through HTTP only; the office database is never opened.
test("manual invoice pricing review and linked financial effects", async () => {
  const root = resolve(import.meta.dirname, "..");
  const dir = await mkdtemp(join(tmpdir(), "confix-manual-"));
  const port = 50000 + Math.floor(Math.random() * 8000);
  const base = `http://127.0.0.1:${port}`;
  const server = spawn(process.execPath, [join(root, "server.mjs")], {
    env: { ...process.env, CONFIX_DATA_DIR: dir, PORT: String(port) },
  });
  const auth = { admin: { cookie: "", csrf: "" }, employee: { cookie: "", csrf: "" } };
  async function call(as, path, method = "GET", body, expected = 200) {
    const a = auth[as],
      res = await fetch(`${base}/api/${path}`, {
        method,
        headers: {
          cookie: a.cookie,
          "x-csrf-token": a.csrf,
          "content-type": "application/json",
        },
        body: body ? JSON.stringify(body) : undefined,
      });
    const data = await res.json();
    assert.equal(res.status, expected, `${path}: ${JSON.stringify(data)}`);
    return { data, res };
  }
  const state = async () => (await call("admin", "state")).data;
  const manual = (description, price, quantity = 1, manualKind = "Product") => ({
    itemId: "",
    description,
    price,
    quantity,
    manualKind,
  });
  const doc = async (as, kind, lines, extra = {}) =>
    (
      await call(
        as,
        "documents",
        "POST",
        {
          kind,
          customer: "TEST ONLY — Gilgit office",
          lines,
          ...extra,
        },
        201,
      )
    ).data;
  try {
    for (let i = 0; i < 100; i++) {
      try {
        if ((await fetch(`${base}/api/session`)).ok) break;
      } catch {}
      await new Promise((r) => setTimeout(r, 50));
    }
    let result = await call("admin", "setup", "POST", {
      username: "owner",
      password: "Administrator strong password 123",
    });
    auth.admin.cookie = result.res.headers.get("set-cookie").split(";")[0];
    auth.admin.csrf = result.data.csrf;
    await call("admin", "users/employee", "POST", {
      username: "sales",
      password: "Employee strong password 123",
    });
    result = await call("employee", "login", "POST", {
      username: "sales",
      password: "Employee strong password 123",
    });
    auth.employee.cookie = result.res.headers.get("set-cookie").split(";")[0];
    auth.employee.csrf = result.data.csrf;
    assert.equal(result.data.mustChangePassword, true);
    await call("employee", "users/change-password", "POST", { password: "Employee personal password 456" });

    const panel = manual("550 W panel for school roof", 2000000, 2);
    const quote = await doc("employee", "quotation", [panel]);
    assert.equal(
      (await state()).items.length,
      0,
      "quotation must not create inventory",
    );
    assert.equal(quote.lines[0].costPrice, null);
    const invoice = await doc("employee", "invoice", quote.lines, {
      sourceId: quote.id,
    });
    let s = await state();
    assert.equal(s.items.length, 1);
    assert.equal(s.items[0].reviewStatus, "pending");
    assert.equal(s.items[0].stock, 0);
    assert.equal(s.items[0].price, 2000000);
    assert.equal(s.items[0].originInvoiceId, invoice.id);
    assert.equal(s.documents.find((x) => x.id === invoice.id).lines[0].costPrice, null);
    assert.equal(
      s.documents.find((x) => x.id === quote.id).convertedInvoiceId,
      invoice.id,
    );
    assert.equal(
      s.movements.length,
      0,
      "manual issue must not deduct an unrelated item",
    );
    await call(
      "employee",
      "documents",
      "POST",
      {
        kind: "invoice",
        customer: quote.customer,
        sourceId: quote.id,
        lines: quote.lines,
      },
      400,
    );
    assert.equal(
      (await state()).items.length,
      1,
      "duplicate conversion must not duplicate item",
    );
    await call(
      "employee",
      `invoices/${invoice.id}/lines/0/resolve-pricing`,
      "POST",
      {
        purchasePrice: 1200000,
        salePrice: 2100000,
        category: "Solar panel",
      },
      403,
    );
    const employeeState = (await call("employee", "state")).data;
    assert.equal(
      employeeState.items.length,
      0,
      "employee cannot select an unresolved item",
    );
    assert.equal(
      employeeState.documents.find((x) => x.id === invoice.id).lines[0].costPrice,
      undefined,
    );
    await call("admin", `items/${s.items[0].id}/stock`, "POST", { quantity: 2 }, 400);
    await call("admin", `items/${s.items[0].id}/archive`, "POST", {}, 400);

    const credit = await doc(
      "admin",
      "return",
      [{ ...invoice.lines[0], quantity: 1 }],
      { sourceId: invoice.id, receivedBack: true },
    );
    s = await state();
    assert.equal(s.items[0].stock, 1);
    assert.equal(s.documents.find((x) => x.id === credit.id).lines[0].costPrice, null);
    await call("admin", `invoices/${invoice.id}/lines/0/resolve-pricing`, "POST", {
      purchasePrice: 1200000,
      salePrice: 2100000,
      category: "Solar panel",
    });
    s = await state();
    assert.equal(s.items[0].reviewStatus, "ready");
    assert.equal(s.items[0].purchasePrice, 1200000);
    assert.equal(s.items[0].price, 2100000);
    assert.equal(s.items[0].stock, 1);
    assert.equal(
      s.documents.find((x) => x.id === invoice.id).lines[0].costPrice,
      1200000,
    );
    assert.equal(
      s.documents.find((x) => x.id === credit.id).lines[0].costPrice,
      1200000,
    );
    assert.equal(s.documents.find((x) => x.id === invoice.id).total, 4000000);
    assert.equal(
      s.audit.filter((x) => x.action === "Invoice line cost resolved").length,
      1,
    );
    await call(
      "admin",
      `invoices/${invoice.id}/lines/0/resolve-pricing`,
      "POST",
      {
        purchasePrice: 100,
        salePrice: 100,
        category: "Other",
      },
      400,
    );
    console.log(
      "Manual product: quotation leaves stock; invoice creates pending item; return and resolution update linked records.",
    );

    const service = await doc("employee", "invoice", [
      manual("Inverter installation labor", 500000, 1, "Service"),
    ]);
    s = await state();
    const serviceItem = s.items.find((x) => x.originInvoiceId === service.id);
    assert.equal(serviceItem.trackStock, false);
    const serviceCredit = await doc(
      "admin",
      "return",
      [{ ...service.lines[0], quantity: 1 }],
      { sourceId: service.id, receivedBack: true },
    );
    assert.equal((await state()).items.find((x) => x.id === serviceItem.id).stock, 0);
    await call(
      "admin",
      `invoices/${service.id}/lines/0/resolve-pricing`,
      "POST",
      {
        purchasePrice: 0,
        salePrice: 550000,
        category: "Service",
      },
      400,
    );
    await call(
      "admin",
      `invoices/${service.id}/lines/0/resolve-pricing`,
      "POST",
      {
        purchasePrice: 600000,
        salePrice: 550000,
        category: "Service",
      },
      409,
    );
    await call("admin", `invoices/${service.id}/lines/0/resolve-pricing`, "POST", {
      purchasePrice: 100000,
      salePrice: 550000,
      category: "Service",
    });
    s = await state();
    assert.equal(
      s.documents.find((x) => x.id === serviceCredit.id).lines[0].costPrice,
      100000,
    );
    console.log(
      "Manual service: catalogued without stock; return changes credit only.",
    );

    const abandoned = await doc("employee", "invoice", [
      manual("One-off battery module", 800000),
    ]);
    const abandonedItem = (await state()).items.find(
      (x) => x.originInvoiceId === abandoned.id,
    );
    await call("admin", `documents/${abandoned.id}/void`, "POST", {});
    s = await state();
    assert.equal(
      s.items.find((x) => x.id === abandonedItem.id).reviewStatus,
      "void-source",
    );
    assert.equal(s.items.find((x) => x.id === abandonedItem.id).active, false);
    assert.equal(s.items.find((x) => x.id === abandonedItem.id).stock, 0);
    assert.ok(
      s.audit.some(
        (x) => x.action === "Unresolved manual item archived after invoice void",
      ),
    );
    console.log(
      "Unresolved invoice void: no invented stock; orphan catalog item archived and audited.",
    );

    const saved = (
      await call(
        "admin",
        "items",
        "POST",
        {
          name: "Saved inverter",
          sku: "INV-TEST",
          category: "Inverter",
          unit: "piece",
          purchasePrice: 1200000,
          price: 1800000,
          trackStock: true,
        },
        201,
      )
    ).data;
    await call("admin", `items/${saved.id}/stock`, "POST", { quantity: 1 });
    await call(
      "employee",
      "documents",
      "POST",
      {
        kind: "invoice",
        customer: "TEST ONLY — Gilgit office",
        lines: [
          {
            itemId: saved.id,
            description: "Changed description",
            quantity: 1,
            price: 1800000,
          },
        ],
      },
      400,
    );
    assert.equal((await state()).items.find((x) => x.id === saved.id).stock, 1);
    console.log(
      "Saved item: changed manual description rejected; existing stock untouched.",
    );
  } finally {
    server.kill("SIGTERM");
    await new Promise((done) => server.once("exit", done));
    await rm(dir, { recursive: true, force: true });
  }
});
