import test from "node:test";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { mkdtemp, rm, readFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { DatabaseSync } from "node:sqlite";

test("old database migrates without deleting legacy manual invoices or returns", async () => {
  const root = resolve(import.meta.dirname, ".."),
    dir = await mkdtemp(join(tmpdir(), "confix-migrate-"));
  const port = 50000 + Math.floor(Math.random() * 8000),
    base = `http://127.0.0.1:${port}`;
  const schema = (await readFile(join(root, "schema.sql"), "utf8")).replace(
    ",\n  reviewStatus TEXT NOT NULL DEFAULT 'ready',\n  originInvoiceId TEXT",
    "",
  );
  const db = new DatabaseSync(join(dir, "confix.sqlite"));
  db.exec(schema);
  const invoiceLine = {
    itemId: "",
    description: "Legacy manual controller",
    quantity: 2,
    price: 500000,
    listPrice: 500000,
    costPrice: 0,
    tracked: false,
  };
  const returnLine = { ...invoiceLine, quantity: 1 };
  const insert = db.prepare(`INSERT INTO documents
  (id,kind,number,customer,date,lines,total,sourceId,status,creditTotal,receivedBack,createdAt)
  VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`);
  insert.run(
    "old-invoice",
    "invoice",
    "INV-LEGACY",
    "TEST ONLY — Gilgit office",
    "2026-09-26",
    JSON.stringify([invoiceLine]),
    1000000,
    "",
    "Issued",
    500000,
    0,
    new Date().toISOString(),
  );
  insert.run(
    "old-return",
    "return",
    "CRN-LEGACY",
    "TEST ONLY — Gilgit office",
    "2026-09-26",
    JSON.stringify([returnLine]),
    500000,
    "old-invoice",
    "Issued",
    0,
    1,
    new Date().toISOString(),
  );
  db.close();
  const server = spawn(process.execPath, [join(root, "server.mjs")], {
    env: { ...process.env, CONFIX_DATA_DIR: dir, PORT: String(port) },
  });
  let cookie = "",
    csrf = "";
  async function call(path, method = "GET", body, expected = 200) {
    const res = await fetch(`${base}/api/${path}`, {
      method,
      headers: { cookie, "x-csrf-token": csrf, "content-type": "application/json" },
      body: body ? JSON.stringify(body) : undefined,
    });
    const data = await res.json();
    assert.equal(res.status, expected, JSON.stringify(data));
    return { res, data };
  }
  try {
    for (let i = 0; i < 100; i++) {
      try {
        if ((await fetch(`${base}/api/session`)).ok) break;
      } catch {}
      await new Promise((r) => setTimeout(r, 50));
    }
    const setup = await call("setup", "POST", {
      username: "owner",
      password: "Administrator strong password 123",
    });
    cookie = setup.res.headers.get("set-cookie").split(";")[0];
    csrf = setup.data.csrf;
    let state = (await call("state")).data;
    assert.equal(state.documents.length, 2);
    assert.equal(state.items.length, 0);
    assert.equal(
      state.documents.find((x) => x.id === "old-invoice").lines[0].itemId,
      "",
    );
    await call("invoices/old-invoice/lines/0/resolve-pricing", "POST", {
      category: "Other",
      purchasePrice: 200000,
      salePrice: 550000,
    });
    state = (await call("state")).data;
    const invoice = state.documents.find((x) => x.id === "old-invoice");
    const credit = state.documents.find((x) => x.id === "old-return");
    assert.equal(state.items.length, 1);
    assert.equal(state.items[0].stock, 1, "previous physical return is reconciled");
    assert.equal(invoice.lines[0].costPrice, 200000);
    assert.equal(invoice.lines[0].itemId, state.items[0].id);
    assert.equal(credit.lines[0].costPrice, 200000);
    assert.equal(credit.lines[0].itemId, state.items[0].id);
    assert.equal(invoice.total, 1000000);
    assert.equal(credit.total, 500000);
    assert.equal(
      state.audit.some((x) => x.action === "Legacy manual item catalogued"),
      true,
    );
    console.log(
      "Legacy migration: records retained, missing cost resolved, return stock reconciled.",
    );
  } finally {
    server.kill("SIGTERM");
    await new Promise((done) => server.once("exit", done));
    await rm(dir, { recursive: true, force: true });
  }
});
