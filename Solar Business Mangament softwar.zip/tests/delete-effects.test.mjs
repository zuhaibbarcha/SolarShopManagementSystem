import test from "node:test";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";

// Black-box checks: use only the same HTTP API used by the browser.
// Each run creates and removes a disposable SQLite database.
test("archive and void effects, blocked dependencies, and audit history", async () => {
  const root = resolve(import.meta.dirname, "..");
  const dir = await mkdtemp(join(tmpdir(), "confix-delete-"));
  const port = 49000 + Math.floor(Math.random() * 10000);
  const base = `http://127.0.0.1:${port}`;
  const server = spawn(process.execPath, [join(root, "server.mjs")], {
    env: { ...process.env, CONFIX_DATA_DIR: dir, PORT: String(port) },
  });
  let cookie = "",
    csrf = "";
  async function call(path, method = "GET", body, expected = 200) {
    const response = await fetch(`${base}/api/${path}`, {
      method,
      headers: { cookie, "x-csrf-token": csrf, "content-type": "application/json" },
      body: body ? JSON.stringify(body) : undefined,
    });
    const data = await response.json();
    assert.equal(response.status, expected, `${path}: ${JSON.stringify(data)}`);
    return { data, response };
  }
  async function state() {
    return (await call("state")).data;
  }
  function financials(s) {
    const invoices = s.documents.filter(
      (d) => d.kind === "invoice" && d.status !== "void",
    );
    return {
      sales: invoices.reduce((n, d) => n + d.total, 0),
      receivable: invoices.reduce(
        (n, d) => n + Math.max(0, d.total - d.creditTotal - d.paidTotal),
        0,
      ),
      expenses: s.expenses.reduce((n, d) => n + d.amount, 0),
    };
  }
  async function item(sku, stock) {
    const product = (
      await call(
        "items",
        "POST",
        {
          name: `TEST ONLY — ${sku} solar equipment`,
          sku,
          category: "Solar panel",
          unit: "piece",
          price: 2000000,
          purchasePrice: 1200000,
          trackStock: true,
        },
        201,
      )
    ).data;
    if (stock)
      await call(`items/${product.id}/stock`, "POST", {
        quantity: stock,
        reason: "Opening test stock",
      });
    return product;
  }
  const line = (product, quantity = 1) => ({
    itemId: product.id,
    description: product.name,
    quantity,
    price: product.price,
  });
  const document = (kind, lines, extra = {}) =>
    call(
      "documents",
      "POST",
      {
        kind,
        customer: "TEST ONLY — Gilgit School",
        lines,
        ...extra,
      },
      201,
    ).then((x) => x.data);
  try {
    for (let i = 0; i < 100; i++) {
      try {
        if ((await fetch(base + "/api/session")).ok) break;
      } catch {}
      await new Promise((r) => setTimeout(r, 50));
    }
    const setup = await call("setup", "POST", {
      username: "owner",
      password: "Administrator strong password 123",
    });
    cookie = setup.response.headers.get("set-cookie").split(";")[0];
    csrf = setup.data.csrf;

    // Inventory: nonzero stock is protected. A zero-stock archive retains history.
    const unused = await item("TEST-ARCHIVE-01", 3);
    await call(`items/${unused.id}/archive`, "POST", {}, 400);
    assert.equal((await state()).items.find((x) => x.id === unused.id).active, true);
    await call(`items/${unused.id}/stock`, "POST", {
      quantity: -3,
      reason: "Test stock adjustment",
    });
    await call(`items/${unused.id}/archive`, "POST", {}, 200);
    await call(`items/${unused.id}/archive`, "POST", {}, 400);
    let s = await state();
    assert.equal(s.items.find((x) => x.id === unused.id).active, false);
    assert.equal(s.items.find((x) => x.id === unused.id).stock, 0);
    assert.equal(s.movements.filter((x) => x.itemId === unused.id).length, 2);
    assert.equal(
      s.audit.filter((x) => x.action === "Item archived" && x.recordId === unused.id)
        .length,
      1,
    );
    console.log(
      "Inventory archive: nonzero stock blocked; zero-stock item kept in history.",
    );

    // Quotation: void does not touch inventory and excludes it from active totals.
    const product = await item("TEST-QUOTE-01", 2);
    const draft = await document("quotation", [line(product)]);
    await call(`documents/${draft.id}/void`, "POST", {}, 200);
    await call(`documents/${draft.id}/void`, "POST", {}, 400);
    await call(
      "documents",
      "POST",
      {
        kind: "invoice",
        sourceId: draft.id,
        customer: draft.customer,
        lines: draft.lines,
      },
      400,
    );
    s = await state();
    assert.equal(s.items.find((x) => x.id === product.id).stock, 2);
    assert.equal(s.documents.find((x) => x.id === draft.id).status, "void");
    assert.equal(
      s.audit.filter((x) => x.action === "Document voided" && x.recordId === draft.id)
        .length,
      1,
    );
    console.log(
      "Quotation void: history retained; stock and sales unchanged; reuse blocked.",
    );

    // Converted quotation cannot be voided until its unpaid invoice is voided.
    const quote = await document("quotation", [line(product)]);
    const invoice = await document("invoice", quote.lines, { sourceId: quote.id });
    await call(
      "expenses",
      "POST",
      {
        date: "2026-09-26",
        category: "Transport to Gilgit installation",
        amount: 150000,
      },
      201,
    );
    await call(`documents/${quote.id}/void`, "POST", {}, 400);
    assert.equal((await state()).items.find((x) => x.id === product.id).stock, 1);
    assert.equal(financials(await state()).sales, 2000000);
    await call(`documents/${invoice.id}/void`, "POST", {}, 200);
    s = await state();
    assert.deepEqual(financials(s), {
      sales: 0,
      receivable: 0,
      expenses: 150000,
    });
    assert.equal(s.items.find((x) => x.id === product.id).stock, 2);
    assert.equal(s.documents.find((x) => x.id === invoice.id).status, "void");
    assert.equal(s.documents.find((x) => x.id === quote.id).status, "Approved");
    assert.equal(s.documents.find((x) => x.id === quote.id).convertedInvoiceId, "");
    assert.equal(
      s.movements
        .filter((x) => x.documentId === invoice.id)
        .reduce((a, x) => a + x.delta, 0),
      0,
    );
    await call(`documents/${quote.id}/void`, "POST", {}, 200);
    console.log("Invoice void: stock restored, linked quote reopened, sales excluded.");

    // Sold-out item may be archived; a later void must restore stock visibly.
    const soldOut = await item("TEST-SOLD-OUT-01", 1);
    const soldInvoice = await document("invoice", [line(soldOut)]);
    await call(`items/${soldOut.id}/archive`, "POST", {}, 200);
    await call(`documents/${soldInvoice.id}/void`, "POST", {}, 200);
    s = await state();
    assert.equal(s.items.find((x) => x.id === soldOut.id).stock, 1);
    assert.equal(s.items.find((x) => x.id === soldOut.id).active, true);
    assert.ok(
      s.audit.some(
        (x) =>
          x.recordId === soldOut.id &&
          x.action === "Item reactivated for stock reversal",
      ),
    );
    console.log(
      "Archived sold-out item: invoice void reactivates and restores stock with audit.",
    );

    // Physical return after archive has the same stock restoration behavior.
    const returned = await item("TEST-RETURN-01", 1);
    const returnInvoice = await document("invoice", [line(returned)]);
    await call(`items/${returned.id}/archive`, "POST", {}, 200);
    const credit = await document(
      "return",
      [{ ...returnInvoice.lines[0], quantity: 1 }],
      {
        sourceId: returnInvoice.id,
        receivedBack: true,
      },
    );
    s = await state();
    assert.equal(s.items.find((x) => x.id === returned.id).stock, 1);
    assert.equal(s.items.find((x) => x.id === returned.id).active, true);
    assert.equal(
      s.documents.find((x) => x.id === returnInvoice.id).creditTotal,
      credit.total,
    );
    await call(`documents/${credit.id}/void`, "POST", {}, 400);
    await call(`documents/${returnInvoice.id}/void`, "POST", {}, 400);
    assert.equal(
      (await state()).documents.find((x) => x.id === credit.id).status,
      "Issued",
    );
    console.log(
      "Return: archived item restored; return and linked invoice cannot be voided.",
    );

    // Paid invoices remain in history and cannot be voided or reverse stock.
    const paidItem = await item("TEST-PAID-01", 2);
    const paid = await document("invoice", [line(paidItem)]);
    await call(
      `invoices/${paid.id}/payments`,
      "POST",
      {
        amount: 500000,
        method: "Cash",
      },
      201,
    );
    await call(`documents/${paid.id}/void`, "POST", {}, 400);
    s = await state();
    assert.equal(s.items.find((x) => x.id === paidItem.id).stock, 1);
    assert.equal(s.documents.find((x) => x.id === paid.id).status, "Issued");
    assert.equal(s.documents.find((x) => x.id === paid.id).paidTotal, 500000);
    assert.equal(s.payments.filter((x) => x.invoiceId === paid.id).length, 1);
    assert.deepEqual(financials(s), {
      sales: 4000000,
      receivable: 1500000,
      expenses: 150000,
    });
    console.log("Paid invoice: void blocked; stock, payment and receivable unchanged.");
  } finally {
    server.kill("SIGTERM");
    await new Promise((done) => server.once("exit", done));
    await rm(dir, { recursive: true, force: true });
  }
});
