import http from "node:http";
import { DatabaseSync, backup } from "node:sqlite";
import { randomBytes, randomUUID, scryptSync, timingSafeEqual } from "node:crypto";
import {
  readFile,
  writeFile,
  mkdir,
  copyFile,
  rename,
  rm,
  open,
  stat,
} from "node:fs/promises";
import { createReadStream } from "node:fs";
import { join, resolve, dirname, extname } from "node:path";
import { fileURLToPath } from "node:url";
// Local-only server. The data folder may be redirected by tests with CONFIX_DATA_DIR.
const root = dirname(fileURLToPath(import.meta.url)),
  dir = resolve(process.env.CONFIX_DATA_DIR || join(root, "data")),
  file = join(dir, "confix.sqlite"),
  port = Number(process.env.PORT || 4173),
  host = "127.0.0.1";
await mkdir(dir, { recursive: true });
const lock = join(dir, "server.lock");
// Restoring must be done with the server stopped; keep a previous copy first.
if (process.argv[2] === "--restore") {
  const input = process.argv[3];
  if (!input) throw Error("Usage: node server.mjs --restore PATH_TO_BACKUP.sqlite");
  try {
    const pid = Number(await readFile(lock, "utf8"));
    if (pid) {
      try {
        process.kill(pid, 0);
        throw Error("Stop the CONFIX server before restoring.");
      } catch (e) {
        if (e.code !== "ESRCH") throw e;
      }
    }
  } catch (e) {
    if (e.code !== "ENOENT") throw e;
  }
  const source = new DatabaseSync(resolve(input), { readOnly: true });
  const check = source.prepare("PRAGMA integrity_check").get();
  source.close();
  if (Object.values(check)[0] !== "ok") throw Error("Backup failed integrity check.");
  const tmp = join(dir, "restore.tmp");
  await copyFile(resolve(input), tmp);
  if (await stat(file).catch(() => null)) {
    const old = join(dir, `before-restore-${Date.now()}.sqlite`);
    await copyFile(file, old);
    console.log("Previous database saved to", old);
  }
  await rename(tmp, file);
  await rm(file + "-wal", { force: true });
  await rm(file + "-shm", { force: true });
  console.log("Restored database. Start the server again.");
  process.exit(0);
}
let handle;
try {
  handle = await open(lock, "wx");
} catch (e) {
  if (e.code !== "EEXIST") throw e;
  const pid = Number(await readFile(lock, "utf8"));
  let active = false;
  try {
    process.kill(pid, 0);
    active = true;
  } catch (err) {
    if (err.code !== "ESRCH") throw err;
  }
  if (active) throw Error(`Another local server is using ${dir}.`);
  await rm(lock, { force: true });
  handle = await open(lock, "wx");
}
await handle.writeFile(String(process.pid));
// Database schema and the one-time user-role migration.
const db = new DatabaseSync(file);
// Schema is kept in SQL so tables and fields can be inspected without reading routes.
db.exec(await readFile(join(root, "schema.sql"), "utf8"));
if (
  !db
    .prepare("PRAGMA table_info(users)")
    .all()
    .some((c) => c.name === "role")
)
  db.exec("ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'admin'");
// Upgrade existing office databases without dropping any records.
const itemColumns = db
  .prepare("PRAGMA table_info(items)")
  .all()
  .map((c) => c.name);
if (!itemColumns.includes("reviewStatus"))
  db.exec("ALTER TABLE items ADD COLUMN reviewStatus TEXT NOT NULL DEFAULT 'ready'");
if (!itemColumns.includes("originInvoiceId"))
  db.exec("ALTER TABLE items ADD COLUMN originInvoiceId TEXT");
const userColumns = db.prepare("PRAGMA table_info(users)").all().map((c) => c.name);
if (!userColumns.includes("mustChangePassword"))
  db.exec("ALTER TABLE users ADD COLUMN mustChangePassword INTEGER NOT NULL DEFAULT 0");
db.exec(`CREATE TABLE IF NOT EXISTS recovery (
  userId TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  salt TEXT NOT NULL,
  hash TEXT NOT NULL,
  createdAt TEXT NOT NULL,
  usedAt TEXT
)`);
const now = () => new Date().toISOString(),
  today = () => now().slice(0, 10),
  uid = () => randomUUID(),
  short = (s) => s.replaceAll("-", "").slice(0, 10).toUpperCase();
const q = (sql, ...args) => db.prepare(sql).get(...args),
  all = (sql, ...args) => db.prepare(sql).all(...args),
  run = (sql, ...args) => db.prepare(sql).run(...args);
const fail = (m, status = 400) => {
  const e = Error(m);
  e.status = status;
  throw e;
};
const validMoney = (n) => Number.isSafeInteger(n) && n >= 0 && n <= 1e12;
const text = (v, max = 160) =>
  String(v ?? "")
    .trim()
    .slice(0, max);
const docRow = (r) =>
  r
    ? {
        ...r,
        lines: JSON.parse(r.lines),
        creditedLines: JSON.parse(r.creditedLines),
        receivedBack: !!r.receivedBack,
      }
    : null;
const itemRow = (r) => ({
  ...r,
  trackStock: !!r.trackStock,
  active: !!r.active,
  schemaVersion: 2,
});
function auditLog(actor, action, recordId, before = null, after = null) {
  run(
    "INSERT INTO audit VALUES (?,?,?,?,?,?,?)",
    uid(),
    actor,
    action,
    recordId,
    JSON.stringify(before).slice(0, 4000),
    JSON.stringify(after).slice(0, 4000),
    now(),
  );
}
function tx(fn) {
  db.exec("BEGIN IMMEDIATE");
  try {
    const result = fn();
    db.exec("COMMIT");
    return result;
  } catch (e) {
    db.exec("ROLLBACK");
    throw e;
  }
}
function itemData(b) {
  const name = text(b.name),
    category = text(b.category, 40),
    unit = text(b.unit, 40),
    sku = text(b.sku, 50) || null,
    price = Number(b.price),
    purchasePrice = Number(b.purchasePrice || 0),
    lowStock = Number(b.lowStock || 0);
  if (
    !name ||
    !unit ||
    !["Solar panel", "Inverter", "Battery", "Service", "Other"].includes(category) ||
    !validMoney(price) ||
    !validMoney(purchasePrice) ||
    !Number.isSafeInteger(lowStock) ||
    lowStock < 0
  )
    fail("Enter valid item details and prices.");
  return {
    name,
    category,
    unit,
    sku,
    price,
    purchasePrice,
    lowStock,
    brand: text(b.brand, 100),
    description: text(b.description, 500),
    trackStock: b.trackStock ? 1 : 0,
  };
}
// Line prices and costs are captured when a document is issued. Later item edits
// cannot silently change historical margins or invoice amounts.
function linesData(raw, sourceLines, kind = "quotation") {
  if (!Array.isArray(raw) || !raw.length || raw.length > 100)
    fail("Enter 1–100 valid lines.");
  const lines = raw.map((l) => {
    const itemId = text(l.itemId, 80);
    const item = itemId ? q("SELECT * FROM items WHERE id=?", itemId) : null;
    if (itemId && !item) fail("Selected inventory item is unavailable.");
    if (itemId && kind !== "return" && text(l.description, 200) !== item.name)
      fail("A saved item description cannot be changed. Select Manual entry instead.");
    if (itemId && kind !== "return" && item.reviewStatus === "pending")
      fail("This item needs administrator pricing review before another sale.");
    const snap = sourceLines?.find(
      (x) =>
        x.itemId === itemId &&
        x.description === text(l.description, 200) &&
        x.price === Number(l.price),
    );
    const manualKind = itemId ? "" : l.manualKind === "Service" ? "Service" : "Product";
    return {
      itemId,
      description: text(l.description, 200),
      quantity: Number(l.quantity),
      price: Number(l.price),
      listPrice: item ? item.price : Number(l.price),
      costPrice: item ? item.purchasePrice : null,
      tracked: !!item?.trackStock,
      manualKind: snap?.manualKind || manualKind,
      manualOrigin: !!snap?.manualOrigin,
      ...(snap
        ? {
            listPrice: snap.listPrice ?? item?.price ?? Number(l.price),
            costPrice: Object.hasOwn(snap, "costPrice")
              ? snap.costPrice
              : (item?.purchasePrice ?? null),
            tracked: snap.tracked ?? !!item?.trackStock,
          }
        : {}),
    };
  });
  if (
    lines.some(
      (l) =>
        !l.description ||
        !Number.isSafeInteger(l.quantity) ||
        l.quantity < 1 ||
        l.quantity > 100000 ||
        !validMoney(l.price),
    )
  )
    fail("Invalid line quantity or price.");
  const total = lines.reduce((a, l) => a + l.quantity * l.price, 0);
  if (!validMoney(total)) fail("Document amount is too large.");
  return { lines, total };
}
function documentInput(b, sourceLines, kind = b.kind || "quotation") {
  const customer = text(b.customer),
    { lines, total } = linesData(b.lines, sourceLines, kind);
  if (!customer) fail("Customer is required.");
  return {
    customer,
    customerId: text(b.customerId, 80),
    phone: text(b.phone, 60),
    email: text(b.email),
    title: text(b.title),
    tenderRef: text(b.tenderRef, 120),
    customerRef: text(b.customerRef, 120),
    notes: text(b.notes, 1000),
    dueDate: text(b.dueDate, 10),
    lines,
    total,
  };
}
const insertDoc = (d) =>
  run(
    `INSERT INTO documents(id,kind,number,customer,customerId,phone,email,title,tenderRef,customerRef,date,dueDate,notes,lines,total,sourceId,status,paidTotal,creditTotal,creditedLines,convertedInvoiceId,receivedBack,createdAt) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    d.id,
    d.kind,
    d.number,
    d.customer,
    d.customerId,
    d.phone,
    d.email,
    d.title,
    d.tenderRef,
    d.customerRef,
    d.date,
    d.dueDate,
    d.notes,
    JSON.stringify(d.lines),
    d.total,
    d.sourceId,
    d.status,
    d.paidTotal || 0,
    d.creditTotal || 0,
    JSON.stringify(d.creditedLines || {}),
    d.convertedInvoiceId || "",
    d.receivedBack ? 1 : 0,
    now(),
  );
// Every stock change writes a movement in the same SQLite transaction.
function stockMove(itemId, delta, reason, reference, documentId, actor) {
  const current = q("SELECT * FROM items WHERE id=?", itemId);
  const reversal =
    delta > 0 && (reason === "Invoice voided" || reason === "Returned to stock");
  if (!current || !current.trackStock || (!current.active && !reversal))
    fail("Linked inventory item unavailable.");
  const next = current.stock + delta;
  if (next < 0) fail(`Insufficient stock for ${current.name}.`);
  // A returned or voided sale can bring back an archived, sold-out item.
  // Reactivate it so the restored stock is visible and manageable.
  if (!current.active && reversal) {
    run("UPDATE items SET active=1,updatedAt=? WHERE id=?", now(), itemId);
    auditLog(
      actor,
      "Item reactivated for stock reversal",
      itemId,
      { active: false, stock: current.stock },
      { active: true, stock: next },
    );
  }
  run("UPDATE items SET stock=?,updatedAt=? WHERE id=?", next, now(), itemId);
  run(
    "INSERT INTO movements VALUES (?,?,?,?,?,?,?,?)",
    uid(),
    itemId,
    delta,
    reason,
    reference,
    documentId,
    actor,
    now(),
  );
}
function groupedStock(lines, sign, { voiding = false } = {}) {
  const changes = new Map();
  for (const l of lines) {
    if (!l.itemId) continue;
    const item = q("SELECT * FROM items WHERE id=?", l.itemId);
    if (!item) fail(`Item ${l.description} no longer exists.`);
    // A manual sale starts at stock zero. A physical return may add stock.
    if (l.manualOrigin && (sign < 0 || voiding)) continue;
    if (item.trackStock) {
      if (!item.active && sign < 0) fail(`Item ${item.name} is archived.`);
      changes.set(item.id, (changes.get(item.id) || 0) + sign * l.quantity);
    }
  }
  return changes;
}
function catalogueManualInvoiceLines(data, actor) {
  data.lines.forEach((line, index) => {
    if (line.itemId) return;
    const id = uid(),
      at = now(),
      isService = line.manualKind === "Service";
    const sku = `MAN-${short(data.id)}-${index + 1}`;
    run(
      `INSERT INTO items
       (id,name,sku,category,description,brand,unit,purchasePrice,price,
        stock,lowStock,trackStock,active,createdAt,updatedAt,reviewStatus,originInvoiceId)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      id,
      line.description,
      sku,
      isService ? "Service" : "Other",
      "",
      "",
      isService ? "job" : "piece",
      0,
      line.price,
      0,
      0,
      isService ? 0 : 1,
      1,
      at,
      at,
      "pending",
      data.id,
    );
    line.itemId = id;
    line.manualOrigin = true;
    line.tracked = false;
    line.costPrice = null;
    auditLog(actor, "Manual invoice item awaiting pricing", id, null, {
      invoiceId: data.id,
      sku,
      quantity: line.quantity,
    });
  });
}
// Quotations leave stock alone. Issued invoices deduct stock; returns can restore it.
function createDocument(b, actor, allowLowPriceOverride = false) {
  const kind = b.kind;
  if (!["quotation", "invoice", "return"].includes(kind))
    fail("Invalid document type.");
  return tx(() => {
    const sourceId = text(b.sourceId, 80),
      source = sourceId
        ? docRow(q("SELECT * FROM documents WHERE id=?", sourceId))
        : null,
      fields = documentInput(b, source?.lines, kind);
    if ((sourceId && !source) || source?.status === "void")
      fail("Source document unavailable.");
    if (
      kind === "invoice" &&
      source &&
      (source.kind !== "quotation" || source.convertedInvoiceId)
    )
      fail("Quotation already converted or invalid.");
    if (kind === "return" && (!source || source.kind !== "invoice"))
      fail("Open the original invoice to record a return.");
    const belowCost =
      kind === "invoice" &&
      fields.lines.some((l) => l.tracked && l.costPrice > 0 && l.price < l.costPrice);
    if (belowCost && b.confirmLowPrice === true && !allowLowPriceOverride)
      fail("Administrator authorization is required for a below-cost sale.", 403);
    if (belowCost && b.confirmLowPrice !== true)
      fail(
        allowLowPriceOverride
          ? "One or more stocked items are priced below their purchase cost. Confirm this sale to continue."
          : "One or more stocked items are priced below their purchase cost. Ask the Super Admin to issue or authorize this invoice.",
        409,
      );
    const id = uid(),
      number = `${{ quotation: "QTN", invoice: "INV", return: "CRN" }[kind]}-${new Date().getFullYear()}-${short(id)}`,
      data = {
        ...fields,
        id,
        kind,
        number,
        date: today(),
        sourceId,
        status: kind === "quotation" ? "Draft" : "Issued",
        receivedBack: kind === "return" && !!b.receivedBack,
      };
    if (kind === "invoice") catalogueManualInvoiceLines(data, actor);
    if (kind === "return") {
      const used = { ...source.creditedLines },
        pending = {};
      for (const l of fields.lines) {
        const index = source.lines.findIndex(
          (x) =>
            x.itemId === l.itemId &&
            x.description === l.description &&
            x.price === l.price,
        );
        if (index < 0) fail("Return items and prices must match the invoice.");
        pending[index] = (pending[index] || 0) + l.quantity;
        if ((used[index] || 0) + pending[index] > source.lines[index].quantity)
          fail("Return quantity exceeds invoice quantity.");
      }
      if (source.creditTotal + fields.total > source.total)
        fail("Credit exceeds invoice.");
      for (const [k, v] of Object.entries(pending)) used[k] = (used[k] || 0) + v;
      run(
        "UPDATE documents SET creditTotal=?,creditedLines=?,updatedAt=? WHERE id=?",
        source.creditTotal + fields.total,
        JSON.stringify(used),
        now(),
        sourceId,
      );
    }
    if (kind === "invoice" && source)
      run(
        "UPDATE documents SET status=?,convertedInvoiceId=?,updatedAt=? WHERE id=?",
        "Converted to invoice",
        id,
        now(),
        sourceId,
      );
    const stock =
      kind === "invoice" || (kind === "return" && data.receivedBack)
        ? groupedStock(fields.lines, kind === "invoice" ? -1 : 1)
        : new Map();
    for (const [itemId, delta] of stock) {
      const item = q("SELECT stock FROM items WHERE id=?", itemId);
      if (item.stock + delta < 0) fail("Insufficient stock.");
    }
    insertDoc(data);
    for (const [itemId, delta] of stock)
      stockMove(
        itemId,
        delta,
        kind === "invoice" ? "Invoice issued" : "Returned to stock",
        number,
        id,
        actor,
      );
    auditLog(
      actor,
      kind === "quotation"
        ? "Quotation created"
        : kind === "invoice"
          ? "Invoice issued"
          : "Sales return recorded",
      id,
      null,
      data,
    );
    return docRow(q("SELECT * FROM documents WHERE id=?", id));
  });
}
// Installments and refunds are append-only rows; the invoice stores the net paid.
function payment(invoiceId, b, actor) {
  return tx(() => {
    const invoice = docRow(q("SELECT * FROM documents WHERE id=?", invoiceId));
    if (!invoice || invoice.kind !== "invoice" || invoice.status === "void")
      fail("Invoice unavailable.");
    const amount = Number(b.amount),
      type = b.type === "refund" ? "refund" : "payment",
      date = text(b.date, 10) || today(),
      method = text(b.method, 40);
    if (
      !validMoney(amount) ||
      amount === 0 ||
      !["Cash", "Bank", "Online", "Cheque"].includes(method) ||
      !/^\d{4}-\d{2}-\d{2}$/.test(date)
    )
      fail("Enter a valid payment.");
    const next = invoice.paidTotal + (type === "refund" ? -amount : amount),
      net = invoice.total - invoice.creditTotal;
    if (
      next < 0 ||
      (type === "refund" && next < net) ||
      (type === "payment" && next > net)
    )
      fail(
        type === "refund"
          ? "Refund exceeds customer credit."
          : "Payment exceeds outstanding balance.",
      );
    const id = uid(),
      number = `${type === "refund" ? "REF" : "REC"}-${new Date().getFullYear()}-${short(id)}`;
    run(
      "INSERT INTO payments VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
      id,
      invoiceId,
      number,
      invoice.number,
      date,
      amount,
      method,
      text(b.reference, 160),
      text(b.notes, 500),
      type,
      actor,
      now(),
    );
    run(
      "UPDATE documents SET paidTotal=?,updatedAt=? WHERE id=?",
      next,
      now(),
      invoiceId,
    );
    auditLog(
      actor,
      type === "refund" ? "Refund recorded" : "Payment recorded",
      invoiceId,
      { paidTotal: invoice.paidTotal },
      { paidTotal: next, amount },
    );
    return q("SELECT * FROM payments WHERE id=?", id);
  });
}
// One-time administrator resolution of a missing historical invoice cost.
function resolveInvoicePricing(invoiceId, index, b, actor) {
  return tx(() => {
    const invoice = docRow(q("SELECT * FROM documents WHERE id=?", invoiceId));
    if (!invoice || invoice.kind !== "invoice" || invoice.status === "void")
      fail("Active invoice unavailable.", 404);
    if (!Number.isSafeInteger(index) || index < 0 || index >= invoice.lines.length)
      fail("Invoice line unavailable.", 404);
    const line = invoice.lines[index];
    if (line.itemId && line.costPrice !== null && line.costPrice !== undefined)
      fail("This invoice line already has a confirmed cost.");
    const cost = Number(b.purchasePrice),
      sale = Number(b.salePrice);
    if (
      !validMoney(cost) ||
      !validMoney(sale) ||
      (cost === 0 && b.confirmZeroCost !== true)
    )
      fail("Enter valid cost and sale prices; explicitly confirm a zero cost.");
    if (cost > line.price && b.confirmBelowCost !== true)
      fail(
        "Actual cost exceeds the agreed invoice unit price. Confirm this loss to continue.",
        409,
      );
    const category = text(b.category, 40),
      isService = category === "Service";
    if (!["Solar panel", "Inverter", "Battery", "Service", "Other"].includes(category))
      fail("Choose a valid item category.");
    const oldItemId = line.itemId;
    let item = oldItemId ? q("SELECT * FROM items WHERE id=?", oldItemId) : null;
    if (!item && oldItemId) fail("Linked item unavailable.");
    if (!item) {
      // Old manual invoices had no catalog link. Create it only during review.
      const id = uid(),
        at = now();
      run(
        `INSERT INTO items
           (id,name,sku,category,description,brand,unit,purchasePrice,price,
            stock,lowStock,trackStock,active,createdAt,updatedAt,reviewStatus,originInvoiceId)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        id,
        line.description,
        `MAN-${short(invoice.id)}-${index + 1}`,
        category,
        "",
        "",
        isService ? "job" : "piece",
        cost,
        sale,
        0,
        0,
        isService ? 0 : 1,
        1,
        at,
        at,
        "ready",
        invoice.id,
      );
      line.itemId = id;
      line.manualOrigin = true;
      line.manualKind = isService ? "Service" : "Product";
      line.tracked = false;
      item = q("SELECT * FROM items WHERE id=?", id);
      auditLog(actor, "Legacy manual item catalogued", id, null, {
        invoiceId,
        lineIndex: index,
      });
    } else if (item.reviewStatus === "pending" && item.originInvoiceId === invoice.id) {
      if (item.stock > 0 && isService)
        fail("Returned stock exists; keep this line as a physical product.");
      run(
        `UPDATE items SET category=?,unit=?,purchasePrice=?,price=?,
           trackStock=?,reviewStatus='ready',updatedAt=? WHERE id=?`,
        category,
        isService ? "job" : "piece",
        cost,
        sale,
        isService ? 0 : 1,
        now(),
        item.id,
      );
      line.manualKind = isService ? "Service" : "Product";
      auditLog(
        actor,
        "Manual item pricing resolved",
        item.id,
        { reviewStatus: "pending" },
        { category, purchasePrice: cost, price: sale },
      );
    }
    line.costPrice = cost;
    run(
      "UPDATE documents SET lines=?,updatedAt=? WHERE id=?",
      JSON.stringify(invoice.lines),
      now(),
      invoiceId,
    );
    for (const raw of all(
      "SELECT * FROM documents WHERE kind='return' AND sourceId=? AND status!='void'",
      invoiceId,
    )) {
      const ret = docRow(raw);
      let changed = false;
      for (const returned of ret.lines) {
        if (
          returned.description !== line.description ||
          returned.price !== line.price ||
          returned.itemId !== oldItemId
        )
          continue;
        returned.costPrice = cost;
        if (line.manualOrigin) {
          returned.itemId = line.itemId;
          returned.manualOrigin = true;
          returned.manualKind = line.manualKind;
          returned.tracked = false;
          if (!oldItemId && ret.receivedBack && !isService)
            stockMove(
              line.itemId,
              returned.quantity,
              "Legacy manual return reconciled",
              ret.number,
              ret.id,
              actor,
            );
        }
        changed = true;
      }
      if (changed)
        run(
          "UPDATE documents SET lines=?,updatedAt=? WHERE id=?",
          JSON.stringify(ret.lines),
          now(),
          ret.id,
        );
    }
    auditLog(
      actor,
      "Invoice line cost resolved",
      invoiceId,
      { lineIndex: index, costPrice: null },
      {
        lineIndex: index,
        costPrice: cost,
        catalogSalePrice: sale,
        itemId: line.itemId,
      },
    );
    return { ok: true, itemId: line.itemId };
  });
}
// A credit note may be recorded before the physical goods reach the shop.
// Receiving them later is a separate, one-time inventory event so a missed checkbox
// can be corrected without deleting/recreating the financial return.
function receiveReturnStock(id, actor) {
  return tx(() => {
    const d = docRow(q("SELECT * FROM documents WHERE id=?", id));
    if (!d || d.kind !== "return" || d.status === "void")
      fail("Sales return unavailable.");
    if (d.receivedBack) fail("Returned stock has already been received.", 409);
    const stock = groupedStock(d.lines, 1);
    if (!stock.size) fail("This return has no physical stock to receive.");
    for (const [itemId, delta] of stock)
      stockMove(itemId, delta, "Returned to stock", d.number, d.id, actor);
    run("UPDATE documents SET receivedBack=1,updatedAt=? WHERE id=?", now(), id);
    auditLog(
      actor,
      "Returned stock received after credit note",
      id,
      { receivedBack: false },
      { receivedBack: true, stockMovements: [...stock.entries()] },
    );
    return docRow(q("SELECT * FROM documents WHERE id=?", id));
  });
}

// Financial documents are voided with audit history, never physically deleted here.
function voidDocument(id, actor) {
  return tx(() => {
    const d = docRow(q("SELECT * FROM documents WHERE id=?", id));
    if (!d || d.status === "void") fail("Document unavailable.");
    if (d.kind === "return")
      fail("Credit notes require a separate controlled reversal.");
    if (
      d.kind === "invoice" &&
      (q("SELECT COUNT(*) n FROM payments WHERE invoiceId=?", id).n ||
        q(
          "SELECT COUNT(*) n FROM documents WHERE kind='return' AND sourceId=? AND status!='void'",
          id,
        ).n)
    )
      fail("Resolve payments and returns before voiding this invoice.");
    if (
      d.kind === "quotation" &&
      q("SELECT COUNT(*) n FROM documents WHERE sourceId=? AND status!='void'", id).n
    )
      fail("Quotation has a linked document.");
    if (d.kind === "invoice") {
      for (const [itemId, delta] of groupedStock(d.lines, 1, { voiding: true }))
        stockMove(itemId, delta, "Invoice voided", d.number, id, actor);
      for (const line of d.lines) {
        if (!line.manualOrigin || !line.itemId) continue;
        const manual = q("SELECT * FROM items WHERE id=?", line.itemId);
        if (
          manual?.reviewStatus === "pending" &&
          manual.originInvoiceId === id &&
          manual.stock === 0
        ) {
          run(
            "UPDATE items SET active=0,reviewStatus='void-source',updatedAt=? WHERE id=?",
            now(),
            manual.id,
          );
          auditLog(
            actor,
            "Unresolved manual item archived after invoice void",
            manual.id,
            { reviewStatus: "pending" },
            { reviewStatus: "void-source" },
          );
        }
      }
      if (d.sourceId)
        run(
          "UPDATE documents SET status=?,convertedInvoiceId=?,updatedAt=? WHERE id=?",
          "Approved",
          "",
          now(),
          d.sourceId,
        );
    }
    run(
      "UPDATE documents SET status=?,voidedAt=?,updatedAt=? WHERE id=?",
      "void",
      now(),
      now(),
      id,
    );
    auditLog(actor, "Document voided", id, d, { status: "void" });
    return { ok: true };
  });
}
const send = (res, status, value, headers = {}) => {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    ...headers,
  });
  res.end(JSON.stringify(value));
};
async function body(req) {
  let raw = "";
  for await (const chunk of req) {
    raw += chunk;
    if (raw.length > 1048576) fail("Request too large.", 413);
  }
  try {
    return JSON.parse(raw || "{}");
  } catch {
    fail("Invalid JSON.");
  }
}
function session(req) {
  const id = /\bconfix_session=([^;]+)/.exec(req.headers.cookie || "")?.[1];
  return id
    ? q(
        "SELECT s.*,u.username,u.role,u.mustChangePassword FROM sessions s JOIN users u ON u.id=s.userId WHERE s.id=? AND s.expires>?",
        id,
        Date.now(),
      )
    : null;
}
function origin(req) {
  const o = req.headers.origin;
  if (o && !["http://127.0.0.1:" + port, "http://localhost:" + port].includes(o))
    fail("Request origin rejected.", 403);
}
function login(res, user, extra = {}) {
  const id = randomBytes(32).toString("hex"),
    csrf = randomBytes(24).toString("hex");
  run(
    "INSERT INTO sessions VALUES (?,?,?,?)",
    id,
    user.id,
    csrf,
    Date.now() + 7 * 86400000,
  );
  send(
    res,
    200,
    { user: user.username, role: user.role, mustChangePassword: !!user.mustChangePassword, csrf, ...extra },
    {
      "Set-Cookie": `confix_session=${id}; HttpOnly; SameSite=Strict; Path=/; Max-Age=604800`,
    },
  );
}
// API authentication and role checks are performed before protected routes.
// The UI restrictions alone are not security controls.
const route = async (req, res) => {
  try {
    const url = new URL(req.url, "http://localhost"),
      path = url.pathname,
      method = req.method;
    if (path.startsWith("/api/")) {
      if (path === "/api/session" && method === "GET") {
        const s = session(req);
        return send(res, 200, {
          setupNeeded: !q("SELECT id FROM users LIMIT 1"),
          recoveryConfigured: !!q("SELECT r.userId FROM recovery r JOIN users u ON u.id=r.userId WHERE u.role='admin' LIMIT 1"),
          user: s?.username || null,
          role: s?.role || null,
          mustChangePassword: !!s?.mustChangePassword,
          csrf: s?.csrf || null,
        });
      }
      if (path === "/api/setup" && method === "POST") {
        origin(req);
        const b = await body(req);
        if (q("SELECT id FROM users LIMIT 1")) fail("Setup is complete.", 403);
        const username = text(b.username, 60),
          password = String(b.password || "");
        if (username.length < 3 || password.length < 10)
          fail("Use a username of 3+ characters and a password of 10+ characters.");
        const salt = randomBytes(24).toString("hex"),
          id = uid();
        run(
          "INSERT INTO users(id,username,salt,hash,role) VALUES (?,?,?,?,?)",
          id,
          username,
          salt,
          scryptSync(password, salt, 64).toString("hex"),
          "admin",
        );
        const recoveryKey = randomBytes(18).toString("hex").toUpperCase();
        const recoverySalt = randomBytes(24).toString("hex");
        run(
          "INSERT INTO recovery(userId,salt,hash,createdAt,usedAt) VALUES (?,?,?,?,NULL)",
          id, recoverySalt, scryptSync(recoveryKey, recoverySalt, 64).toString("hex"), now(),
        );
        auditLog(username, "Local administrator created", id);
        return login(res, { id, username, role: "admin", mustChangePassword: 0 }, { recoveryKey });
      }
      if (path === "/api/login" && method === "POST") {
        origin(req);
        const b = await body(req),
          u = q("SELECT * FROM users WHERE username=?", text(b.username, 60));
        if (!u) fail("Invalid username or password.", 401);
        const actual = scryptSync(String(b.password || ""), u.salt, 64),
          expected = Buffer.from(u.hash, "hex");
        if (!timingSafeEqual(actual, expected))
          fail("Invalid username or password.", 401);
        return login(res, u);
      }
      if (path === "/api/recover-admin" && method === "POST") {
        origin(req);
        const b = await body(req), username = text(b.username, 60),
          recoveryKey = String(b.recoveryKey || "").trim().toUpperCase(),
          password = String(b.password || "");
        if (password.length < 10) fail("New password must be at least 10 characters.");
        const u = q("SELECT * FROM users WHERE username=? AND role='admin'", username);
        if (!u) fail("Recovery details are invalid.", 401);
        const r = q("SELECT * FROM recovery WHERE userId=?", u.id);
        if (!r) fail("Recovery details are invalid.", 401);
        const actual = scryptSync(recoveryKey, r.salt, 64), expected = Buffer.from(r.hash, "hex");
        if (actual.length !== expected.length || !timingSafeEqual(actual, expected))
          fail("Recovery details are invalid.", 401);
        const salt = randomBytes(24).toString("hex");
        run("UPDATE users SET salt=?,hash=?,mustChangePassword=0 WHERE id=?", salt, scryptSync(password, salt, 64).toString("hex"), u.id);
        run("DELETE FROM sessions WHERE userId=?", u.id);
        const newRecoveryKey = randomBytes(18).toString("hex").toUpperCase();
        const newRecoverySalt = randomBytes(24).toString("hex");
        run("UPDATE recovery SET salt=?,hash=?,createdAt=?,usedAt=NULL WHERE userId=?", newRecoverySalt, scryptSync(newRecoveryKey, newRecoverySalt, 64).toString("hex"), now(), u.id);
        auditLog(username, "Administrator password recovered; recovery key rotated", u.id);
        return send(res, 200, { ok: true, recoveryKey: newRecoveryKey });
      }
      const s = session(req);
      if (!s) fail("Sign in first.", 401);
      if (method !== "GET") {
        origin(req);
        if (req.headers["x-csrf-token"] !== s.csrf) fail("Session token missing.", 403);
      }
      const admin = s.role === "admin";
      if (path === "/api/users/change-password" && method === "POST") {
        const b = await body(req), password = String(b.password || "");
        if (password.length < 10) fail("Use a password of at least 10 characters.");
        const salt = randomBytes(24).toString("hex");
        run("UPDATE users SET salt=?,hash=?,mustChangePassword=0 WHERE id=?", salt, scryptSync(password, salt, 64).toString("hex"), s.userId);
        run("DELETE FROM sessions WHERE userId=? AND id<>?", s.userId, s.id);
        auditLog(s.username, "Password changed", s.userId);
        return send(res, 200, { ok: true });
      }
      // A user must always be able to sign out, including during a forced
      // temporary-password change. Clear the cookie and server session first.
      if (path === "/api/logout" && method === "POST") {
        run("DELETE FROM sessions WHERE id=?", s.id);
        return send(res, 200, { ok: true }, {
          "Set-Cookie": "confix_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0",
        });
      }
      if (s.mustChangePassword) fail("Change your temporary password before continuing.", 403);
      const restricted =
        /^\/api\/(items|backup|expenses|users)(\/|$)/.test(path) ||
        /^\/api\/documents\/[^/]+\/void$/.test(path);
      if (!admin && restricted) fail("Administrator access required.", 403);
      if (path === "/api/state" && method === "GET") {
        const items = all("SELECT * FROM items ORDER BY createdAt DESC").map(itemRow),
          documents = all("SELECT * FROM documents ORDER BY createdAt DESC").map(
            docRow,
          );
        return send(res, 200, {
          role: s.role,
          items: admin
            ? items
            : items
                .filter((i) => i.reviewStatus !== "pending")
                .map(({ id, name, sku, category, price, active }) => ({
                  id,
                  name,
                  sku,
                  category,
                  price,
                  active,
                })),
          customers: all("SELECT * FROM customers ORDER BY createdAt DESC"),
          documents: admin
            ? documents
            : documents.map((d) => ({
                ...d,
                lines: d.lines.map(({ costPrice, tracked, ...line }) => line),
              })),
          payments: all("SELECT * FROM payments ORDER BY createdAt DESC"),
          movements: admin
            ? all("SELECT * FROM movements ORDER BY createdAt DESC")
            : [],
          audit: admin
            ? all("SELECT * FROM audit ORDER BY createdAt DESC LIMIT 300")
            : [],
          expenses: admin
            ? all("SELECT * FROM expenses ORDER BY date DESC,createdAt DESC")
            : [],
          users: admin ? all("SELECT id,username,role FROM users ORDER BY rowid") : [],
        });
      }
      if (path === "/api/users/recovery-key" && method === "POST") {
        const recoveryKey = randomBytes(18).toString("hex").toUpperCase(), salt = randomBytes(24).toString("hex");
        run("INSERT INTO recovery(userId,salt,hash,createdAt,usedAt) VALUES (?,?,?,?,NULL) ON CONFLICT(userId) DO UPDATE SET salt=excluded.salt,hash=excluded.hash,createdAt=excluded.createdAt,usedAt=NULL", s.userId, salt, scryptSync(recoveryKey, salt, 64).toString("hex"), now());
        auditLog(s.username, "Administrator recovery key generated/rotated", s.userId);
        return send(res, 200, { recoveryKey });
      }
      if (path === "/api/users/employee" && method === "POST") {
        const b = await body(req),
          username = text(b.username, 60),
          password = String(b.password || "");
        if (username.length < 3 || password.length < 10)
          fail("Use a username of 3+ characters and password of 10+ characters.");
        return send(
          res,
          200,
          tx(() => {
            const current = q("SELECT * FROM users WHERE role='employee' LIMIT 1"),
              salt = randomBytes(24).toString("hex"),
              hash = scryptSync(password, salt, 64).toString("hex");
            if (current) {
              run(
                "UPDATE users SET username=?,salt=?,hash=?,mustChangePassword=1 WHERE id=?",
                username,
                salt,
                hash,
                current.id,
              );
              run("DELETE FROM sessions WHERE userId=?", current.id);
              auditLog(s.username, "Employee account updated", current.id);
              return { username, role: "employee" };
            }
            const id = uid();
            run(
              "INSERT INTO users(id,username,salt,hash,role,mustChangePassword) VALUES (?,?,?,?,?,1)",
              id,
              username,
              salt,
              hash,
              "employee",
            );
            auditLog(s.username, "Employee account created", id);
            return { username, role: "employee" };
          }),
        );
      }
      if (path === "/api/expenses" && method === "POST") {
        const b = await body(req),
          amount = Number(b.amount),
          category = text(b.category, 80),
          expenseDate = text(b.date, 10);
        if (
          !validMoney(amount) ||
          !amount ||
          !category ||
          !/^\d{4}-\d{2}-\d{2}$/.test(expenseDate)
        )
          fail("Enter a valid expense.");
        return send(
          res,
          201,
          tx(() => {
            const id = uid();
            run(
              "INSERT INTO expenses VALUES (?,?,?,?,?,?,?)",
              id,
              expenseDate,
              category,
              amount,
              text(b.notes, 500),
              s.username,
              now(),
            );
            auditLog(s.username, "Expense recorded", id, null, { amount, category });
            return { ok: true };
          }),
        );
      }
      if (path === "/api/items" && method === "POST") {
        const b = itemData(await body(req));
        return send(
          res,
          201,
          tx(() => {
            const id = uid(),
              at = now();
            run(
              `INSERT INTO items
               (id,name,sku,category,description,brand,unit,purchasePrice,price,
                stock,lowStock,trackStock,active,createdAt,updatedAt)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
              id,
              b.name,
              b.sku,
              b.category,
              b.description,
              b.brand,
              b.unit,
              b.purchasePrice,
              b.price,
              0,
              b.lowStock,
              b.trackStock,
              1,
              at,
              at,
            );
            auditLog(s.username, "Inventory item created", id, null, b);
            return itemRow(q("SELECT * FROM items WHERE id=?", id));
          }),
        );
      }
      let m = /^\/api\/items\/([^/]+)$/.exec(path);
      if (m && method === "PATCH") {
        const b = itemData(await body(req));
        return send(
          res,
          200,
          tx(() => {
            const old = q("SELECT * FROM items WHERE id=?", m[1]);
            if (!old) fail("Item unavailable.", 404);
            if (old.reviewStatus === "pending")
              fail("Resolve invoice pricing before editing this item.");
            if (old.trackStock !== b.trackStock && old.stock !== 0)
              fail("Set stock to zero before changing stock tracking.");
            run(
              "UPDATE items SET name=?,sku=?,category=?,description=?,brand=?,unit=?,purchasePrice=?,price=?,lowStock=?,trackStock=?,updatedAt=? WHERE id=?",
              b.name,
              b.sku,
              b.category,
              b.description,
              b.brand,
              b.unit,
              b.purchasePrice,
              b.price,
              b.lowStock,
              b.trackStock,
              now(),
              m[1],
            );
            auditLog(s.username, "Inventory item edited", m[1], old, b);
            return itemRow(q("SELECT * FROM items WHERE id=?", m[1]));
          }),
        );
      }
      m = /^\/api\/items\/([^/]+)\/stock$/.exec(path);
      if (m && method === "POST") {
        const b = await body(req),
          quantity = Number(b.quantity),
          item = q("SELECT * FROM items WHERE id=?", m[1]);
        if (!item?.trackStock || !item.active || item.reviewStatus === "pending")
          fail("Resolve item pricing before a manual stock movement.");
        if (
          !Number.isSafeInteger(quantity) ||
          Math.abs(quantity) > 1000000 ||
          !quantity
        )
          fail("Enter a nonzero integer quantity.");
        return send(
          res,
          200,
          tx(() => {
            stockMove(
              m[1],
              quantity,
              text(b.reason, 80) || "Manual stock movement",
              text(b.reference, 100),
              "",
              s.username,
            );
            auditLog(
              s.username,
              "Stock moved",
              m[1],
              { stock: item.stock },
              { stock: item.stock + quantity },
            );
            return itemRow(q("SELECT * FROM items WHERE id=?", m[1]));
          }),
        );
      }
      m = /^\/api\/items\/([^/]+)\/archive$/.exec(path);
      if (m && method === "POST")
        return send(
          res,
          200,
          tx(() => {
            const item = q("SELECT * FROM items WHERE id=?", m[1]);
            if (!item) fail("Item unavailable.", 404);
            if (item.reviewStatus === "pending")
              fail("Resolve invoice pricing before archiving this item.");
            if (!item.active) fail("Item is already archived.");
            if (item.stock) fail("Move remaining stock to zero before archiving.");
            run("UPDATE items SET active=0,updatedAt=? WHERE id=?", now(), m[1]);
            auditLog(s.username, "Item archived", m[1], item, { active: false });
            return { ok: true };
          }),
        );
      if (
        (path === "/api/customers" && method === "POST") ||
        (/^\/api\/customers\/[^/]+$/.test(path) && method === "PATCH")
      ) {
        const b = await body(req),
          name = text(b.name);
        if (!name) fail("Customer name required.");
        const data = {
            name,
            phone: text(b.phone, 60),
            email: text(b.email),
            address: text(b.address, 500),
          },
          id = path.split("/")[3] || uid();
        return send(
          res,
          200,
          tx(() => {
            const old = q("SELECT * FROM customers WHERE id=?", id);
            if (method === "PATCH" && !old) fail("Customer unavailable.", 404);
            if (method === "POST")
              run(
                "INSERT INTO customers VALUES (?,?,?,?,?,?,?)",
                id,
                data.name,
                data.phone,
                data.email,
                data.address,
                now(),
                now(),
              );
            else
              run(
                "UPDATE customers SET name=?,phone=?,email=?,address=?,updatedAt=? WHERE id=?",
                data.name,
                data.phone,
                data.email,
                data.address,
                now(),
                id,
              );
            auditLog(
              s.username,
              old ? "Customer edited" : "Customer created",
              id,
              old,
              data,
            );
            return q("SELECT * FROM customers WHERE id=?", id);
          }),
        );
      }
      if (path === "/api/documents" && method === "POST") {
        const b = await body(req);
        if (!admin && !["quotation", "invoice", "return"].includes(b.kind))
          fail("Administrator access required.", 403);
        return send(res, 201, createDocument(b, s.username, admin));
      }
      m = /^\/api\/quotations\/([^/]+)$/.exec(path);
      if (m && method === "PATCH") {
        const b = await body(req);
        return send(
          res,
          200,
          tx(() => {
            const old = docRow(q("SELECT * FROM documents WHERE id=?", m[1]));
            if (
              !old ||
              old.kind !== "quotation" ||
              old.status === "void" ||
              old.convertedInvoiceId
            )
              fail("Quotation unavailable or converted.");
            if (b.status) {
              if (
                !["Draft", "Submitted", "Approved", "Rejected", "Expired"].includes(
                  b.status,
                )
              )
                fail("Invalid quotation status.");
              run(
                "UPDATE documents SET status=?,updatedAt=? WHERE id=?",
                b.status,
                now(),
                m[1],
              );
            } else {
              const d = documentInput(b);
              run(
                "UPDATE documents SET customer=?,customerId=?,phone=?,email=?,title=?,tenderRef=?,customerRef=?,dueDate=?,notes=?,lines=?,total=?,updatedAt=? WHERE id=?",
                d.customer,
                d.customerId,
                d.phone,
                d.email,
                d.title,
                d.tenderRef,
                d.customerRef,
                d.dueDate,
                d.notes,
                JSON.stringify(d.lines),
                d.total,
                now(),
                m[1],
              );
            }
            auditLog(s.username, "Quotation updated", m[1], old, b);
            return docRow(q("SELECT * FROM documents WHERE id=?", m[1]));
          }),
        );
      }
      m = /^\/api\/invoices\/([^/]+)\/payments$/.exec(path);
      if (m && method === "POST")
        return send(res, 201, payment(m[1], await body(req), s.username));
      m = /^\/api\/invoices\/([^/]+)\/lines\/(\d+)\/resolve-pricing$/.exec(path);
      if (m && method === "POST") {
        if (!admin) fail("Administrator access required.", 403);
        return send(
          res,
          200,
          resolveInvoicePricing(m[1], Number(m[2]), await body(req), s.username),
        );
      }
      m = /^\/api\/returns\/([^/]+)\/receive-stock$/.exec(path);
      if (m && method === "POST") {
        if (!admin) fail("Administrator access required.", 403);
        return send(res, 200, receiveReturnStock(m[1], s.username));
      }
      m = /^\/api\/documents\/([^/]+)\/void$/.exec(path);
      if (m && method === "POST") return send(res, 200, voidDocument(m[1], s.username));
      if (path === "/api/backup" && method === "GET") {
        const filename = `confix-backup-${today()}-${Date.now()}.sqlite`,
          target = join(dir, filename);
        await backup(db, target);
        const size = (await stat(target)).size;
        res.writeHead(200, {
          "Content-Type": "application/octet-stream",
          "Content-Disposition": `attachment; filename="${filename}"`,
          "Content-Length": size,
          "Cache-Control": "no-store",
        });
        const stream = createReadStream(target);
        stream.on("close", () => rm(target, { force: true }));
        return stream.pipe(res);
      }
      fail("Endpoint not found.", 404);
    }
    if (method !== "GET" && method !== "HEAD") fail("Method not allowed.", 405);
    const allowed = {
        "/": "index.html",
        "/index.html": "index.html",
        "/app.js": "app.js",
        "/style.css": "style.css",
        "/local.css": "local.css",
        "/confix-logo.jpg": "confix-logo.jpg",
        "/payment-qr.png": "payment-qr.png",
      },
      name = allowed[path];
    if (!name) fail("Page not found.", 404);
    const content = await readFile(join(root, "public", name));
    res.writeHead(200, {
      "Content-Type": {
        ".html": "text/html; charset=utf-8",
        ".js": "text/javascript; charset=utf-8",
        ".css": "text/css; charset=utf-8",
        ".jpg": "image/jpeg",
        ".png": "image/png",
      }[extname(name)],
      "Cache-Control": "no-cache",
      "X-Content-Type-Options": "nosniff",
    });
    res.end(method === "HEAD" ? undefined : content);
  } catch (e) {
    if (!res.headersSent)
      send(res, e.status || (/UNIQUE constraint failed/.test(e.message) ? 409 : 500), {
        error: /UNIQUE constraint failed/.test(e.message)
          ? "Duplicate SKU or username."
          : e.status
            ? e.message
            : "Unexpected server error.",
      });
    if (!e.status) console.error(e);
  }
};
const server = http.createServer(route);
server.listen(port, host, () =>
  console.log(`CONFIX Solar Solution offline: http://${host}:${port}`),
);
async function shutdown() {
  server.close();
  db.close();
  await handle.close();
  await rm(lock, { force: true });
  process.exit(0);
}
process.on("SIGTERM", shutdown);
process.on("SIGINT", shutdown);
