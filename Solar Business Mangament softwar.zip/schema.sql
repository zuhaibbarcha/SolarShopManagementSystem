-- Existing databases remain intact: every table is created only if missing.
PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  salt TEXT NOT NULL,
  hash TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY,
  userId TEXT NOT NULL REFERENCES users(id),
  csrf TEXT NOT NULL,
  expires INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS items (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  sku TEXT UNIQUE,
  category TEXT NOT NULL,
  description TEXT,
  brand TEXT,
  unit TEXT NOT NULL,
  purchasePrice INTEGER NOT NULL DEFAULT 0,
  price INTEGER NOT NULL,
  stock INTEGER NOT NULL DEFAULT 0,
  lowStock INTEGER NOT NULL DEFAULT 0,
  trackStock INTEGER NOT NULL DEFAULT 0,
  active INTEGER NOT NULL DEFAULT 1,
  createdAt TEXT NOT NULL,
  updatedAt TEXT NOT NULL,
  reviewStatus TEXT NOT NULL DEFAULT 'ready',
  originInvoiceId TEXT
);
CREATE TABLE IF NOT EXISTS customers (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  phone TEXT,
  email TEXT,
  address TEXT,
  createdAt TEXT NOT NULL,
  updatedAt TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS documents (
  id TEXT PRIMARY KEY,
  kind TEXT NOT NULL,
  number TEXT UNIQUE NOT NULL,
  customer TEXT NOT NULL,
  customerId TEXT,
  phone TEXT,
  email TEXT,
  title TEXT,
  tenderRef TEXT,
  customerRef TEXT,
  date TEXT NOT NULL,
  dueDate TEXT,
  notes TEXT,
  lines TEXT NOT NULL,
  total INTEGER NOT NULL,
  sourceId TEXT,
  status TEXT NOT NULL,
  paidTotal INTEGER NOT NULL DEFAULT 0,
  creditTotal INTEGER NOT NULL DEFAULT 0,
  creditedLines TEXT NOT NULL DEFAULT '{}',
  convertedInvoiceId TEXT,
  receivedBack INTEGER NOT NULL DEFAULT 0,
  createdAt TEXT NOT NULL,
  updatedAt TEXT,
  voidedAt TEXT
);
CREATE TABLE IF NOT EXISTS payments (
  id TEXT PRIMARY KEY,
  invoiceId TEXT NOT NULL REFERENCES documents(id),
  number TEXT UNIQUE NOT NULL,
  invoiceNumber TEXT NOT NULL,
  date TEXT NOT NULL,
  amount INTEGER NOT NULL,
  method TEXT NOT NULL,
  reference TEXT,
  notes TEXT,
  type TEXT NOT NULL,
  actor TEXT NOT NULL,
  createdAt TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS movements (
  id TEXT PRIMARY KEY,
  itemId TEXT NOT NULL REFERENCES items(id),
  delta INTEGER NOT NULL,
  reason TEXT NOT NULL,
  reference TEXT,
  documentId TEXT,
  actor TEXT NOT NULL,
  createdAt TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS audit (
  id TEXT PRIMARY KEY,
  actor TEXT NOT NULL,
  action TEXT NOT NULL,
  recordId TEXT NOT NULL,
  before TEXT,
  after TEXT,
  createdAt TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS expenses (
  id TEXT PRIMARY KEY,
  date TEXT NOT NULL,
  category TEXT NOT NULL,
  amount INTEGER NOT NULL,
  notes TEXT,
  actor TEXT NOT NULL,
  createdAt TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS ix_documents_kind ON documents(kind, date);
CREATE INDEX IF NOT EXISTS ix_payments_invoice ON payments(invoiceId);
CREATE INDEX IF NOT EXISTS ix_movements_item ON movements(itemId);
