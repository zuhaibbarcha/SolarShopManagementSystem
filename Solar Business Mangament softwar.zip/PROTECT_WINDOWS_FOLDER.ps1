# Optional: restrict this copy of the program and its SQLite database to the
# current Windows account and SYSTEM. Run only from the owning Windows account.
# This does not block Windows administrators from taking ownership later.
param([switch] $Apply)

$ErrorActionPreference = 'Stop'
$project = (Resolve-Path -LiteralPath $PSScriptRoot).Path
if (-not (Test-Path -LiteralPath (Join-Path $project 'data') -PathType Container)) {
    throw 'Start the application once so its data folder exists.'
}
if (-not $Apply) {
    Write-Host 'No changes made. Back up the data, close the server, then run:'
    Write-Host 'powershell -NoProfile -ExecutionPolicy Bypass -File .\PROTECT_WINDOWS_FOLDER.ps1 -Apply'
    exit 0
}

$currentUser = [System.Security.Principal.WindowsIdentity]::GetCurrent().User
$systemUser = [System.Security.Principal.SecurityIdentifier]::new('S-1-5-18')
$rights = [System.Security.AccessControl.FileSystemRights]::FullControl
$allow = [System.Security.AccessControl.AccessControlType]::Allow
$none = [System.Security.AccessControl.PropagationFlags]::None

function Set-PrivateAcl([string] $target, [bool] $isDirectory) {
    $acl = Get-Acl -LiteralPath $target
    $acl.SetAccessRuleProtection($true, $false)
    foreach ($entry in @($acl.Access)) {
        [void] $acl.RemoveAccessRuleAll($entry)
    }
    $inherit = [System.Security.AccessControl.InheritanceFlags]::None
    if ($isDirectory) {
        $inherit = [System.Security.AccessControl.InheritanceFlags]::ContainerInherit -bor
                   [System.Security.AccessControl.InheritanceFlags]::ObjectInherit
    }
    foreach ($who in @($currentUser, $systemUser)) {
        $rule = [System.Security.AccessControl.FileSystemAccessRule]::new(
            $who, $rights, $inherit, $none, $allow
        )
        $acl.AddAccessRule($rule)
    }
    Set-Acl -LiteralPath $target -AclObject $acl
}

# Restrict existing child files first, then the project directory itself.
# A failure stops the script so the owner can inspect permissions manually.
Get-ChildItem -LiteralPath $project -Recurse -Force |
    Sort-Object { $_.FullName.Length } -Descending |
    ForEach-Object { Set-PrivateAcl $_.FullName $_.PSIsContainer }
Set-PrivateAcl $project $true
Write-Host 'Protected project folder for the current Windows user and SYSTEM.'
Write-Host 'Protect external backup files separately and keep Windows admin access private.'
