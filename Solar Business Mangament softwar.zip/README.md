# CONFIX Solar Solution · Offline Office

**Latest complete release:** Read `UPGRADE-MANUAL-PRICING.md` before replacing an
existing installation. Keep your `data` folder and a separate backup. This
Node.js + SQLite app works locally without Firebase or internet access.


## Updated office access and pricing

The original local account becomes **super admin** automatically when this version first starts. Sign in as that account, open **Users**, and set the separate **sales employee** username and password. Updating that employee login signs out its earlier sessions. The employee sees Customers, Quotations and Invoices, and can issue invoices, record partial/final payments and sales returns. Inventory administration, late restock corrections, protected voids, reports, backups, expenses, pricing overrides and financial dashboard figures remain admin-only. The app is designed for one computer; anyone with direct access to the SQLite files or operating system administrator rights can bypass application roles, so protect the computer and backups.

Use the **Discount %** field beside a saved item when creating a quotation or invoice. It lowers the unit price from that item's saved sale price; the document shows a discount only when one was granted. If an invoice line falls below the purchase price of a stocked item, the server requires explicit confirmation. For new documents, each catalog-linked line (including a service) saves its purchase-cost snapshot. The super admin can record business expenses, and the dashboard calculates recorded net profit from invoices, returns, saved product/service costs and recorded expenses. Older invoices created before cost snapshots are marked as incomplete for profit reporting. Unrecorded costs cannot be included.

Invoices display the CONFIX PRIVATE LIMITED Soneri Bank account details and the supplied QR image. Verify the QR with your banking app against the printed account/IBAN before accepting payments; the app does not verify its encoded destination.

**Updating an existing Windows installation:** while signed in as admin, download a backup. Stop the old server with Ctrl+C. Keep your existing `data` folder, replace only `server.mjs`, `public`, `START_WINDOWS.bat`, and `README.md` from the new ZIP, then restart. The new release migrates the `users` table in place and keeps customer, inventory and document records. Never copy the ZIP's empty data folder over your working data.

A separate, single-computer application. It runs on **127.0.0.1** and uses SQLite. It does not use Firebase or sync with the online site. The database starts empty so you can test entries without affecting your hosted app.

## Windows setup

1. Install **Node.js 24.8 or newer** once (the installer can be downloaded on a connected computer and copied over). No PHP, XAMPP, npm packages, Firebase account or internet connection is needed after installation.
2. Extract the ZIP into a permanent folder, such as `C:\CONFIX-Solar-Offline`. Do not run from inside the ZIP.
3. Double-click `START_WINDOWS.bat`, or open Command Prompt in the extracted folder and type `node server.mjs`.
4. Open `http://127.0.0.1:4173` on **the same computer**. Create an administrator username and a password of at least 10 characters. After the account is created, save the one-time recovery key shown by the application.
5. Keep the command window open while working. Close it with Ctrl+C to stop safely.

Mac/Linux: open a terminal in this folder, run `node server.mjs`, then open the address above.

## Try every entry

1. **Inventory:** Add 4–5 entries in each category (solar panels, inverters, batteries, services, other). Enable stock tracking for physical products; disable it for services. Use **Stock / history** to add opening stock. Editing a price does not change existing quotation prices.
2. **Customers:** Add an organization with phone and email.
3. **Quotations:** Select that customer, add several saved items, save. Search by number, customer, project, or tender reference. Open the record to print or save a PDF. Mark Submitted and Approved. Choose Reuse to make a new quotation with adjusted quantities; its original remains intact.
4. **Invoice:** From the approved quotation, choose Convert to invoice. Verify its quotation reference and the stock decrease. A quotation never decreases stock.
5. **Payments:** Open the invoice. The amount starts at its full remaining balance; enter a smaller figure for an installment. Check the payment history and Accounts receivable card after each installment. The app prevents paying more than the outstanding amount.
6. **Returns:** Open the invoice and choose Sales return. Return quantities at the original price; tick “Physical stock received back” only when the item actually arrived. Check the stock movement and Sales returns card. If the invoice was already paid, record the refund from its payment form.
7. **Void:** A quotation without linked invoice, or an invoice without payments or returns, may be voided with confirmation. Its history stays visible, and invoice stock is restored. The app blocks voiding invoices with linked financial entries.
8. **Persistence:** Refresh, sign out, sign in, and verify the same records. Stop and start Node.js to verify database persistence.

This package starts **without sample data**. The automated test (`node --test tests/flow.test.mjs`) creates 25 sample products, five customers, five quotations, payments, a return and a backup in a temporary database, then removes that temporary database. It never modifies your working records.

## Reusable document notes

New quotations and invoices start with a short note suited to that document.
You may edit it before saving; it prints on the document. A custom note saved on
one quotation or invoice becomes available in **Reuse a note from a previous
document** on later forms. Converting a quotation with custom terms preserves
those terms. If its note was only the standard quotation note, the invoice
form offers the standard payment note instead. Each document retains its own
saved wording even when later notes change.

## Backup and restore

- Click **Download backup** and store the `.sqlite` file on another drive. Do this regularly, especially before bulk changes. The download is a consistent SQLite backup while the app is running.
- To restore, **stop the server first**, save another copy of the current `data` folder, and in Command Prompt run:

  `node server.mjs --restore "C:\path\to\confix-backup.sqlite"`

- Restart with `node server.mjs`. Restore checks the file and saves the previous database as `before-restore-...sqlite` in `data`.
- The live database is `data/confix.sqlite`; keep the `data` folder when updating the program. Do not copy only the live SQLite file while the app is running; use the Download backup button.
- The offline data never automatically syncs to Firebase. Email and WhatsApp sharing need internet; the message prompts you to attach the saved PDF manually. Printing and PDF saving work offline.

## Limits and office use

This edition is intended for one computer and one local administrator. It listens only on `127.0.0.1` and cannot be accessed by other computers. Prices are stored as integer paisa in SQLite. Invoice line prices are fixed on issue; payments and returns retain separate records and audit entries. Physical returns are limited to quantities on the original invoice. Credit note reversal and editing issued invoices require a separate controlled workflow; the app blocks destructive changes instead of silently changing financial history. A computer failure without an external backup can lose data.

## Source code and access

The project is formatted and commented for manual editing. Read
`docs/ARCHITECTURE.md` for files, API, data flow and customization points.
Read `docs/ACCESS.md` before giving other Windows users access. The local
SQLite database is not encrypted: app permissions protect API access, while
Windows file permissions and disk encryption protect the actual files. The
source copy includes `LICENSE.txt` with the intended ownership restrictions.

Run `npm test` after any modification; tests use temporary databases.

## Manual item and profit review

Manual quotation lines do not create stock. A manually entered invoice line
creates an inventory item at zero stock with a pricing review notice for the
super admin. The admin confirms actual cost and future catalog sale price.
Sales profit and Net profit remain Incomplete until the cost is confirmed.
Physical returned items increase stock; services do not. See
`docs/MANUAL-ITEM-FLOW.md` for the exact accounting and migration behavior.

## Return stock receipt safeguard (2026-09-27)
A sales return/credit note and the physical receipt of goods are intentionally separate. If the credit note is recorded before the goods are received (or the restock checkbox was missed), an administrator can open the return and use **Mark goods received & restock**. The operation restores eligible physical stock exactly once, records an inventory movement and audit event, and rejects duplicate receipt attempts. Reports flag credit notes whose physical stock is still pending. Until the goods are actually received, their COGS remains charged, so a temporary negative margin can be legitimate rather than hidden.

## Password recovery and reset

- A new installation displays a one-time Super Admin recovery key after the administrator account is created. Save it outside the computer.
- Existing installations can sign in as Super Admin, open **Users**, and choose **Generate / replace Super Admin recovery key**. Creating a new key invalidates the previous one.
- The sign-in screen shows **Forgot Super Admin password?** only after a recovery key actually exists. Fresh installations therefore show setup only until the first administrator is created; upgraded installations without a recovery key show normal sign-in only. A successful recovery rotates the key and displays a new one to save.
- Super Admin can reset the sales employee login from **Users**. The employee is signed out and must choose a new personal password on the next sign-in. Any signed-in user, including an employee on the temporary-password page, can sign out to return to the initial login panel. The Super Admin recovery option appears there when a recovery key exists.
- Passwords and recovery keys are stored as salted scrypt hashes; plaintext passwords are not stored. Password changes and recovery-key operations are written to the audit log.
