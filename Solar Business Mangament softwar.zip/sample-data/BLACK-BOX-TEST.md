# CONFIX Solar Solution: five-case offline workflow test

**TEST DATA ONLY.** The customer names are real organizations used solely as labels in simulated records. They have not requested quotations or made payments. Emails use the reserved `example.test` domain; never send these PDFs or messages externally. Product descriptions, specifications and prices are illustrative, not verified catalog offers.

## Before you insert the data

1. This seed is for the **separate Node.js + SQLite localhost application**. It is not for Firebase or Firestore. Use the offline app with Node.js **24.8 or newer**.
2. Confirm the app opens at `http://127.0.0.1:4173` and create your local administrator account first.
3. Click **Download backup** in the app and copy the downloaded backup to another drive. Keep it until you finish testing.
4. Stop the app with **Ctrl+C** in its command window. Do not edit the SQLite file while the server is running.
5. Keep the included `sample-data` folder inside `confix-local-shop`. Double-click `RUN_DEMO_SEED_WINDOWS.bat` from the project root, or run `node sample-data/seed-demo.mjs`. It makes another automatic backup in `data` before any inserts. If it reports existing demo entries, stop; it intentionally will not duplicate records.
6. Restart `START_WINDOWS.bat`, sign in, and check **Inventory** and **Customers**. The seed inserts no quotations, invoices, payments, or returns: create these through the app to test the real rules. To run the isolated automated black-box test instead, use `npm run test:blackbox`; it creates and removes its own temporary database.

### Expected seed

- Inventory: five items each in **Solar panel, Inverter, Battery, Service, Other** (25 total). Every physical item starts at **20 units** with an opening movement. Services have tracking off and stock 0.
- Customers: five `TEST ONLY — ...` organization records with no real phone numbers and `example.test` emails.
- Audit: 30 seed events; stock history: 20 opening movements.
- Any missing count means stop testing and review the seed output. Do not run the seed again to patch a partial result.

## Use one row at a time

In **Quotations → + Quotation**, select the saved customer and choose the five saved items listed below. Set panel quantity **2**, and set inverter, battery, service, and other quantity **1** each. Keep the seeded sale price unchanged. Enter `TEST ONLY — simulated tender; not for submission` in Notes. Write down each generated quotation and invoice number; the IDs are unique and cannot be predicted in advance.

| Case | Saved customer (prefix `TEST ONLY —`) | Item SKU suffix (prefix `DEMO-`) | Project / tender ref | Quotation & invoice amount | Four installment amounts | One-panel return / refund |
|---|---|---|---|---:|---:|---:|
| 1 | Pakistan Telecommunication Company Limited | PNL-01, INV-01, BAT-01, SRV-01, OTH-01 | TEST Gilgit telecom solar / DEMO-TENDER-01 | PKR 271,500.00 | PKR 67,875.00 each | PKR 42,000.00 |
| 2 | K-Electric Limited | PNL-02, INV-02, BAT-02, SRV-02, OTH-02 | TEST hybrid upgrade / DEMO-TENDER-02 | PKR 336,200.00 | PKR 84,050.00 each | PKR 49,000.00 |
| 3 | Pakistan Petroleum Limited | PNL-03, INV-03, BAT-03, SRV-03, OTH-03 | TEST site resilience / DEMO-TENDER-03 | PKR 383,600.00 | PKR 95,900.00 each | PKR 51,500.00 |
| 4 | Oil and Gas Development Company Limited | PNL-04, INV-04, BAT-04, SRV-04, OTH-04 | TEST remote power / DEMO-TENDER-04 | PKR 413,700.00 | PKR 103,425.00 each | PKR 47,500.00 |
| 5 | National Logistics Corporation | PNL-05, INV-05, BAT-05, SRV-05, OTH-05 | TEST logistics solar / DEMO-TENDER-05 | PKR 504,850.00 | PKR 126,212.50 each | PKR 56,000.00 |

### Repeat these checks for **each of the five cases**

1. **Quotation:** Save; confirm the amount in the table. Search by its quotation number, customer name and tender reference. Reopen, use **Print / Save PDF** and verify company name, logo, address, contact information, item rows and highlighted total. Stock must still be 20 for that case's four physical items; service stock stays 0. If stock dropped now, stop.
2. **Status:** Mark Submitted, then Approved. Refresh the page; both the saved quotation and its status must remain.
3. **Invoice:** Open quotation → **Convert to invoice**. Confirm one new invoice, a unique invoice number and the original quotation reference in the invoice. Search the invoice number. Confirm panel stock changed **20 → 18**, inverter/battery/other **20 → 19**, service stock stays **0**. No duplicate customer or inventory item should appear. After issuing all five invoices, dashboard **Total sales = PKR 1,909,850.00**.
4. **Payments:** Open that invoice → **Record payment**, choose Bank, enter installment 1 from the table and an obvious reference like `DEMO-CASE-1-PAY-1`. Confirm invoice shows **Partially paid** and receivable = invoice amount minus payment. Record installments 2 and 3 separately; verify payment history shows 3 distinct receipts and the balance falls each time. Enter installment 4; it should show **Paid**, with balance zero and 4 distinct receipts. Try one extra PKR 1 payment: the app must reject it, leaving totals unchanged.
5. **Return:** From the paid invoice, choose **Sales return**. Remove the other lines; retain **one panel, quantity 1, at its original price**. Tick **Physical stock received back**. Confirm a linked credit note, panel stock **18 → 19**, Sales returns grows by the last column amount, and a refund is due. From the invoice payment form choose **Refund after credit note**, Bank and exactly the same amount. Confirm one separate refund entry, balance zero and unchanged history of the four prior installments.
6. **Persistence:** Refresh the browser. Sign out/in. Verify invoice, 4 receipts, 1 refund, linked return and stock history still exist before proceeding to the next case.

## Expected totals after all five cases

| Figure | Expected result |
|---|---:|
| Items / customers | 25 / 5 |
| Quotations / invoices / credit notes | 5 / 5 / 5 |
| Installment receipts / refund records | 20 / 5 |
| Gross Total sales | PKR 1,909,850.00 |
| Sales returns | PKR 246,000.00 |
| Net sales (gross less returns) | PKR 1,663,850.00 |
| Accounts receivable | PKR 0.00 |
| Sales profit (after returns and item/service costs, before expenses) | PKR 461,550.00 |
| Net profit (recorded), with no expenses recorded in these cases | PKR 461,550.00 |
| Net received after refunds | PKR 1,663,850.00 |
| Tracked stock for each case panel / inverter / battery / other | 19 / 19 / 19 / 19 |
| Services stock | 0 |

### Extra controls after the five-case totals are verified

- **Quotation reuse:** Open Case 1 quotation → Reuse; change panel quantity from 2 to 1 and save. Confirm a **sixth** quotation with a new number and unchanged original. Search both. The dashboard should display the five newest quotations, and **View all quotations** should show all six. This sixth quotation is not part of the five-case totals.
- **Manual stock movement:** Open `DEMO-OTH-01` → Stock / history. Record stock-out 1 (**19 → 18**) and stock-in 1 (**18 → 19**). Confirm two distinct movements and that invoice/return totals do not change.
- **Void with restoration:** Create one *additional* invoice with `DEMO-OTH-02`, quantity 1; check stock **19 → 18**. With no payment or return, void it; check stock **18 → 19** and audit history. This void invoice is excluded from valid sales.
- **Search/print:** Search the newest quotation and each invoice by number and organization. Verify that printing a quotation or invoice omits action buttons.

**Additional negative check:** Try to void one of the paid/returned invoices. The app must refuse because it has payment and return records. Use a separate *unpaid* test invoice with no return if you need to test successful voiding and stock restoration. Do not delete or edit these five linked cases by directly changing SQL.

To inspect the database without changing it, use the SELECT statements in `verify-demo.sql` after stopping the server. If a balance, count, stock quantity or reference differs, stop at that exact case and note the document number, step, expected figure and actual figure. This pinpoints the broken transition without mixing later cases into the diagnosis.

On Windows, after stopping the app, run `node sample-data/verify-demo.mjs` from the folder containing `server.mjs`. This executes read-only checks and prints the actual counts and balances; `sample-data/verify-demo.sql` contains the equivalent SQL for a database viewer.

## Automated black-box evidence

Run `npm run test:blackbox` in the project folder. The test starts the actual
localhost server, creates the admin account, loads the fixture into a temporary
SQLite database, then calls the same HTTP endpoints as the browser for five
quotations, five invoices, 20 payments, five returns and five refunds. It checks
stock, cross-references, totals, service costs, receivables, persistence after
a restart and read-only database integrity. The fixture is loaded directly
only for test setup; business actions use the public API. It refuses duplicate
seeding. The test removes its temporary database after completion and never
modifies your `data` folder.

**Expected:** 25 items, five customers, sales PKR 1,909,850.00, returns
PKR 246,000.00, sales profit PKR 461,550.00, receivables PKR 0.00,
20 receipts and five refunds. If a check fails, the assertion shows the
affected API step. Keep that output and the document number when reporting it.
