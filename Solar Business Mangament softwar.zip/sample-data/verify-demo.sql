-- READ-ONLY CHECKS. Run against data/confix.sqlite when the server is stopped.
SELECT category,COUNT(*) AS item_count,MIN(stock) AS min_stock,MAX(stock) AS max_stock FROM items WHERE sku LIKE 'DEMO-%' GROUP BY category ORDER BY category;
SELECT COUNT(*) AS test_customers FROM customers WHERE id LIKE 'demo-customer-%';
SELECT kind,COUNT(*) AS document_count,ROUND(SUM(total)/100.0,2) AS pkr_total FROM documents WHERE status!='void' AND (customerId LIKE 'demo-customer-%' OR sourceId IN (SELECT id FROM documents WHERE customerId LIKE 'demo-customer-%')) GROUP BY kind ORDER BY kind;
SELECT COUNT(*) AS installment_receipts FROM payments WHERE type='payment' AND invoiceId IN (SELECT id FROM documents WHERE customerId LIKE 'demo-customer-%');
SELECT COUNT(*) AS refunds FROM payments WHERE type='refund' AND invoiceId IN (SELECT id FROM documents WHERE customerId LIKE 'demo-customer-%');
SELECT number,customer,ROUND(total/100.0,2) AS invoice_pkr,ROUND(creditTotal/100.0,2) AS returned_pkr,ROUND(paidTotal/100.0,2) AS paid_net_pkr,ROUND(MAX(0,total-creditTotal-paidTotal)/100.0,2) AS receivable_pkr FROM documents WHERE kind='invoice' AND customerId LIKE 'demo-customer-%' ORDER BY createdAt;
SELECT i.sku,i.name,i.stock,i.trackStock FROM items i WHERE i.sku LIKE 'DEMO-%' ORDER BY i.sku;
