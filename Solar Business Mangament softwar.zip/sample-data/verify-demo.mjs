import { DatabaseSync } from "node:sqlite";
import { stat } from "node:fs/promises";
import { resolve, join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
const dir = resolve(
  process.env.CONFIX_DATA_DIR ||
    join(dirname(fileURLToPath(import.meta.url)), "../data"),
);
const file = join(dir, "confix.sqlite");
if (!(await stat(file).catch(() => null)))
  throw Error("Database not found. Place this file beside server.mjs.");
const db = new DatabaseSync(file, { readOnly: true });
try {
  const all = (sql) => db.prepare(sql).all(),
    one = (sql) => db.prepare(sql).get(),
    pkr = (x) =>
      "PKR " +
      (x / 100).toLocaleString("en-PK", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      });
  console.log("TEST INVENTORY BY CATEGORY");
  console.table(
    all(
      "SELECT category,COUNT(*) AS items,MIN(stock) AS min_stock,MAX(stock) AS max_stock FROM items WHERE sku LIKE 'DEMO-%' GROUP BY category ORDER BY category",
    ),
  );
  console.log(
    "TEST CUSTOMERS:",
    one("SELECT COUNT(*) AS n FROM customers WHERE id LIKE 'demo-customer-%'").n,
  );
  const docs = all(
    "SELECT kind,COUNT(*) AS count,SUM(total) AS total FROM documents WHERE status!='void' AND (customerId LIKE 'demo-customer-%' OR sourceId IN (SELECT id FROM documents WHERE customerId LIKE 'demo-customer-%')) GROUP BY kind ORDER BY kind",
  );
  console.table(
    docs.map((x) => ({ kind: x.kind, count: x.count, total_pkr: pkr(x.total) })),
  );
  const payments = all(
    "SELECT type,COUNT(*) AS count,SUM(amount) AS amount FROM payments WHERE invoiceId IN (SELECT id FROM documents WHERE customerId LIKE 'demo-customer-%') GROUP BY type ORDER BY type",
  );
  console.table(payments.map((x) => ({ ...x, amount_pkr: pkr(x.amount) })));
  const invoices = all(
    "SELECT number,total,creditTotal,paidTotal,MAX(0,total-creditTotal-paidTotal) AS balance FROM documents WHERE kind='invoice' AND customerId LIKE 'demo-customer-%' ORDER BY createdAt",
  );
  console.table(
    invoices.map((x) => ({
      number: x.number,
      invoice: pkr(x.total),
      returned: pkr(x.creditTotal),
      paid_net: pkr(x.paidTotal),
      receivable: pkr(x.balance),
    })),
  );
  console.log(
    "Stock history records:",
    one("SELECT COUNT(*) AS n FROM movements WHERE itemId LIKE 'demo-item-%'").n,
  );
  console.log("Integrity:", one("PRAGMA integrity_check").integrity_check);
} finally {
  db.close();
}
