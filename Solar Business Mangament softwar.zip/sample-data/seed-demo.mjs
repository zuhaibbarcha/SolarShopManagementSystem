import { DatabaseSync, backup } from "node:sqlite";
import { readFile, stat, mkdir } from "node:fs/promises";
import { resolve, join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
const here = dirname(fileURLToPath(import.meta.url));
const dataDir = resolve(process.env.CONFIX_DATA_DIR || join(here, "../data"));
const dbFile = join(dataDir, "confix.sqlite"),
  lock = join(dataDir, "server.lock");
if (!(await stat(dbFile).catch(() => null)))
  throw Error(
    "Database not found. Put these seed files beside server.mjs, start the app once, create the administrator, and stop it before seeding.",
  );
const lockFile = await readFile(lock, "utf8").catch((e) => {
  if (e.code === "ENOENT") return null;
  throw e;
});
if (lockFile) {
  const pid = Number(lockFile);
  try {
    process.kill(pid, 0);
    throw Error("Stop the localhost app (Ctrl+C) before inserting test data.");
  } catch (e) {
    if (e.code !== "ESRCH") throw e;
  }
}
const db = new DatabaseSync(dbFile);
try {
  db.exec("PRAGMA foreign_keys=ON;");
  if (db.prepare("PRAGMA integrity_check").get().integrity_check !== "ok")
    throw Error("Database integrity check failed.");
  if (!db.prepare("SELECT 1 FROM users LIMIT 1").get())
    throw Error("Create your local administrator account first.");
  const existing =
    db.prepare("SELECT COUNT(*) n FROM items WHERE sku LIKE 'DEMO-%'").get().n +
    db
      .prepare(
        "SELECT COUNT(*) n FROM customers WHERE id LIKE 'demo-customer-%' OR name LIKE 'TEST ONLY — %'",
      )
      .get().n;
  if (existing)
    throw Error(
      "Test seed already exists or conflicts with existing test customers. No changes made.",
    );
  const backupPath = join(
    dataDir,
    `before-demo-seed-${new Date().toISOString().replace(/[:.]/g, "-")}.sqlite`,
  );
  await backup(db, backupPath);
  console.log("Safety backup saved:", backupPath);
  const sql = await readFile(join(here, "seed-demo.sql"), "utf8");
  try {
    db.exec(sql);
  } catch (e) {
    try {
      db.exec("ROLLBACK");
    } catch {}
    throw e;
  }
  const count = (table) =>
    db
      .prepare(
        `SELECT COUNT(*) n FROM ${table} WHERE ${table === "items" ? "sku LIKE 'DEMO-%'" : "id LIKE 'demo-customer-%'"}`,
      )
      .get().n;
  const items = count("items"),
    customers = count("customers");
  const movements = db
    .prepare("SELECT COUNT(*) n FROM movements WHERE reference='DEMO-SEED'")
    .get().n;
  if (items !== 25 || customers !== 5 || movements !== 20)
    throw Error(
      `Seed count unexpected: ${items} items, ${customers} customers, ${movements} movements.`,
    );
  console.log(
    "Inserted 25 items (five per category), five test customers, 20 stock movements and audit entries.",
  );
  console.log("Restart the app with START_WINDOWS.bat.");
} finally {
  db.close();
}
