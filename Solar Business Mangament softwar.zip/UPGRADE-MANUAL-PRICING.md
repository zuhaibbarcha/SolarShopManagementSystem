# CONFIX Solar Solution offline — complete manual-item release

## Update an existing office installation (Windows)

1. Sign in as super admin and click **Download backup**. Copy that backup to
   another drive. Keep a separate copy of the entire existing `data` folder.
2. Stop the Node.js server with **Ctrl+C**. Do not replace files while it runs.
3. Extract this ZIP. Copy the program files into your existing
   `confix-local-shop` folder and allow replacement of `server.mjs`, `schema.sql`,
   `public`, `tests` and documentation. **Do not remove or overwrite your
   existing `data` folder.** This ZIP contains no live database.
4. In the project folder run `npm test`. Then start `START_WINDOWS.bat` and
   refresh your browser with **Ctrl+Shift+R**.
5. The server adds two metadata columns to existing inventory records without
   deleting records. Earlier invoices and their linked returns remain intact.

This is the **offline Node.js + SQLite** edition. It does not update Firebase
hosting or sync to the online site.

## Entering a line

- **Saved item:** select it in the dropdown. Its description is locked on the
  line. The agreed price may be discounted. Issuing an invoice deducts physical
  stock, while a quotation leaves stock unchanged.
- **Manual entry:** select Manual entry, type its description, select **Physical
  product** or **Service / labour**, quantity and unit sale price. A quotation
  saves this line without creating inventory. When the invoice is issued, a
  separate catalog item is created at stock **0** with status **Pricing review
  required**. No other item's stock is deducted. The invoice retains the
  agreed amount.

## Super admin pricing review

A yellow notice appears on every admin page while valid invoice lines need
review. Open **Invoices → Needs pricing → Review pricing** or **Inventory →
Needs pricing → Review pricing**. Enter the actual unit cost, choose the category
and confirm the future catalog sale price. Zero actual cost needs an explicit
checkbox. A cost higher than the agreed invoice unit price requires an
additional confirmation because it records a loss on that line. The original invoice price and total do not change.

Sales profit and Net profit show **Incomplete** until all valid invoice costs are
resolved. A returned physical product increases its linked item's stock even
when pricing review is pending; Inventory value then also shows **Incomplete**.
Cost review updates the invoice and related returns together in one database
transaction and records the actor and change in the audit trail. Employees can
issue manual invoices but cannot see costs or the review queue.

Earlier manual invoices without item links remain visible and are also flagged
for review. Resolving one creates its catalog item and reconciles physical
returns previously recorded against that invoice. Historical invoice amounts
and payment records are not rewritten.

## Checks

Run `npm test`: it uses isolated temporary databases and does not touch your
`data/confix.sqlite`. The tests cover stored-item stock, manual quotations and
invoices, employee restrictions, service costs, physical returns, pending
pricing, older-database migration, profit, voids, payments, and backups. The
sample data in `sample-data/` is explicitly marked test-only and is never
inserted into your office database by `npm test`.
