@echo off
cd /d "%~dp0"
echo TEST DATA ONLY: 25 items and 5 simulated customers.
echo Back up your database and stop the app before continuing.
echo This operation refuses duplicate DEMO records and makes its own backup.
pause
node sample-data\seed-demo.mjs
pause
